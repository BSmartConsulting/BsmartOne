package com.aza.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiApplication {

    public static void main(String[] args) throws InterruptedException {
        SpringApplication.run(ApiApplication.class, args);
    }

}

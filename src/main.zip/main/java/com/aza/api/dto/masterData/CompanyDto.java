/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.*;
import com.aza.api.model.masterData.Company;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CompanyDto extends BaseEntity {

    private Long id;
    private String companyname;
    private String nit;

    public static Company CompanyDtoToCompany(CompanyDto recordDto) {
        Company company = Company.builder()
                .id(recordDto.getId())
                .companyname(recordDto.getCompanyname())
                .nit(recordDto.getNit())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
        return company;
    }

    public static CompanyDto CompanyToCompanyDto(Company record) {
        CompanyDto companydto = CompanyDto.builder()
                .id(record.getId())
                .companyname(record.getCompanyname())
                .nit(record.getNit())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
        return companydto;
    }

    public CompanyDto() {
    }

    @Builder
    public CompanyDto(Long id, String companyname, String nit, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.companyname = companyname;
        this.nit = nit;
    }

}

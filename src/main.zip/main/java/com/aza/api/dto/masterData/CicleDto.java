/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.*;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.CicleType;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CicleDto extends BaseEntity implements Serializable {

    private Long id;
    private CicleTypeDto cicletype;
    private String name;
    private String ciclenumber;
    private String description;
    private LocalDateTime startdate;
    private LocalDateTime enddate;

    public static Cicle CicleDtoToCicle(CicleDto recordDto) {
        CicleType cicleType = null;
        cicleType = CicleTypeDto.CicleTypeDtoToCicleType(recordDto.getCicletype());
        Cicle cicle = Cicle.builder()
                .id(recordDto.getId())
                .cicletype(cicleType.getId())
                .name(recordDto.getName())
                .ciclenumber(recordDto.getCiclenumber())
                .description(recordDto.getDescription())
                .startdate(recordDto.getStartdate())
                .enddate(recordDto.getEnddate())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
        return cicle;
    }

    public static CicleDto CicleToCicleDto(Cicle record) {
        CicleTypeDto cicleTypeDto = CicleTypeDto.CicleTypeToCicleTypeDto(CicleTypeDto.getCicleTypeDto(record.getCicletype()));
        CicleDto cicledto = CicleDto.builder()
                .id(record.getId())
                .cicletype(cicleTypeDto)
                .name(record.getName())
                .ciclenumber(record.getCiclenumber())
                .description(record.getDescription())
                .startdate(record.getStartdate())
                .enddate(record.getEnddate())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
        return cicledto;
    }

    public CicleDto() {
    }

    @Builder
    public CicleDto(Long id, CicleTypeDto cicletype, String name, String ciclenumber, String description, LocalDateTime startdate, LocalDateTime enddate, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.cicletype = cicletype;
        this.name = name;
        this.ciclenumber = ciclenumber;
        this.description = description;
        this.startdate = startdate;
        this.enddate = enddate;
    }

}

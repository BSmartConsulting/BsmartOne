package com.aza.api.dto.masterData;

import com.aza.api.model.*;
import com.aza.api.model.masterData.Profile;
import com.aza.api.model.masterData.Role;
import com.aza.api.model.masterData.User;
import com.aza.api.model.masterData.UserRole;
import com.aza.api.model.masterData.UserStatus;
import com.aza.api.model.masterData.UserType;
import com.aza.api.service.masterData.ProfileService;
import com.aza.api.service.masterData.RoleService;
import com.aza.api.service.masterData.UserRoleService;
import com.aza.api.service.masterData.UserStatusService;
import com.aza.api.service.masterData.UserTypeService;
import com.aza.api.util.BeanUtil;
import com.aza.api.util.GlobalExceptionHandler;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class UserDto extends BaseEntity implements Serializable {

    private static UserStatusService userStatusService = BeanUtil.getBean(UserStatusService.class);
    private static RoleService roleService = BeanUtil.getBean(RoleService.class);
    private static UserRoleService userRoleService = BeanUtil.getBean(UserRoleService.class);
    private static UserTypeService userTypeService = BeanUtil.getBean(UserTypeService.class);
    private static ProfileService profileService = BeanUtil.getBean(ProfileService.class);

    private Long id;
    private String username;
    private String password;
    private String email;
    private String taxid;
    private UserStatusDto status;
    private String fullname;
    private ProfileDto azaprofile;
    private String capacity;
    private UserTypeDto usertype;
    private boolean requirespasswordchange;
    private Integer failedattempts;
    private Set<RoleDto> roles;
    private String specialty;
    private String corporateemail;
    private String licensenumber;
    private String technicalexperience;
    private String specialization;
    private String coreprofession;
    private String otherformation;
    private String cityofresidence;
    private String address;
    private String cellphone;
    private String coodinator;
    private String supportconsultant;
    private LocalDateTime startdate;
    private LocalDateTime enddate;

    public static User UserDtoToUser(UserDto recordDto) {
        Set<Long> roles = new HashSet<>();
        try {

            for (RoleDto role : recordDto.getRoles()) {
                roles.add(role.getId());
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);

        }
        return User.builder()
                .id(recordDto.getId())
                .username(recordDto.getUsername())
                .password(recordDto.getPassword())
                .email(recordDto.getEmail())
                .fullname(recordDto.getFullname())
                .taxid(recordDto.getTaxid())
                .status(recordDto.getStatus().getId())
                .requirespasswordchange(recordDto.isRequirespasswordchange())
                .roles(roles)
                .azaprofile(recordDto.getAzaprofile() != null ? recordDto.getAzaprofile().getId() : null)
                .capacity(recordDto.getCapacity())
                .cellphone(recordDto.getCellphone())
                .failedattempts(recordDto.getFailedattempts())
                .specialty(recordDto.getSpecialty())
                .corporateemail(recordDto.getCorporateemail())
                .licensenumber(recordDto.getLicensenumber())
                .technicalexperience(recordDto.getTechnicalexperience())
                .specialization(recordDto.getSpecialization())
                .coreprofession(recordDto.getCoreprofession())
                .otherformation(recordDto.getOtherformation())
                .cityofresidence(recordDto.getCityofresidence())
                .address(recordDto.getAddress())
                .failedattempts(recordDto.getFailedattempts())
                .cellphone(recordDto.getCellphone())
                .usertype(recordDto.getUsertype().getId())
                .coodinator(recordDto.getCoodinator())
                .supportconsultant(recordDto.getSupportconsultant())
                .startdate(recordDto.getStartdate())
                .enddate(recordDto.getEnddate())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    public static UserDto UserToUserDto(User record) {

        Set<Long> roleIds = getUserRolesById(record.getId());
        Set<Role> currentRoles = new HashSet<>();
        for (Long userRole : roleIds) {
            for (Role r : roleService.getAllActive()) {
                if (userRole == r.getId()) {
                    currentRoles.add(r);
                }
            }
        }
        Set<RoleDto> roles = currentRoles.stream()
                .map(RoleDto::RoleToRoleDto)
                .collect(Collectors.toSet());
        UserStatus currentUserStatus = new UserStatus();
        UserType currentUserType = new UserType();
        Profile currentAzaProfile = new Profile();
        Profile currentArlProfile = new Profile();
        for (UserStatus us : userStatusService.getAllActive()) {
            if (record.getStatus() == us.getId()) {
                currentUserStatus = us;
                break;
            }
        }
        for (UserType ut : userTypeService.getAllActive()) {
            if (record.getUsertype() == ut.getId()) {
                currentUserType = ut;
                break;
            }
        }

        for (Profile p : profileService.getAllActive()) {
            if (record.getAzaprofile() == p.getId()) {
                currentAzaProfile = p;
                break;
            }
        }

        UserStatusDto userstatus = UserStatusDto.UserStatusToUserStatusDto(currentUserStatus);

        ProfileDto azaProfileDto = ProfileDto.ProfileToProfileDto(currentAzaProfile);

        ProfileDto arlProfileDto = ProfileDto.ProfileToProfileDto(currentArlProfile);

        UserTypeDto usertype = UserTypeDto.UserTypeToUserTypeDto(currentUserType);

        return UserDto.builder()
                .id(record.getId())
                .username(record.getUsername())
                .password(record.getPassword())
                .email(record.getEmail())
                .fullname(record.getFullname())
                .taxid(record.getTaxid())
                .status(userstatus)
                .requirespasswordchange(record.isRequirespasswordchange())
                .roles(roles)
                .azaprofile(azaProfileDto != null ? azaProfileDto : null)
                .capacity(record.getCapacity())
                .cellphone(record.getCellphone())
                .failedattempts(record.getFailedattempts())
                .usertype(usertype)
                .specialty(record.getSpecialty())
                .corporateemail(record.getCorporateemail())
                .licensenumber(record.getLicensenumber())
                .technicalexperience(record.getTechnicalexperience())
                .specialization(record.getSpecialization())
                .coreprofession(record.getCoreprofession())
                .otherformation(record.getOtherformation())
                .cityofresidence(record.getCityofresidence())
                .address(record.getAddress())
                .failedattempts(record.getFailedattempts())
                .cellphone(record.getCellphone())
                .coodinator(record.getCoodinator())
                .supportconsultant(record.getSupportconsultant())
                .startdate(record.getStartdate())
                .enddate(record.getEnddate())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    private static Set<Long> getUserRolesById(Long id) {
        Set<UserRole> currentUserRole = userRoleService.findByUserId(id);
        Set<Long> allUserRoleId = new HashSet<>();
        for (UserRole ur : currentUserRole) {
            allUserRoleId.add(ur.getRoleId());
        }
        return allUserRoleId;
    }

    public UserDto() {
    }

    @Builder
    public UserDto(Long id, String username, String password, String email, String taxid, UserStatusDto status, String fullname, ProfileDto azaprofile, String capacity, UserTypeDto usertype, boolean requirespasswordchange, Integer failedattempts, Set<RoleDto> roles, String specialty, String corporateemail, String licensenumber, String technicalexperience, String specialization, String coreprofession, String otherformation, String cityofresidence, String address, String cellphone, String coodinator, String supportconsultant, LocalDateTime startdate, LocalDateTime enddate, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.taxid = taxid;
        this.status = status;
        this.fullname = fullname;
        this.azaprofile = azaprofile;
        this.capacity = capacity;
        this.usertype = usertype;
        this.requirespasswordchange = requirespasswordchange;
        this.failedattempts = failedattempts;
        this.roles = roles;
        this.specialty = specialty;
        this.corporateemail = corporateemail;
        this.licensenumber = licensenumber;
        this.technicalexperience = technicalexperience;
        this.specialization = specialization;
        this.coreprofession = coreprofession;
        this.otherformation = otherformation;
        this.cityofresidence = cityofresidence;
        this.address = address;
        this.cellphone = cellphone;
        this.coodinator = coodinator;
        this.supportconsultant = supportconsultant;
        this.startdate = startdate;
        this.enddate = enddate;
    }
}

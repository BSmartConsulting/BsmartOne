package com.aza.api.dto;

import com.aza.api.dto.masterData.*;
import com.aza.api.model.*;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.CityService;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.DiscountReasonService;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.BeanUtil;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class DiscountDto extends BaseEntity implements Serializable {

    private static UserService userService = BeanUtil.getBean(UserService.class);
    private static DiscountReasonService discountReasonService = BeanUtil.getBean(DiscountReasonService.class);
    private static CicleService cicleService = BeanUtil.getBean(CicleService.class);

    private Long id;
    private UserDto userId;
    private DiscountReasonDto discountReason;
    private CicleDto settlementCicle;
    private LocalDate discountDate;
    private Long amount;

    public static Discount DiscountDtoToDiscount(DiscountDto record) {
        return Discount.builder()
                .id(record.getId())
                .discountReason(record.getDiscountReason()!=null ? record.getDiscountReason().getId(): null)
                .settlementCicle(record.getSettlementCicle()!=null ? record.getSettlementCicle().getId():null)
                .userId(record.getUserId()!=null ? record.getUserId().getId():null)
                .discountDate(record.getDiscountDate()!=null ? record.getDiscountDate(): null)
                .amount(record.getAmount())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static DiscountDto DiscountToDiscountDto(Discount record,
            Map<Long, UserDto> userMap,
            Map<Long, CicleDto> cicleMap,
            Map<Long, DiscountReasonDto> discountReasonMap) {

        // Luego puedes usar estos mapas para asignar los DTOs
        CicleDto settlementCicle = cicleMap.getOrDefault(record.getSettlementCicle(), new CicleDto());
        DiscountReasonDto discounReason = discountReasonMap.getOrDefault(record.getDiscountReason(), new DiscountReasonDto());
        UserDto user = userMap.getOrDefault(record.getUserId(), new UserDto());
        return DiscountDto.builder()
                .discountReason(discounReason)
                .settlementCicle(settlementCicle)
                .userId(user)
                .discountDate(record.getDiscountDate()!=null ? record.getDiscountDate(): null)
                .amount(record.getAmount())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public DiscountDto() {
    }

    @Builder
    public DiscountDto(Long id, UserDto userId, DiscountReasonDto discountReason, CicleDto settlementCicle, LocalDate discountDate, Long amount, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.userId = userId;
        this.discountReason = discountReason;
        this.settlementCicle = settlementCicle;
        this.discountDate = discountDate;
        this.amount = amount;
    }

}

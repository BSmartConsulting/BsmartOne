/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.DiscountReason;
import com.aza.api.repository.masterData.DiscountReasonRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class DiscountReasonDto extends CatalogEntity {

    private static DiscountReasonRepository discountReasonRepository = BeanUtil.getBean(DiscountReasonRepository.class);
    private Long id;

    public static DiscountReason getDiscountReasonDto(Long statusid) {
        Optional<DiscountReason> currentDiscountReason = discountReasonRepository.findById(statusid);
        DiscountReason result = null;
        if (currentDiscountReason.isPresent()) {
            result = currentDiscountReason.get();
        }
        return result;
    }

    public static DiscountReasonDto DiscountReasonToDiscountReasonDto(DiscountReason record) {
        return DiscountReasonDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static DiscountReason DiscountReasonDtoToDiscountReason(DiscountReasonDto recordDto) {
        return DiscountReason.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public DiscountReasonDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public DiscountReasonDto() {
    }

}

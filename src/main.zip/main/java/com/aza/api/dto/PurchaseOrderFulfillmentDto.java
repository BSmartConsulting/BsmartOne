package com.aza.api.dto;

import com.aza.api.dto.masterData.*;
import com.aza.api.model.*;
import com.aza.api.service.PurchaseOrderService;
import com.aza.api.util.BeanUtil;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PurchaseOrderFulfillmentDto extends BaseEntity implements Serializable {

    private static PurchaseOrderService purchaseOrderService = BeanUtil.getBean(PurchaseOrderService.class);

    private Long id;
    private PurchaseOrderDto purchaseOrder;
    private LocalDateTime appointmentDate;
    private PurchaseOrderFulfillmentStatusDto purchaseOrderFulfillmentStatus;
    private Double executedHours;
    private ServiceTypeDto serviceType;
    private LocalDateTime reportApprovalDate;
    private String invoiceNumber;
    private Double billedHours;
    private Long invoiceStatus;
    private PurchaseOrderRejectionReasonDto purchaseOrderRejectionReason;
    private Double transportationExpenses;
    private Double travelExpenses;
    private boolean requiresSupport;
    private boolean requiresReport;
    private boolean hasBankOfHours;
    private String cicleName;
    private CityDto fulfillmentCityOfOrigin;
    private CityDto fulfillmentDestinationCity;
    private boolean requiresTransport;
    private boolean requireIntercityTransport;
    private boolean requireSpecialTransport;
    private boolean requireTravelExpenses;
    private boolean requireDeliverySupport;
    private boolean requireVisitSupport;
    private boolean requireEvaluationSupport;
    private boolean requireTrainingSupport;
    private boolean reviewedByConsultant;
    private UserDto user;
    private String observation;
    private String rejectionMotiveObservation;
    private CicleDto reportCicle;
    private CicleDto approveCicle;
    private CicleDto billingCicle;
    private CicleDto settlementCicle;
    private Double arlBillingRate;
    private Double azaSettlementRate;
    private LocalDate bankOfHoursRequestDate;
    private LocalDate bankOfHoursPaymentDate;
    private Double travelExpensesSsettlementValue;
    private Double transportexpensessettlementvalue;
    private Double settlementhours;
    private Boolean customsettlementvalues;
    private String coodinator;
    private String supportconsultant;
    private String customsettlementvaluesobservation;
    
    public static PurchaseOrderFulfillment PurchaseOrderFulfillmentDtoToPurchaseOrderFulfillment(PurchaseOrderFulfillmentDto recordDto,
            Map<Long, CompanyDto> companyMap, Map<Long, ProductDto> productMap, Map<Long, TaskDto> taskMap, Map<Long, ClasificationDto> clasificationMap,
            Map<Long, UserDto> userMap, Map<Long, CityDto> cityMap, Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap, Map<Long, ARLDto> arlMap
    ) {
        for (PurchaseOrder p : purchaseOrderService.getAllActive()) {
            if (p.getPurchaseOrderNumber().equalsIgnoreCase(recordDto.getPurchaseOrder().getPurchaseOrderNumber())) {
                recordDto.setPurchaseOrder(PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(p,
                        companyMap, productMap, taskMap, clasificationMap, userMap, cityMap, purchaseOrderStatusMap, arlMap));
                break;
            }
        }
        return PurchaseOrderFulfillment.builder()
                .id(recordDto.getId())
                .purchaseOrder(recordDto.getPurchaseOrder().getId())
                .appointmentDate(recordDto.getAppointmentDate())
                .purchaseOrderFulfillmentStatus(recordDto.getPurchaseOrderFulfillmentStatus().getId())
                .executedHours(recordDto.getExecutedHours())
                .serviceType(recordDto.getServiceType().getId())
                .reportApprovalDate(recordDto.getReportApprovalDate())
                .invoiceNumber(recordDto.getInvoiceNumber())
                .billedHours(recordDto.getBilledHours())
                .invoiceStatus(recordDto.getInvoiceStatus())
                .purchaseOrderRejectionReason(recordDto.getPurchaseOrderRejectionReason() != null ? recordDto.getPurchaseOrderRejectionReason().getId() : null)
                .transportationExpenses(recordDto.getTransportationExpenses())
                .travelExpenses(recordDto.getTravelExpenses())
                .requiresSupport(recordDto.isRequiresSupport())
                .requiresReport(recordDto.isRequiresReport())
                .hasBankOfHours(recordDto.isHasBankOfHours())
                .cicleName(recordDto.getCicleName())
                .fulfillmentCityOfOrigin(recordDto.getFulfillmentCityOfOrigin().getId())
                .fulfillmentDestinationCity(recordDto.getFulfillmentDestinationCity().getId())
                .requiresTransport(recordDto.isRequiresTransport())
                .requireIntercityTransport(recordDto.isRequireIntercityTransport())
                .requireSpecialTransport(recordDto.isRequireSpecialTransport())
                .requireTravelExpenses(recordDto.isRequireTravelExpenses())
                .requireDeliverySupport(recordDto.isRequireDeliverySupport())
                .requireVisitSupport(recordDto.isRequireVisitSupport())
                .requireEvaluationSupport(recordDto.isRequireEvaluationSupport())
                .requireTrainingSupport(recordDto.isRequireTrainingSupport())
                .reviewedByConsultant(recordDto.isReviewedByConsultant())
                .observation(recordDto.getObservation())
                .rejectionMotiveObservation(recordDto.getRejectionMotiveObservation())
                .user(recordDto.getUser().getId())
                .reportCicle(recordDto.getReportCicle() != null ? recordDto.getReportCicle().getId() : null)
                .approveCicle(recordDto.getApproveCicle() != null ? recordDto.getApproveCicle().getId() : null)
                .billingCicle(recordDto.getBillingCicle() != null ? recordDto.getBillingCicle().getId() : null)
                .settlementCicle(recordDto.getSettlementCicle() != null ? recordDto.getSettlementCicle().getId() : null)
                .arlBillingRate(recordDto.getArlBillingRate() != null ? recordDto.getArlBillingRate() : Double.valueOf("0"))
                .azaSettlementRate(recordDto.getAzaSettlementRate() != null ? recordDto.getAzaSettlementRate() : Double.valueOf("0"))
                .bankOfHoursPaymentDate(recordDto.getBankOfHoursPaymentDate() != null ? recordDto.getBankOfHoursPaymentDate() : null)
                .bankOfHoursRequestDate(recordDto.getBankOfHoursRequestDate() != null ? recordDto.getBankOfHoursRequestDate() : null)
                .travelExpensesSsettlementValue(recordDto.getTravelExpensesSsettlementValue() != null ? recordDto.getTravelExpensesSsettlementValue() : null)
                .transportexpensessettlementvalue(recordDto.getTransportexpensessettlementvalue()!= null ? recordDto.getTransportexpensessettlementvalue(): null)
                .settlementhours(recordDto.getSettlementhours()!= null ? recordDto.getSettlementhours(): null)
                .customsettlementvalues(recordDto.getCustomsettlementvalues()!= null ? recordDto.getCustomsettlementvalues(): false)
                .coodinator(recordDto.getCoodinator())
                .supportconsultant(recordDto.getSupportconsultant())
                .customsettlementvaluesobservation(recordDto.getCustomsettlementvaluesobservation()!= null ? recordDto.getCustomsettlementvaluesobservation(): "")
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    public static PurchaseOrderFulfillmentDto PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(PurchaseOrderFulfillment record,
            Map<Long, CompanyDto> companyMap, Map<Long, ProductDto> productMap, Map<Long, TaskDto> taskMap, Map<Long, ClasificationDto> clasificationMap,
            Map<Long, UserDto> userMap, Map<Long, CityDto> cityMap, Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap, Map<Long, ARLDto> arlMap,
            Map<Long, PurchaseOrderDto> purchaseOrderMap, Map<Long, PurchaseOrderFulfillmentStatusDto> purchaseOrderFulfillmentStatusMap,
            Map<Long, ServiceTypeDto> serviceTypeMap, Map<Long, PurchaseOrderRejectionReasonDto> purchaseOrderRejectionReasonMap, Map<Long, DiscountReasonDto> discountReasonMap,
            Map<Long, CicleDto> cicleMap) {
        CityDto cityOfOrigin = cityMap.getOrDefault(record.getFulfillmentCityOfOrigin(), new CityDto());
        CityDto destinationCity = cityMap.getOrDefault(record.getFulfillmentDestinationCity(), new CityDto());

        PurchaseOrderDto purchaseOrder = purchaseOrderMap.getOrDefault(record.getPurchaseOrder(), new PurchaseOrderDto());
        PurchaseOrderFulfillmentStatusDto purchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatusMap.getOrDefault(record.getPurchaseOrderFulfillmentStatus(), new PurchaseOrderFulfillmentStatusDto());
        ServiceTypeDto serviceType = serviceTypeMap.getOrDefault(record.getServiceType(), new ServiceTypeDto());
        PurchaseOrderRejectionReasonDto purchaseOrderRejectionReason = purchaseOrderRejectionReasonMap.getOrDefault(record.getPurchaseOrderRejectionReason(), new PurchaseOrderRejectionReasonDto());
        UserDto fulfillmentUser = userMap.getOrDefault(record.getUser(), new UserDto());

        CicleDto reportCicle = cicleMap.getOrDefault(record.getReportCicle(), new CicleDto());
        CicleDto approveCicle = cicleMap.getOrDefault(record.getApproveCicle(), new CicleDto());
        CicleDto billingCicle = cicleMap.getOrDefault(record.getBillingCicle(), new CicleDto());
        CicleDto settlementCicle = cicleMap.getOrDefault(record.getSettlementCicle(), new CicleDto());

        return PurchaseOrderFulfillmentDto.builder()
                .id(record.getId())
                .purchaseOrder(purchaseOrder)
                .appointmentDate(record.getAppointmentDate())
                .purchaseOrderFulfillmentStatus(purchaseOrderFulfillmentStatus)
                .executedHours(record.getExecutedHours())
                .serviceType(serviceType)
                .reportApprovalDate(record.getReportApprovalDate())
                .invoiceNumber(record.getInvoiceNumber())
                .billedHours(record.getBilledHours())
                .invoiceStatus(record.getInvoiceStatus())
                .purchaseOrderRejectionReason(purchaseOrderRejectionReason)
                .transportationExpenses(record.getTransportationExpenses())
                .travelExpenses(record.getTravelExpenses())
                .requiresReport(record.isRequiresReport())
                .requiresSupport(record.isRequiresSupport())
                .hasBankOfHours(record.isHasBankOfHours())
                .cicleName(record.getCicleName())
                .fulfillmentCityOfOrigin(cityOfOrigin)
                .fulfillmentDestinationCity(destinationCity)
                .requiresTransport(record.isRequiresTransport())
                .requireIntercityTransport(record.isRequireIntercityTransport())
                .requireSpecialTransport(record.isRequireSpecialTransport())
                .requireTravelExpenses(record.isRequireTravelExpenses())
                .requireDeliverySupport(record.isRequireDeliverySupport())
                .requireVisitSupport(record.isRequireVisitSupport())
                .requireEvaluationSupport(record.isRequireEvaluationSupport())
                .requireTrainingSupport(record.isRequireTrainingSupport())
                .reviewedByConsultant(record.isReviewedByConsultant())
                .observation(record.getObservation())
                .rejectionMotiveObservation(record.getRejectionMotiveObservation())
                .user(fulfillmentUser)
                .reportCicle(reportCicle)
                .approveCicle(approveCicle)
                .billingCicle(billingCicle)
                .settlementCicle(settlementCicle)
                .arlBillingRate(record.getArlBillingRate() != null ? record.getArlBillingRate() : Double.valueOf("0"))
                .azaSettlementRate(record.getAzaSettlementRate() != null ? record.getAzaSettlementRate() : Double.valueOf("0"))
                .bankOfHoursPaymentDate(record.getBankOfHoursPaymentDate() != null ? record.getBankOfHoursPaymentDate() : null)
                .bankOfHoursPaymentDate(record.getBankOfHoursPaymentDate() != null ? record.getBankOfHoursPaymentDate() : null)
                .travelExpensesSsettlementValue(record.getTravelExpensesSsettlementValue() != null ? record.getTravelExpensesSsettlementValue() : null)
                .transportexpensessettlementvalue(record.getTransportexpensessettlementvalue()!= null ? record.getTransportexpensessettlementvalue(): null)
                .settlementhours(record.getSettlementhours()!= null ? record.getSettlementhours(): null)
                .customsettlementvalues(record.getCustomsettlementvalues()!=null ? record.getCustomsettlementvalues() : false)
                .coodinator(record.getCoodinator())
                .supportconsultant(record.getSupportconsultant())
                .customsettlementvaluesobservation(record.getCustomsettlementvaluesobservation()!= null ? record.getCustomsettlementvaluesobservation(): "")
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public PurchaseOrderFulfillmentDto() {
    }

    @Builder
    public PurchaseOrderFulfillmentDto(Long id, PurchaseOrderDto purchaseOrder, LocalDateTime appointmentDate, PurchaseOrderFulfillmentStatusDto purchaseOrderFulfillmentStatus, Double executedHours, ServiceTypeDto serviceType, LocalDateTime reportApprovalDate, String invoiceNumber, Double billedHours, Long invoiceStatus, PurchaseOrderRejectionReasonDto purchaseOrderRejectionReason, Double transportationExpenses, Double travelExpenses, boolean requiresSupport, boolean requiresReport, boolean hasBankOfHours, String cicleName, CityDto fulfillmentCityOfOrigin, CityDto fulfillmentDestinationCity, boolean requiresTransport, boolean requireIntercityTransport, boolean requireSpecialTransport, boolean requireTravelExpenses, boolean requireDeliverySupport, boolean requireVisitSupport, boolean requireEvaluationSupport, boolean requireTrainingSupport, boolean reviewedByConsultant, UserDto user, String observation, String rejectionMotiveObservation, CicleDto reportCicle, CicleDto approveCicle, CicleDto billingCicle, CicleDto settlementCicle, Double arlBillingRate, Double azaSettlementRate, LocalDate bankOfHoursRequestDate, LocalDate bankOfHoursPaymentDate, Double travelExpensesSsettlementValue, Double transportexpensessettlementvalue, Double settlementhours, Boolean customsettlementvalues, String coodinator, String supportconsultant, String customsettlementvaluesobservation, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.purchaseOrder = purchaseOrder;
        this.appointmentDate = appointmentDate;
        this.purchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatus;
        this.executedHours = executedHours;
        this.serviceType = serviceType;
        this.reportApprovalDate = reportApprovalDate;
        this.invoiceNumber = invoiceNumber;
        this.billedHours = billedHours;
        this.invoiceStatus = invoiceStatus;
        this.purchaseOrderRejectionReason = purchaseOrderRejectionReason;
        this.transportationExpenses = transportationExpenses;
        this.travelExpenses = travelExpenses;
        this.requiresSupport = requiresSupport;
        this.requiresReport = requiresReport;
        this.hasBankOfHours = hasBankOfHours;
        this.cicleName = cicleName;
        this.fulfillmentCityOfOrigin = fulfillmentCityOfOrigin;
        this.fulfillmentDestinationCity = fulfillmentDestinationCity;
        this.requiresTransport = requiresTransport;
        this.requireIntercityTransport = requireIntercityTransport;
        this.requireSpecialTransport = requireSpecialTransport;
        this.requireTravelExpenses = requireTravelExpenses;
        this.requireDeliverySupport = requireDeliverySupport;
        this.requireVisitSupport = requireVisitSupport;
        this.requireEvaluationSupport = requireEvaluationSupport;
        this.requireTrainingSupport = requireTrainingSupport;
        this.reviewedByConsultant = reviewedByConsultant;
        this.user = user;
        this.observation = observation;
        this.rejectionMotiveObservation = rejectionMotiveObservation;
        this.reportCicle = reportCicle;
        this.approveCicle = approveCicle;
        this.billingCicle = billingCicle;
        this.settlementCicle = settlementCicle;
        this.arlBillingRate = arlBillingRate;
        this.azaSettlementRate = azaSettlementRate;
        this.bankOfHoursRequestDate = bankOfHoursRequestDate;
        this.bankOfHoursPaymentDate = bankOfHoursPaymentDate;
        this.travelExpensesSsettlementValue = travelExpensesSsettlementValue;
        this.transportexpensessettlementvalue = transportexpensessettlementvalue;
        this.settlementhours = settlementhours;
        this.customsettlementvalues = customsettlementvalues;
        this.coodinator = coodinator;
        this.supportconsultant = supportconsultant;
        this.customsettlementvaluesobservation = customsettlementvaluesobservation;
    }
    
}

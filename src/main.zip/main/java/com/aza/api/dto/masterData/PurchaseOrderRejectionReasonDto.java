/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.PurchaseOrderRejectionReason;
import com.aza.api.repository.masterData.PurchaseOrderRejectionReasonRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PurchaseOrderRejectionReasonDto extends CatalogEntity {

    private static PurchaseOrderRejectionReasonRepository PurchaseOrderRejectionReasonRepository = BeanUtil.getBean(PurchaseOrderRejectionReasonRepository.class);
    private Long id;

    public static PurchaseOrderRejectionReason getPurchaseOrderRejectionReasonDto(Long statusid) {
        Optional<PurchaseOrderRejectionReason> currentPurchaseOrderRejectionReason = PurchaseOrderRejectionReasonRepository.findById(statusid);
        PurchaseOrderRejectionReason result = null;
        if (currentPurchaseOrderRejectionReason.isPresent()) {
            result = currentPurchaseOrderRejectionReason.get();
        }
        return result;
    }

    public static PurchaseOrderRejectionReasonDto PurchaseOrderRejectionReasonToPurchaseOrderRejectionReasonDto(PurchaseOrderRejectionReason record) {
        return PurchaseOrderRejectionReasonDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static PurchaseOrderRejectionReason PurchaseOrderRejectionReasonDtoToPurchaseOrderRejectionReason(PurchaseOrderRejectionReasonDto recordDto) {
        return PurchaseOrderRejectionReason.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public PurchaseOrderRejectionReasonDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public PurchaseOrderRejectionReasonDto() {
    }

}

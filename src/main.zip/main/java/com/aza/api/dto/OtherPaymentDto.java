package com.aza.api.dto;

import com.aza.api.dto.masterData.*;
import com.aza.api.model.*;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.OtherPaymentTypeService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.BeanUtil;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class OtherPaymentDto extends BaseEntity implements Serializable {

    private static UserService userService = BeanUtil.getBean(UserService.class);
    private static OtherPaymentTypeService otherPaymentTypeService = BeanUtil.getBean(OtherPaymentTypeService.class);
    private static CicleService cicleService = BeanUtil.getBean(CicleService.class);

    private Long id;
    private UserDto user;
    private OtherPaymentTypeDto otherPaymentType;
    private CicleDto settlementCicle;
    private Long amount;

    public static OtherPayment OtherPaymentDtoToOtherPayment(OtherPaymentDto record) {
        return OtherPayment.builder()
                .id(record.getId())
                .otherpaymenttype(record.getOtherPaymentType()!=null ? record.getOtherPaymentType().getId(): null)
                .settlementCicle(record.getSettlementCicle()!=null ? record.getSettlementCicle().getId():null)
                .user(record.getUser()!=null ? record.getUser().getId():null)
                .amount(record.getAmount())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static OtherPaymentDto OtherPaymentToOtherPaymentDto(OtherPayment record,
            Map<Long, UserDto> userMap,
            Map<Long, CicleDto> cicleMap,
            Map<Long, OtherPaymentTypeDto> otherPaymentTypeMap) {

        // Luego puedes usar estos mapas para asignar los DTOs
        CicleDto settlementCicle = cicleMap.getOrDefault(record.getSettlementCicle(), new CicleDto());
        OtherPaymentTypeDto otherPaymentType = otherPaymentTypeMap.getOrDefault(record.getOtherpaymenttype(), new OtherPaymentTypeDto());
        UserDto user = userMap.getOrDefault(record.getUser(), new UserDto());
        return OtherPaymentDto.builder()
                .id(record.getId())
                .otherPaymentTypeDto(otherPaymentType)
                .settlementCicle(settlementCicle)
                .user(user)
                .amount(record.getAmount())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public OtherPaymentDto() {
    }

    @Builder
    public OtherPaymentDto(Long id, UserDto user, OtherPaymentTypeDto otherPaymentTypeDto, CicleDto settlementCicle, Long amount, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.user = user;
        this.otherPaymentType = otherPaymentTypeDto;
        this.settlementCicle = settlementCicle;
        this.amount = amount;
    }

}

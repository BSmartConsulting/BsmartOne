/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.CicleType;
import com.aza.api.repository.masterData.CicleTypeRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CicleTypeDto extends CatalogEntity {

    private static CicleTypeRepository CicleTypeRepository = BeanUtil.getBean(CicleTypeRepository.class);
    private Long id;

    public static CicleType getCicleTypeDto(Long statusid) {
        Optional<CicleType> currentCicleType = CicleTypeRepository.findById(statusid);
        CicleType result = null;
        if (currentCicleType.isPresent()) {
            result = currentCicleType.get();
        }
        return result;
    }

    public static CicleTypeDto CicleTypeToCicleTypeDto(CicleType record) {
        return CicleTypeDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static CicleType CicleTypeDtoToCicleType(CicleTypeDto recordDto) {
        return CicleType.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public CicleTypeDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public CicleTypeDto() {
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.Profile;
import com.aza.api.repository.masterData.ProfileRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProfileDto extends CatalogEntity {

    private static ProfileRepository profileRepository = BeanUtil.getBean(ProfileRepository.class);
    private Long id;
    private String type;

    public static Profile getProfileDto(Long statusid) {
        Optional<Profile> currentProfile = profileRepository.findById(statusid);
        Profile result = null;
        if (currentProfile.isPresent()) {
            result = currentProfile.get();
        }
        return result;
    }

    public static ProfileDto ProfileToProfileDto(Profile record) {
        return ProfileDto.builder()
                .id(record.getId())
                .type(record.getType())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static Profile ProfileDtoToProfile(ProfileDto recordDto) {
        return Profile.builder()
                .id(recordDto.getId())
                .type(recordDto.getType())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public ProfileDto(Long id, String type, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.type = type;
    }

    public ProfileDto() {
    }

}

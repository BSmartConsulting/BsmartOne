/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.*;
import com.aza.api.model.masterData.UserRate;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.ProfileService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.BeanUtil;
import com.aza.api.util.GlobalExceptionHandler;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class UserRateDto extends BaseEntity implements Serializable {

    private Long id;
    private ProfileDto profile;
    private String rateType;
    private double rateValue;
    private LocalDateTime startdate;
    private LocalDateTime enddate;
    private UserDto user;
    private ARLDto arl;
    private boolean approved;

    private static UserService userService = BeanUtil.getBean(UserService.class);
    private static ARLService arlService = BeanUtil.getBean(ARLService.class);
    private static ProfileService profileService = BeanUtil.getBean(ProfileService.class);

    public static UserRate UserRateDtoToUserRate(UserRateDto recordDto) {
        try {
            UserRate profileRate = UserRate.builder()
                    .id(recordDto.getId())
                    .profileid(recordDto.getProfile().getId())
                    .ratetype(recordDto.getRateType())
                    .ratevalue(recordDto.getRateValue())
                    .userid(recordDto.getUser().getId())
                    .arlid(recordDto.getArl().getId())
                    .startdate(recordDto.getStartdate())
                    .enddate(recordDto.getEnddate())
                    .creationDate(recordDto.getCreationDate())
                    .approved(recordDto.isApproved())
                    .lastUpdatedDate(recordDto.getLastUpdatedDate())
                    .createdBy(recordDto.getCreatedBy())
                    .lastUpdatedBy(recordDto.getLastUpdatedBy())
                    .deleted(recordDto.getDeleted())
                    .build();
            return profileRate;
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            System.out.println("ERROR AL CARGAR LA TARIFA DTO->MODEL: " + recordDto.toString() + "\n Error: " + e.getMessage());
            return null;
        }

    }

    public static UserRateDto UserRateToUserRateDto(UserRate record) {
        try {
            UserDto currentUserDto = UserDto.UserToUserDto(userService.findById(record.getUserid()).get());
            ARLDto currentArlDto = ARLDto.ARLToARLDto(arlService.findById(record.getArlid()));
            ProfileDto profileDto = ProfileDto.ProfileToProfileDto(profileService.findById(record.getProfileid()));
            UserRateDto profileRatedto = UserRateDto.builder()
                    .id(record.getId())
                    .profile(profileDto)
                    .rateType(record.getRatetype())
                    .rateValue(record.getRatevalue())
                    .user(currentUserDto)
                    .arl(currentArlDto)
                    .startdate(record.getStartdate())
                    .enddate(record.getEnddate())
                    .creationDate(record.getCreationDate())
                    .approved(record.isApproved())
                    .lastUpdatedDate(record.getLastUpdatedDate())
                    .createdBy(record.getCreatedBy())
                    .lastUpdatedBy(record.getLastUpdatedBy())
                    .deleted(record.getDeleted())
                    .build();
            return profileRatedto;
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            System.out.println("ERROR AL CARGAR LA TARIFA MODEL->DTO: " + record.toString() + "\n Error: " + e.getMessage());
            return null;

        }
    }

    public UserRateDto() {
    }

    @Builder
    public UserRateDto(Long id, ProfileDto profile, String rateType, double rateValue, LocalDateTime startdate, LocalDateTime enddate, UserDto user, ARLDto arl, boolean approved, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.profile = profile;
        this.rateType = rateType;
        this.rateValue = rateValue;
        this.startdate = startdate;
        this.enddate = enddate;
        this.user = user;
        this.arl = arl;
        this.approved = approved;
    }

}

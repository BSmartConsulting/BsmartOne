package com.aza.api.dto;

import com.aza.api.dto.masterData.*;
import com.aza.api.model.*;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.CityService;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.BeanUtil;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PurchaseOrderDto extends BaseEntity implements Serializable {

    private static CompanyService companyService = BeanUtil.getBean(CompanyService.class);
    private static ProductService productService = BeanUtil.getBean(ProductService.class);
    private static ClasificationService clasificationService = BeanUtil.getBean(ClasificationService.class);
    private static TaskService taskService = BeanUtil.getBean(TaskService.class);
    private static UserService userService = BeanUtil.getBean(UserService.class);
    private static CityService cityService = BeanUtil.getBean(CityService.class);
    private static PurchaseOrderStatusService purchaseOrderStatusService = BeanUtil.getBean(PurchaseOrderStatusService.class);
    private static ARLService arlService = BeanUtil.getBean(ARLService.class);

    private Long id;
    private String purchaseOrderNumber;
    private CompanyDto company;
    private ProductDto product;
    private TaskDto task;
    private ClasificationDto clasification;
    private UserDto user;
    private LocalDateTime approvalDate;
    private CityDto cityOfOrigin;
    private CityDto destinationCity;
    private PurchaseOrderStatusDto purchaseOrderStatus;
    private Double requestedHours;
    private Double executedhours;
    private Double availablehours;
    private ARLDto arl;
    private String observation;
    private boolean requiresReport;
    private boolean customPurchaseOrderRate;
    private Double customPurchaseOrderRateValue;

    
private boolean requiresTransportation;

    public static PurchaseOrder PurchaseOrderDtoToPurchaseOrder(PurchaseOrderDto recordDto) {
        return PurchaseOrder.builder()
                .id(recordDto.getId())
                .purchaseOrderNumber(recordDto.getPurchaseOrderNumber())
                .company(recordDto.getCompany().getId())
                .product(recordDto.getProduct().getId())
                .task(recordDto.getTask().getId())
                .clasification(recordDto.getClasification().getId())
                .user(recordDto.getUser().getId())
                .approvalDate(recordDto.getApprovalDate())
                .cityOfOrigin(recordDto.getCityOfOrigin().getId())
                .destinationCity(recordDto.getDestinationCity().getId())
                .purchaseOrderStatus(recordDto.getPurchaseOrderStatus().getId())
                .requestedHours(recordDto.getRequestedHours())
                .executedhours(recordDto.getExecutedhours())
                .availablehours(recordDto.getAvailablehours())
                .arl(recordDto.getArl().getId())
                .observation(recordDto.getObservation())
                .requiresTransportation(recordDto.isRequiresTransportation())
                .requiresReport(recordDto.isRequiresReport())
                .creationDate(recordDto.getCreationDate())
                .customPurchaseOrderRate(recordDto != null? Boolean.TRUE.equals(recordDto.isCustomPurchaseOrderRate()) : false)
                .customPurchaseOrderRateValue(recordDto.getCustomPurchaseOrderRateValue()!=null ?recordDto.getCustomPurchaseOrderRateValue():Double.valueOf("0"))
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    public static PurchaseOrderDto PurchaseOrderToPurchaseOrderDto(PurchaseOrder record, Map<Long, CompanyDto> companyMap,
            Map<Long, ProductDto> productMap, Map<Long, TaskDto> taskMap, Map<Long, ClasificationDto> clasificationMap,
            Map<Long, UserDto> userMap, Map<Long, CityDto> cityMap, Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap, Map<Long, ARLDto> arlMap) {

        // Luego puedes usar estos mapas para asignar los DTOs
        CompanyDto company = companyMap.getOrDefault(record.getCompany(), new CompanyDto());
        ProductDto product = productMap.getOrDefault(record.getProduct(), new ProductDto());
        TaskDto task = taskMap.getOrDefault(record.getTask(), new TaskDto());
        ClasificationDto clasification = clasificationMap.getOrDefault(record.getClasification(), new ClasificationDto());
        UserDto user = userMap.getOrDefault(record.getUser(), new UserDto());
        CityDto cityOfOrigin = cityMap.getOrDefault(record.getCityOfOrigin(), new CityDto());
        CityDto destinationCity = cityMap.getOrDefault(record.getDestinationCity(), new CityDto());
        ARLDto arl = arlMap.getOrDefault(record.getArl(), new ARLDto());
        PurchaseOrderStatusDto purchaseOrderStatus = purchaseOrderStatusMap.getOrDefault(record.getPurchaseOrderStatus(), new PurchaseOrderStatusDto());
        return PurchaseOrderDto.builder()
                .id(record.getId())
                .purchaseOrderNumber(record.getPurchaseOrderNumber())
                .company(company)
                .product(product)
                .task(task)
                .clasification(clasification)
                .user(user)
                .approvalDate(record.getApprovalDate())
                .cityOfOrigin(cityOfOrigin)
                .destinationCity(destinationCity)
                .purchaseOrderStatus(purchaseOrderStatus)
                .requestedHours(record.getRequestedHours())
                .executedhours(record.getExecutedhours())
                .availablehours(record.getAvailablehours())
                .arl(arl)
                .observation(record.getObservation())
                .requiresTransportation(record.isRequiresTransportation())
                .requiresReport(record.isRequiresReport())
                .customPurchaseOrderRate(record != null? Boolean.TRUE.equals(record.isCustomPurchaseOrderRate()) : false)
                .customPurchaseOrderRateValue(record.getCustomPurchaseOrderRateValue()!=null ?record.getCustomPurchaseOrderRateValue():Double.valueOf("0"))
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public PurchaseOrderDto() {
    }

    @Builder
    public PurchaseOrderDto(Long id, String purchaseOrderNumber, CompanyDto company, ProductDto product, TaskDto task, ClasificationDto clasification, UserDto user, LocalDateTime approvalDate, CityDto cityOfOrigin, CityDto destinationCity, PurchaseOrderStatusDto purchaseOrderStatus, Double requestedHours, Double executedhours, Double availablehours, ARLDto arl, String observation, boolean requiresReport, boolean customPurchaseOrderRate, Double customPurchaseOrderRateValue, boolean requiresTransportation, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.purchaseOrderNumber = purchaseOrderNumber;
        this.company = company;
        this.product = product;
        this.task = task;
        this.clasification = clasification;
        this.user = user;
        this.approvalDate = approvalDate;
        this.cityOfOrigin = cityOfOrigin;
        this.destinationCity = destinationCity;
        this.purchaseOrderStatus = purchaseOrderStatus;
        this.requestedHours = requestedHours;
        this.executedhours = executedhours;
        this.availablehours = availablehours;
        this.arl = arl;
        this.observation = observation;
        this.requiresReport = requiresReport;
        this.customPurchaseOrderRate = customPurchaseOrderRate;
        this.customPurchaseOrderRateValue = customPurchaseOrderRateValue;
        this.requiresTransportation = requiresTransportation;
    }

}

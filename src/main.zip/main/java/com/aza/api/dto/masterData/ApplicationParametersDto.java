/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.BaseEntity;
import com.aza.api.model.masterData.ApplicationParameters;
import com.aza.api.repository.masterData.ApplicationParametersRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ApplicationParametersDto extends BaseEntity {

    private static ApplicationParametersRepository applicationParametersRepository = BeanUtil.getBean(ApplicationParametersRepository.class);
    private Long id;

    private Long parametername;
    private String parametervalue;
    private String description;

    public static ApplicationParameters getApplicationParametersDto(Long id) {
        Optional<ApplicationParameters> currentApplicationParameters = applicationParametersRepository.findById(id);
        ApplicationParameters result = null;
        if (currentApplicationParameters.isPresent()) {
            result = currentApplicationParameters.get();
        }
        return result;
    }

    public static ApplicationParametersDto ApplicationParametersToApplicationParametersDto(ApplicationParameters record) {
        return ApplicationParametersDto.builder()
                .id(record.getId())
                .parametername(record.getParametername())
                .parametervalue(record.getParametervalue())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static ApplicationParameters ApplicationParametersDtoToApplicationParameters(ApplicationParametersDto record) {
        return ApplicationParameters.builder()
                .id(record.getId())
                .parametername(record.getParametername())
                .parametervalue(record.getParametervalue())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public ApplicationParametersDto() {
    }

    @Builder
    public ApplicationParametersDto(Long id, Long parametername, String parametervalue, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.parametername = parametername;
        this.parametervalue = parametervalue;
        this.description = description;
    }

}

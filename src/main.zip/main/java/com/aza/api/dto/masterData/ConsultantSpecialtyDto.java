/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.ConsultantSpecialty;
import com.aza.api.repository.masterData.ConsultantSpecialtyRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultantSpecialtyDto extends CatalogEntity {

    private static ConsultantSpecialtyRepository ConsultantSpecialtyRepository = BeanUtil.getBean(ConsultantSpecialtyRepository.class);
    private Long id;

    public static ConsultantSpecialty getConsultantSpecialtyDto(Long statusid) {
        Optional<ConsultantSpecialty> currentConsultantSpecialty = ConsultantSpecialtyRepository.findById(statusid);
        ConsultantSpecialty result = null;
        if (currentConsultantSpecialty.isPresent()) {
            result = currentConsultantSpecialty.get();
        }
        return result;
    }

    public static ConsultantSpecialtyDto ConsultantSpecialtyToConsultantSpecialtyDto(ConsultantSpecialty record) {
        return ConsultantSpecialtyDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static ConsultantSpecialty ConsultantSpecialtyDtoToConsultantSpecialty(ConsultantSpecialtyDto recordDto) {
        return ConsultantSpecialty.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public ConsultantSpecialtyDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public ConsultantSpecialtyDto() {
    }

}

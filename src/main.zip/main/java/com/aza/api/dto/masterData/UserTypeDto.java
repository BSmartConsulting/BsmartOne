/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.UserType;
import com.aza.api.repository.masterData.UserTypeRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class UserTypeDto extends CatalogEntity {

    private static UserTypeRepository userTypeRepository = BeanUtil.getBean(UserTypeRepository.class);
    private Long id;

    public static UserType getUserTypeDto(Long statusid) {
        Optional<UserType> currentUserType = userTypeRepository.findById(statusid);
        UserType result = null;
        if (currentUserType.isPresent()) {
            result = currentUserType.get();
        } else {
            currentUserType = userTypeRepository.findByCode("EMPLEADO");
            if (currentUserType.isPresent()) {
                result = currentUserType.get();
            }
        }
        return result;
    }

    public static UserTypeDto UserTypeToUserTypeDto(UserType record) {
        return UserTypeDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static UserType UserTypeDtoToUserType(UserTypeDto recordDto) {
        return UserType.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public UserTypeDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public UserTypeDto() {
    }

}

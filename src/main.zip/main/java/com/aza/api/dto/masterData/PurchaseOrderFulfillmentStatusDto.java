/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.PurchaseOrderFulfillmentStatus;
import com.aza.api.repository.masterData.PurchaseOrderFulfillmentStatusRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PurchaseOrderFulfillmentStatusDto extends CatalogEntity {

    private static PurchaseOrderFulfillmentStatusRepository PurchaseOrderFulfillmentStatusRepository = BeanUtil.getBean(PurchaseOrderFulfillmentStatusRepository.class);
    private Long id;

    public static PurchaseOrderFulfillmentStatus getPurchaseOrderFulfillmentStatusDto(Long statusid) {
        Optional<PurchaseOrderFulfillmentStatus> currentPurchaseOrderFulfillmentStatus = PurchaseOrderFulfillmentStatusRepository.findById(statusid);
        PurchaseOrderFulfillmentStatus result = null;
        if (currentPurchaseOrderFulfillmentStatus.isPresent()) {
            result = currentPurchaseOrderFulfillmentStatus.get();
        }
        return result;
    }

    public static PurchaseOrderFulfillmentStatusDto PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(PurchaseOrderFulfillmentStatus record) {
        return PurchaseOrderFulfillmentStatusDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static PurchaseOrderFulfillmentStatus PurchaseOrderFulfillmentStatusDtoToPurchaseOrderFulfillmentStatus(PurchaseOrderFulfillmentStatusDto recordDto) {
        return PurchaseOrderFulfillmentStatus.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public PurchaseOrderFulfillmentStatusDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public PurchaseOrderFulfillmentStatusDto() {
    }

}

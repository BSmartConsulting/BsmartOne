/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.*;
import com.aza.api.model.masterData.ARL;
import com.aza.api.model.masterData.Clasification;
import com.aza.api.model.masterData.ClasificationSupport;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ClasificationSupportDto extends BaseEntity implements Serializable {

    private Long id;
    private ClasificationDto clasification;
    private ARLDto arl;
    private boolean requiresVisitSupport;
    private boolean requiresDeliverySupport;
    private boolean requiresTrainingSupport;
    private boolean requiresEvaluationSupport;

    public static ClasificationSupport ClasificationSupportDtoToClasificationSupport(ClasificationSupportDto recordDto) {
        Clasification clasification = ClasificationDto.ClasificationDtoToClasification(recordDto.getClasification());
        ARL arl = ARLDto.ARLDtoToARL(recordDto.getArl());
        ClasificationSupport current = ClasificationSupport.builder()
                .id(recordDto.getId())
                .arl(arl.getId())
                .clasification(clasification.getId())
                .requiresDeliverySupport(recordDto.isRequiresDeliverySupport())
                .requiresEvaluationSupport(recordDto.isRequiresEvaluationSupport())
                .requiresVisitSupport(recordDto.isRequiresVisitSupport())
                .requiresTrainingSupport(recordDto.isRequiresTrainingSupport())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
        return current;
    }

    public static ClasificationSupportDto ClasificationSupportToClasificationSupportDto(ClasificationSupport record) {
        ClasificationDto clasificationDto = ClasificationDto.ClasificationToClasificationDto(ClasificationDto.getClasificationDto(record.getClasification()));
        ARLDto arlDto = ARLDto.ARLToARLDto(ARLDto.getARLDto(record.getArl()));
        ClasificationSupportDto current = ClasificationSupportDto.builder()
                .id(record.getId())
                .arl(arlDto)
                .clasification(clasificationDto)
                .requiresDeliverySupport(record.isRequiresDeliverySupport())
                .requiresEvaluationSupport(record.isRequiresEvaluationSupport())
                .requiresVisitSupport(record.isRequiresVisitSupport())
                .requiresTrainingSupport(record.isRequiresTrainingSupport())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
        return current;
    }

    public ClasificationSupportDto() {
    }

    @Builder
    public ClasificationSupportDto(Long id, ClasificationDto clasification, ARLDto arl, boolean requiresVisitSupport, boolean requiresDeliverySupport, boolean requiresTrainingSupport, boolean requiresEvaluationSupport, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.clasification = clasification;
        this.arl = arl;
        this.requiresVisitSupport = requiresVisitSupport;
        this.requiresDeliverySupport = requiresDeliverySupport;
        this.requiresTrainingSupport = requiresTrainingSupport;
        this.requiresEvaluationSupport = requiresEvaluationSupport;
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.ConsultantStatus;
import com.aza.api.repository.masterData.ConsultantStatusRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultantStatusDto extends CatalogEntity {

    private static ConsultantStatusRepository ConsultantStatusRepository = BeanUtil.getBean(ConsultantStatusRepository.class);
    private Long id;

    public static ConsultantStatus getConsultantStatusDto(Long statusid) {
        Optional<ConsultantStatus> currentConsultantStatus = ConsultantStatusRepository.findById(statusid);
        ConsultantStatus result = null;
        if (currentConsultantStatus.isPresent()) {
            result = currentConsultantStatus.get();
        }
        return result;
    }

    public static ConsultantStatusDto ConsultantStatusToConsultantStatusDto(ConsultantStatus record) {
        return ConsultantStatusDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static ConsultantStatus ConsultantStatusDtoToConsultantStatus(ConsultantStatusDto recordDto) {
        return ConsultantStatus.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public ConsultantStatusDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public ConsultantStatusDto() {
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.ServiceType;
import com.aza.api.repository.masterData.ServiceTypeRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ServiceTypeDto extends CatalogEntity {

    private static ServiceTypeRepository ServiceTypeRepository = BeanUtil.getBean(ServiceTypeRepository.class);
    private Long id;

    public static ServiceType getServiceTypeDto(Long statusid) {
        Optional<ServiceType> currentServiceType = ServiceTypeRepository.findById(statusid);
        ServiceType result = null;
        if (currentServiceType.isPresent()) {
            result = currentServiceType.get();
        }
        return result;
    }

    public static ServiceTypeDto ServiceTypeToServiceTypeDto(ServiceType record) {
        return ServiceTypeDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static ServiceType ServiceTypeDtoToServiceType(ServiceTypeDto recordDto) {
        return ServiceType.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public ServiceTypeDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public ServiceTypeDto() {
    }

}

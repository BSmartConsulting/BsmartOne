/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.*;
import com.aza.api.model.masterData.FrontEndMessage;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FrontEndMessageDto extends BaseEntity {

    private Long id;
    private String entity;
    private String messagekey;
    private String value_es;
    private String value_en;

    public static FrontEndMessage FrontEndMessageDtoToFrontEndMessage(FrontEndMessageDto recordDto) {
        FrontEndMessage frontEndMessage = FrontEndMessage.builder()
                .id(recordDto.getId())
                .entity(recordDto.getEntity())
                .messagekey(recordDto.getMessagekey())
                .value_es(recordDto.getValue_es())
                .value_en(recordDto.getValue_en())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
        return frontEndMessage;
    }

    public static FrontEndMessageDto FrontEndMessageToFrontEndMessageDto(FrontEndMessage record) {
        FrontEndMessageDto frontEndMessagedto = FrontEndMessageDto.builder()
                .id(record.getId())
                .entity(record.getEntity())
                .messagekey(record.getMessagekey())
                .value_es(record.getValue_es())
                .value_en(record.getValue_en())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
        return frontEndMessagedto;
    }

    public FrontEndMessageDto() {
    }

    @Builder

    public FrontEndMessageDto(Long id, String entity, String messagekey, String value_es, String value_en, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.entity = entity;
        this.messagekey = messagekey;
        this.value_es = value_es;
        this.value_en = value_en;
    }

}

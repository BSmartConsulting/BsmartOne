/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.dto.masterData;

import com.aza.api.model.CatalogEntity;
import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.repository.masterData.PurchaseOrderStatusRepository;
import com.aza.api.util.BeanUtil;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PurchaseOrderStatusDto extends CatalogEntity {

    private static PurchaseOrderStatusRepository PurchaseOrderStatusRepository = BeanUtil.getBean(PurchaseOrderStatusRepository.class);
    private Long id;

    public static PurchaseOrderStatus getPurchaseOrderStatusDto(Long statusid) {
        Optional<PurchaseOrderStatus> currentPurchaseOrderStatus = PurchaseOrderStatusRepository.findById(statusid);
        PurchaseOrderStatus result = null;
        if (currentPurchaseOrderStatus.isPresent()) {
            result = currentPurchaseOrderStatus.get();
        }
        return result;
    }

    public static PurchaseOrderStatusDto PurchaseOrderStatusToPurchaseOrderStatusDto(PurchaseOrderStatus record) {
        return PurchaseOrderStatusDto.builder()
                .id(record.getId())
                .code(record.getCode())
                .description(record.getDescription())
                .creationDate(record.getCreationDate())
                .lastUpdatedDate(record.getLastUpdatedDate())
                .createdBy(record.getCreatedBy())
                .lastUpdatedBy(record.getLastUpdatedBy())
                .deleted(record.getDeleted())
                .build();
    }

    public static PurchaseOrderStatus PurchaseOrderStatusDtoToPurchaseOrderStatus(PurchaseOrderStatusDto recordDto) {
        return PurchaseOrderStatus.builder()
                .id(recordDto.getId())
                .code(recordDto.getCode())
                .description(recordDto.getDescription())
                .creationDate(recordDto.getCreationDate())
                .lastUpdatedDate(recordDto.getLastUpdatedDate())
                .createdBy(recordDto.getCreatedBy())
                .lastUpdatedBy(recordDto.getLastUpdatedBy())
                .deleted(recordDto.getDeleted())
                .build();
    }

    @Builder
    public PurchaseOrderStatusDto(Long id, String code, String description, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(code, description, creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
    }

    public PurchaseOrderStatusDto() {
    }

}

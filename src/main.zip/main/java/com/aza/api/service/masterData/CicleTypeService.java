/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.CicleType;
import com.aza.api.repository.masterData.CicleTypeRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class CicleTypeService implements CicleTypeServiceInterface {

    @Autowired
    private CicleTypeRepository cicleTypeRepository;

    @Override
    public CicleType create(CicleType cicleType) {
        return cicleTypeRepository.save(cicleType);
        //return CicleTypeRepository.save(new CicleType(cicleType.getId(),cicleType.getCodigo(),cicleType.getDescripcion()));
    }

    @Override
    public List<CicleType> getAll() {
        return cicleTypeRepository.findAll();
    }

    @Override
    public void delete(CicleType cicleType) {
        cicleTypeRepository.delete(cicleType);
    }

    @Override
    public void deleteAll() {
        cicleTypeRepository.deleteAll();
    }

    @Override
    public CicleType findById(Long id) {
        return cicleTypeRepository.findById(id).get();
    }

    public List<CicleType> getAllActive() {
        return cicleTypeRepository.findAllByDeletedFalse();
    }

}

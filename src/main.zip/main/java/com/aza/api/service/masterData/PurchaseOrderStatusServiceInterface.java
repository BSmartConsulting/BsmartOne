/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.PurchaseOrderStatus;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface PurchaseOrderStatusServiceInterface {

    PurchaseOrderStatus create(PurchaseOrderStatus purchaseOrderStatus);

    void delete(PurchaseOrderStatus purchaseOrderStatus);

    void deleteAll();

    PurchaseOrderStatus findById(Long id);

    List<PurchaseOrderStatus> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.model.TransactionLog;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface TransactionLogServiceInterface {

    TransactionLog create(TransactionLog loadDataControl);

    void delete(TransactionLog loadDataControl);

    void deleteAll();

    Optional<TransactionLog> findById(Long id);

    List<TransactionLog> getAll();

}

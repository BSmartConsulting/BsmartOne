/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ServiceType;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ServiceTypeServiceInterface {

    ServiceType create(ServiceType serviceType);

    void delete(ServiceType serviceType);

    void deleteAll();

    ServiceType findById(Long id);

    List<ServiceType> getAll();

}

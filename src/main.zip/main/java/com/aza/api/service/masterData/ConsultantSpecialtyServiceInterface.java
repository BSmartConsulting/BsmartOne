/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ConsultantSpecialty;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ConsultantSpecialtyServiceInterface {

    ConsultantSpecialty create(ConsultantSpecialty consultantSpecialty);

    void delete(ConsultantSpecialty consultantSpecialty);

    void deleteAll();

    ConsultantSpecialty findById(Long id);

    List<ConsultantSpecialty> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.OtherPaymentType;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface OtherPaymentTypeServiceInterface {

    OtherPaymentType create(OtherPaymentType userType);

    void delete(OtherPaymentType userType);

    void deleteAll();

    Optional<OtherPaymentType> findById(Long id);

    List<OtherPaymentType> getAll();

}

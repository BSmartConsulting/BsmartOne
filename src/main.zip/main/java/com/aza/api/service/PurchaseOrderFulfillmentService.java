package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.PurchaseOrderDto;
import com.aza.api.dto.PurchaseOrderFulfillmentDto;
import com.aza.api.dto.masterData.ARLDto;
import com.aza.api.dto.masterData.CicleDto;
import com.aza.api.dto.masterData.CityDto;
import com.aza.api.dto.masterData.ClasificationDto;
import com.aza.api.dto.masterData.CompanyDto;
import com.aza.api.dto.masterData.DiscountReasonDto;
import com.aza.api.dto.masterData.ProductDto;
import com.aza.api.dto.masterData.PurchaseOrderFulfillmentStatusDto;
import com.aza.api.dto.masterData.PurchaseOrderRejectionReasonDto;
import com.aza.api.dto.masterData.PurchaseOrderStatusDto;
import com.aza.api.dto.masterData.ServiceTypeDto;
import com.aza.api.dto.masterData.TaskDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.PurchaseOrder;
import com.aza.api.model.PurchaseOrderFulfillment;
import com.aza.api.model.masterData.ARL;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.City;
import com.aza.api.model.masterData.Clasification;
import com.aza.api.model.masterData.Company;
import com.aza.api.model.masterData.DiscountReason;
import com.aza.api.model.masterData.Product;
import com.aza.api.model.masterData.PurchaseOrderFulfillmentStatus;
import com.aza.api.model.masterData.PurchaseOrderRejectionReason;
import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.model.masterData.ServiceType;
import com.aza.api.model.masterData.Task;
import com.aza.api.model.masterData.User;
import com.aza.api.repository.PurchaseOrderFulfillmentRepository;
import com.aza.api.repository.PurchaseOrderRepository;
import com.aza.api.repository.masterData.UserRepository;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.CityService;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.DiscountReasonService;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.PurchaseOrderFulfillmentStatusService;
import com.aza.api.service.masterData.PurchaseOrderRejectionReasonService;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.ServiceTypeService;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PurchaseOrderFulfillmentService implements PurchaseOrderFulfillmentServiceInterface {

    @Autowired
    private JwtService jwtService;
    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @PersistenceContext
    private EntityManager entityManager;
    private static final int BATCH_SIZE = 250; // Ajustado a 500

    @Autowired
    private PurchaseOrderFulfillmentRepository purchaseOrderFulfillmentRepository;

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;
    @Autowired
    private PurchaseOrderService purchaseOrderService;
    @Autowired
    private PurchaseOrderFulfillmentStatusService purchaseOrderFulfillmentStatusService;
    @Autowired
    private ServiceTypeService serviceTypeService;
    @Autowired
    private PurchaseOrderRejectionReasonService purchaseOrderRejectionReasonService;
    @Autowired
    private CityService cityService;
    @Autowired
    private DiscountReasonService discountReasonService;
    @Autowired
    private CompanyService companyService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ClasificationService clasificationService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private PurchaseOrderStatusService purchaseOrderStatusService;
    @Autowired
    private ARLService arlService;
    @Autowired
    private CicleService cicleService;

    @Autowired
    private TransactionLogService transactionLogService;

    private Map<Long, CompanyDto> companyMap;
    private Map<Long, ProductDto> productMap;
    private Map<Long, TaskDto> taskMap;
    private Map<Long, ClasificationDto> clasificationMap;
    private Map<Long, UserDto> userMap;
    private Map<Long, CityDto> cityMap;
    private Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap;
    private Map<Long, ARLDto> arlMap;
    private Map<Long, PurchaseOrderDto> purchaseOrderMap;
    private Map<Long, PurchaseOrderFulfillmentStatusDto> purchaseOrderFulfillmentStatusMap;
    private Map<Long, ServiceTypeDto> serviceTypeMap;
    private Map<Long, PurchaseOrderRejectionReasonDto> purchaseOrderRejectionReasonMap;
    private Map<Long, DiscountReasonDto> discountReasonMap;
    private Map<Long, CicleDto> cicleMap;

    //@Override
    @Override
    public PurchaseOrderFulfillment create(PurchaseOrderFulfillment purchaseOrderFulfillment) {
        PurchaseOrderFulfillment savedPurchaseOrderFulfillment = purchaseOrderFulfillmentRepository.save(purchaseOrderFulfillment);
        return savedPurchaseOrderFulfillment;

    }

    @Override
    public List<PurchaseOrderFulfillment> getAll() {
        List<PurchaseOrderFulfillment> lpurchaseOrderFulfillments = purchaseOrderFulfillmentRepository.findAll();
        return lpurchaseOrderFulfillments;
    }

    @Override
    public void delete(PurchaseOrderFulfillment purchaseOrderFulfillment) {
        purchaseOrderFulfillmentRepository.delete(purchaseOrderFulfillment);
    }

    @Override
    public void deleteAll() {
        purchaseOrderFulfillmentRepository.deleteAll();
    }

    @Override
    public Optional<PurchaseOrderFulfillment> findById(Long id) {
        return purchaseOrderFulfillmentRepository.findById(id);
    }

    @Override
    public GenericResponse add(PurchaseOrderFulfillmentDto request) {
        PurchaseOrderFulfillmentStatus approvedStatus = new PurchaseOrderFulfillmentStatus();
        PurchaseOrderFulfillmentStatus pendingStatusARL = new PurchaseOrderFulfillmentStatus();
        PurchaseOrderFulfillmentStatus pendingStatus = new PurchaseOrderFulfillmentStatus();
        List<PurchaseOrderFulfillmentStatus> allFulfillmentStatuses = purchaseOrderFulfillmentStatusService.getAll();
        for (PurchaseOrderFulfillmentStatus current : allFulfillmentStatuses) {
            if (current.getDescription().toLowerCase().equalsIgnoreCase("cita aprobada")) {
                approvedStatus = current;
            }
            if (current.getDescription().toUpperCase().equalsIgnoreCase("CITA PENDIENTE APROBACIÓN ARL")) {
                pendingStatusARL = current;
            }
            if (current.getDescription().toUpperCase().equalsIgnoreCase("CITA PENDIENTE APROBACIÓN")) {
                pendingStatus = current;
            }
        }
        if (request.getPurchaseOrder().getClasification().getDescription().equalsIgnoreCase("asesoría")
                && request.getUser().getUsertype().getDescription().toLowerCase().contains("emplead")
                && request.getPurchaseOrderFulfillmentStatus().getId().equals(pendingStatus.getId())
                && pendingStatus.getId() != null
                && approvedStatus.getId() != null) {
            if (request.getPurchaseOrder().getArl().getDescription().toLowerCase().contains("sura")
                 ||request.getPurchaseOrder().getArl().getDescription().toLowerCase().contains("nd")   ) {
                request.setPurchaseOrderFulfillmentStatus(PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(approvedStatus));
                request.setReportCicle(getReportcicle(LocalDateTime.now()));
                request.setApproveCicle(getApprovecicle(LocalDateTime.now()));
                request.setCicleName(request.getApproveCicle().getName() + "-" + request.getApproveCicle().getCiclenumber() + " EMPLEADOS");

            } else {
                request.setReportCicle(getReportcicle(LocalDateTime.now()));
                request.setPurchaseOrderFulfillmentStatus(PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(pendingStatusARL));
                request.setCicleName(request.getReportCicle().getName() + "-" + request.getReportCicle().getCiclenumber() + " EMPLEADOS");
            }
        }

        if (request.getId() != null) {
            PurchaseOrderFulfillment currentPurchaseOrderFulfillment = findById(request.getId()).get();
            PurchaseOrderFulfillment purchaseOrderFulfillment = PurchaseOrderFulfillment.builder()
                    .id(currentPurchaseOrderFulfillment.getId())
                    .purchaseOrder(currentPurchaseOrderFulfillment.getPurchaseOrder())
                    .appointmentDate(request.getAppointmentDate())
                    .purchaseOrderFulfillmentStatus(request.getPurchaseOrderFulfillmentStatus() != null ? request.getPurchaseOrderFulfillmentStatus().getId() : null)
                    .executedHours(request.getExecutedHours())
                    .serviceType(request.getServiceType() != null ? request.getServiceType().getId() : null)
                    .reportApprovalDate(request.getReportApprovalDate())
                    .invoiceNumber(request.getInvoiceNumber())
                    .billedHours(request.getBilledHours())
                    .invoiceStatus(request.getInvoiceStatus())
                    .purchaseOrderRejectionReason(request.getPurchaseOrderRejectionReason() != null ? request.getPurchaseOrderRejectionReason().getId() : null)
                    .transportationExpenses(request.getTransportationExpenses())
                    .travelExpenses(request.getTravelExpenses())
                    .requiresSupport(request.isRequiresSupport())
                    .requiresReport(request.isRequiresReport())
                    .hasBankOfHours(request.isHasBankOfHours())
                    .cicleName(request.getCicleName())
                    .fulfillmentCityOfOrigin(request.getFulfillmentCityOfOrigin() != null ? request.getFulfillmentCityOfOrigin().getId() : null)
                    .fulfillmentDestinationCity(request.getFulfillmentDestinationCity() != null ? request.getFulfillmentDestinationCity().getId() : null)
                    .requiresTransport(request.isRequiresTransport())
                    .requireIntercityTransport(request.isRequireIntercityTransport())
                    .requireSpecialTransport(request.isRequireSpecialTransport())
                    .requireTravelExpenses(request.isRequireTravelExpenses())
                    .requireDeliverySupport(request.isRequireDeliverySupport())
                    .requireVisitSupport(request.isRequireVisitSupport())
                    .requireEvaluationSupport(request.isRequireEvaluationSupport())
                    .requireTrainingSupport(request.isRequireTrainingSupport())
                    .reviewedByConsultant(request.isReviewedByConsultant())
                    .rejectionMotiveObservation(request.getRejectionMotiveObservation())
                    .reportCicle(request.getReportCicle() != null ? request.getReportCicle().getId() : null)
                    .approveCicle(request.getApproveCicle() != null ? request.getApproveCicle().getId() : null)
                    .billingCicle(request.getBillingCicle() != null ? request.getBillingCicle().getId() : null)
                    .settlementCicle(request.getSettlementCicle() != null ? request.getSettlementCicle().getId() : null)
                    .arlBillingRate(request.getArlBillingRate() != null ? request.getArlBillingRate() : Double.valueOf("0"))
                    .azaSettlementRate(request.getAzaSettlementRate() != null ? request.getAzaSettlementRate() : Double.valueOf("0"))
                    .bankOfHoursRequestDate(request.getBankOfHoursRequestDate() != null ? request.getBankOfHoursRequestDate() : null)
                    .bankOfHoursPaymentDate(request.getBankOfHoursPaymentDate() != null ? request.getBankOfHoursPaymentDate() : null)
                    .travelExpensesSsettlementValue(request.getTravelExpensesSsettlementValue() != null ? request.getTravelExpensesSsettlementValue() : null)
                    .transportexpensessettlementvalue(request.getTransportexpensessettlementvalue() != null ? request.getTransportexpensessettlementvalue() : null)
                    .settlementhours(request.getSettlementhours() != null ? request.getSettlementhours() : null)
                    .creationDate(request.getCreationDate())
                    .observation(request.getObservation())
                    .coodinator(request.getCoodinator())
                    .supportconsultant(request.getSupportconsultant())
                    .customsettlementvaluesobservation(request.getCustomsettlementvaluesobservation() != null ? request.getCustomsettlementvaluesobservation() : "")
                    .customsettlementvalues(request.getCustomsettlementvalues())
                    .user(request.getUser().getId())
                    .lastUpdatedDate(currentPurchaseOrderFulfillment.getLastUpdatedDate())
                    .createdBy(currentPurchaseOrderFulfillment.getCreatedBy())
                    .lastUpdatedBy(request.getLastUpdatedBy())
                    .deleted(request.getDeleted())
                    .build();
            create(purchaseOrderFulfillment);
            createMasterDataMap();
            calculateOCHoursForEdit(request);
            //addTransactionLogEdit(request);
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(request.getLastUpdatedBy()), userRepository.findByUsername(request.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(purchaseOrderFulfillment, companyMap,
                            productMap,
                            taskMap,
                            clasificationMap,
                            userMap,
                            cityMap,
                            purchaseOrderStatusMap,
                            arlMap,
                            purchaseOrderMap,
                            purchaseOrderFulfillmentStatusMap,
                            serviceTypeMap,
                            purchaseOrderRejectionReasonMap,
                            discountReasonMap,
                            cicleMap
                    ))
                    .build();

        } else {
            PurchaseOrderFulfillment purchaseOrderFulfillment = PurchaseOrderFulfillment.builder()
                    .id(request.getId())
                    .purchaseOrder(request.getPurchaseOrder() != null ? request.getPurchaseOrder().getId() : null)
                    .appointmentDate(request.getAppointmentDate())
                    .purchaseOrderFulfillmentStatus(request.getPurchaseOrderFulfillmentStatus() != null ? request.getPurchaseOrderFulfillmentStatus().getId() : null)
                    .executedHours(request.getExecutedHours())
                    .serviceType(request.getServiceType() != null ? request.getServiceType().getId() : null)
                    .reportApprovalDate(request.getReportApprovalDate())
                    .invoiceNumber(request.getInvoiceNumber())
                    .billedHours(request.getBilledHours())
                    .invoiceStatus(request.getInvoiceStatus())
                    .purchaseOrderRejectionReason(request.getPurchaseOrderRejectionReason() != null ? request.getPurchaseOrderRejectionReason().getId() : null)
                    .transportationExpenses(request.getTransportationExpenses())
                    .travelExpenses(request.getTravelExpenses())
                    .requiresSupport(request.isRequiresSupport())
                    .requiresReport(request.isRequiresReport())
                    .hasBankOfHours(request.isHasBankOfHours())
                    .cicleName(request.getCicleName())
                    .fulfillmentCityOfOrigin(request.getFulfillmentCityOfOrigin() != null ? request.getFulfillmentCityOfOrigin().getId() : null)
                    .fulfillmentDestinationCity(request.getFulfillmentDestinationCity() != null ? request.getFulfillmentDestinationCity().getId() : null)
                    .requiresTransport(request.isRequiresTransport())
                    .requireIntercityTransport(request.isRequireIntercityTransport())
                    .requireSpecialTransport(request.isRequireSpecialTransport())
                    .requireTravelExpenses(request.isRequireTravelExpenses())
                    .requireDeliverySupport(request.isRequireDeliverySupport())
                    .requireVisitSupport(request.isRequireVisitSupport())
                    .requireEvaluationSupport(request.isRequireEvaluationSupport())
                    .requireTrainingSupport(request.isRequireTrainingSupport())
                    .reviewedByConsultant(request.isReviewedByConsultant())
                    .observation(request.getObservation())
                    .rejectionMotiveObservation(request.getRejectionMotiveObservation())
                    .user(request.getUser().getId())
                    .reportCicle(request.getReportCicle() != null ? request.getReportCicle().getId() : null)
                    .approveCicle(request.getApproveCicle() != null ? request.getApproveCicle().getId() : null)
                    .billingCicle(request.getBillingCicle() != null ? request.getBillingCicle().getId() : null)
                    .settlementCicle(request.getSettlementCicle() != null ? request.getSettlementCicle().getId() : null)
                    .arlBillingRate(request.getArlBillingRate() != null ? request.getArlBillingRate() : Double.valueOf("0"))
                    .azaSettlementRate(request.getAzaSettlementRate() != null ? request.getAzaSettlementRate() : Double.valueOf("0"))
                    .bankOfHoursRequestDate(request.getBankOfHoursRequestDate() != null ? request.getBankOfHoursRequestDate() : null)
                    .bankOfHoursPaymentDate(request.getBankOfHoursPaymentDate() != null ? request.getBankOfHoursPaymentDate() : null)
                    .travelExpensesSsettlementValue(request.getTravelExpensesSsettlementValue() != null ? request.getTravelExpensesSsettlementValue() : null)
                    .transportexpensessettlementvalue(request.getTransportexpensessettlementvalue() != null ? request.getTransportexpensessettlementvalue() : null)
                    .settlementhours(request.getSettlementhours() != null ? request.getSettlementhours() : null)
                    .customsettlementvalues(request.getCustomsettlementvalues())
                    .customsettlementvaluesobservation(request.getCustomsettlementvaluesobservation() != null ? request.getCustomsettlementvaluesobservation() : "")
                    .coodinator(request.getCoodinator())
                    .supportconsultant(request.getSupportconsultant())
                    .creationDate(request.getCreationDate())
                    .lastUpdatedDate(request.getLastUpdatedDate())
                    .createdBy(request.getCreatedBy())
                    .lastUpdatedBy(request.getLastUpdatedBy())
                    .deleted(request.getDeleted())
                    .build();
            create(purchaseOrderFulfillment);
            createMasterDataMap();
            calculateOCHoursForEdit(request);
            //addTransactionLogEdit(request);
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(request.getLastUpdatedBy()), userRepository.findByUsername(request.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(purchaseOrderFulfillment, companyMap,
                            productMap,
                            taskMap,
                            clasificationMap,
                            userMap,
                            cityMap,
                            purchaseOrderStatusMap,
                            arlMap,
                            purchaseOrderMap,
                            purchaseOrderFulfillmentStatusMap,
                            serviceTypeMap,
                            purchaseOrderRejectionReasonMap,
                            discountReasonMap,
                            cicleMap
                    ))
                    .build();
        }
    }

    @Transactional
    @Override
    public GenericResponse saveAllPurchaseOrderFulfillments(List<PurchaseOrderFulfillmentDto> purchaseOrderFulfillments, User authenticatedUser) {
        System.out.println("Inicia carga masiva de cumplimientos a bd (api)" + LocalDateTime.now().toString());
        List<PurchaseOrderFulfillment> lpurchaseOrderFulfillments = new ArrayList<>();
        createMasterDataMap();
        boolean isReviewd = false;
        Long isReported;

        PurchaseOrderFulfillmentStatus approvedStatus = new PurchaseOrderFulfillmentStatus();
        PurchaseOrderFulfillmentStatus pendingStatus = new PurchaseOrderFulfillmentStatus();
        List<PurchaseOrderFulfillmentStatus> allFulfillmentStatuses = purchaseOrderFulfillmentStatusService.getAll();
        for (PurchaseOrderFulfillmentStatus current : allFulfillmentStatuses) {
            if (current.getDescription().toLowerCase().contains("cita aprobada")) {
                approvedStatus = current;
            }
            if (current.getDescription().toLowerCase().contains("pendiente de aprobación arl")) {
                pendingStatus = current;
            }

        }
        for (PurchaseOrderFulfillmentDto cdto : purchaseOrderFulfillments) {
            try {
                lpurchaseOrderFulfillments.add(PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentDtoToPurchaseOrderFulfillment(cdto, companyMap,
                        productMap,
                        taskMap,
                        clasificationMap,
                        userMap,
                        cityMap,
                        purchaseOrderStatusMap,
                        arlMap
                ));
            } catch (Exception e) {
                GlobalExceptionHandler.responseErrorMessage(e);
                System.out.println("ERROR CONVERSION: " + cdto.getPurchaseOrder().getPurchaseOrderNumber() + " ERROR MESAGGE: " + e.getMessage());
            }

        }

        List<PurchaseOrderFulfillment> loadPurchaseOrderFulfillments = new ArrayList<>();
        List<PurchaseOrderFulfillment> currentActive = getAllActive();
        boolean existsPOF = false;
        for (PurchaseOrderFulfillment current : lpurchaseOrderFulfillments) {
            for (PurchaseOrderFulfillment currentDb : currentActive) {
                if (current.getAppointmentDate().equals(currentDb.getAppointmentDate())
                        && current.getPurchaseOrder().equals(currentDb.getPurchaseOrder())) {
                    current.setDeleted(false);
                    current.setId(currentDb.getId());
                    current.setCreationDate(currentDb.getCreationDate());
                    current.setCreatedBy(currentDb.getCreatedBy());
                    current.setReviewedByConsultant(currentDb.isReviewedByConsultant());
                    current.setObservation(currentDb.getObservation());
                    current.setRejectionMotiveObservation(currentDb.getRejectionMotiveObservation());
                    current.setPurchaseOrderRejectionReason(currentDb.getPurchaseOrderRejectionReason());
                    current.setCoodinator(currentDb.getCoodinator());
                    current.setSupportconsultant(currentDb.getSupportconsultant());
                    current.setSupportconsultant(currentDb.getInvoiceNumber());
                    current.setSupportconsultant(currentDb.getCustomsettlementvaluesobservation());
                    existsPOF = true;
                    break;
                }
            }
            if (existsPOF) {
                if (!(current.isReviewedByConsultant())) {
                    loadPurchaseOrderFulfillments.add(current);
                }
                //facturación
                if (current.getBillingCicle() != null) {
                    if (current.getBillingCicle() > 0) {
                        loadPurchaseOrderFulfillments.add(current);
                    }
                }
            } else {
                loadPurchaseOrderFulfillments.add(current);
            }
        }
        int batchCount = 0;
        System.out.println("Inicia carga masiva de de Cumplimientos a bd proceso bacth" + LocalDateTime.now().toString());
        for (int i = 0; i < loadPurchaseOrderFulfillments.size(); i++) {
            entityManager.merge(loadPurchaseOrderFulfillments.get(i));
            batchCount++;

            if (batchCount % BATCH_SIZE == 0) {
                // Flush and clear the entity manager to free memory.
                System.out.println("Carga datos" + i);
                entityManager.flush();
                entityManager.clear();
                batchCount = 0;
            }
        }

        if (batchCount > 0) {
            entityManager.flush();
            entityManager.clear();
        }

        System.out.println("termina carga masiva de OC a bd (api)" + LocalDateTime.now().toString());
        createMasterDataMap();
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        calculateOCHoursForLoad(purchaseOrderFulfillments);
        return GenericResponse.builder()
                .token(token)
                .data(purchaseOrderFulfillments)
                .build();

    }

    public List<PurchaseOrderFulfillment> getAllActive() {
        return purchaseOrderFulfillmentRepository.findAllByDeletedFalse();
    }

    private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Company> lcompanies = companyService.getAllActive();
        List<CompanyDto> lcompaniesDto = new ArrayList<>();
        for (Company c : lcompanies) {
            lcompaniesDto.add(CompanyDto.CompanyToCompanyDto(c));
        }
        companyMap = lcompaniesDto.stream()
                .collect(Collectors.toMap(CompanyDto::getId, Function.identity()));

        List<Product> lproducts = productService.getAllActive();
        List<ProductDto> lproductsDto = new ArrayList<>();
        for (Product p : lproducts) {
            lproductsDto.add(ProductDto.ProductToProductDto(p));
        }
        productMap = lproductsDto.stream()
                .collect(Collectors.toMap(ProductDto::getId, Function.identity()));

        List<Task> ltasks = taskService.getAllActive();
        List<TaskDto> ltasksDto = new ArrayList<>();
        for (Task t : ltasks) {
            ltasksDto.add(TaskDto.TaskToTaskDto(t));
        }
        taskMap = ltasksDto.stream()
                .collect(Collectors.toMap(TaskDto::getId, Function.identity()));

        List<Clasification> lclasification = clasificationService.getAllActive();
        List<ClasificationDto> lclasificationDto = new ArrayList<>();
        for (Clasification c : lclasification) {
            lclasificationDto.add(ClasificationDto.ClasificationToClasificationDto(c));
        }
        clasificationMap = lclasificationDto.stream()
                .collect(Collectors.toMap(ClasificationDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

        List<City> lcities = cityService.getAllActive();
        List<CityDto> lcitiesDto = new ArrayList<>();
        for (City c : lcities) {
            lcitiesDto.add(CityDto.CityToCityDto(c));
        }
        cityMap = lcitiesDto.stream()
                .collect(Collectors.toMap(CityDto::getId, Function.identity()));

        List<PurchaseOrderStatus> lpurchaseOrderStatus = purchaseOrderStatusService.getAllActive();
        List<PurchaseOrderStatusDto> lpurchaseOrderStatusDto = new ArrayList<>();
        for (PurchaseOrderStatus p : lpurchaseOrderStatus) {
            lpurchaseOrderStatusDto.add(PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(p));
        }
        purchaseOrderStatusMap = lpurchaseOrderStatusDto.stream()
                .collect(Collectors.toMap(PurchaseOrderStatusDto::getId, Function.identity()));

        List<ARL> larl = arlService.getAllActive();
        List<ARLDto> larlDto = new ArrayList<>();
        for (ARL a : larl) {
            larlDto.add(ARLDto.ARLToARLDto(a));
        }
        arlMap = larlDto.stream()
                .collect(Collectors.toMap(ARLDto::getId, Function.identity()));

        List<PurchaseOrder> lPurchaseOrder = purchaseOrderService.getAllActive();
        List<PurchaseOrderDto> lPurchaseOrderDto = new ArrayList<>();
        for (PurchaseOrder a : lPurchaseOrder) {
            lPurchaseOrderDto.add(PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(a, companyMap, productMap, taskMap, clasificationMap, userMap, cityMap, purchaseOrderStatusMap, arlMap));
        }
        purchaseOrderMap = lPurchaseOrderDto.stream()
                .collect(Collectors.toMap(PurchaseOrderDto::getId, Function.identity()));

        List<PurchaseOrderFulfillmentStatus> lPurchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatusService.getAllActive();
        List<PurchaseOrderFulfillmentStatusDto> lPurchaseOrderFulfillmentStatusDto = new ArrayList<>();
        for (PurchaseOrderFulfillmentStatus a : lPurchaseOrderFulfillmentStatus) {
            lPurchaseOrderFulfillmentStatusDto.add(PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(a));
        }
        purchaseOrderFulfillmentStatusMap = lPurchaseOrderFulfillmentStatusDto.stream()
                .collect(Collectors.toMap(PurchaseOrderFulfillmentStatusDto::getId, Function.identity()));

        List<ServiceType> lServiceType = serviceTypeService.getAllActive();
        List<ServiceTypeDto> lServiceTypeDto = new ArrayList<>();
        for (ServiceType a : lServiceType) {
            lServiceTypeDto.add(ServiceTypeDto.ServiceTypeToServiceTypeDto(a));
        }
        serviceTypeMap = lServiceTypeDto.stream()
                .collect(Collectors.toMap(ServiceTypeDto::getId, Function.identity()));

        List<PurchaseOrderRejectionReason> lPurchaseOrderRejectionReason = purchaseOrderRejectionReasonService.getAllActive();
        List<PurchaseOrderRejectionReasonDto> lPurchaseOrderRejectionReasonDto = new ArrayList<>();
        for (PurchaseOrderRejectionReason a : lPurchaseOrderRejectionReason) {
            lPurchaseOrderRejectionReasonDto.add(PurchaseOrderRejectionReasonDto.PurchaseOrderRejectionReasonToPurchaseOrderRejectionReasonDto(a));
        }
        purchaseOrderRejectionReasonMap = lPurchaseOrderRejectionReasonDto.stream()
                .collect(Collectors.toMap(PurchaseOrderRejectionReasonDto::getId, Function.identity()));

        List<DiscountReason> lDiscountReason = discountReasonService.getAllActive();
        List<DiscountReasonDto> lDiscountReasonDto = new ArrayList<>();
        for (DiscountReason a : lDiscountReason) {
            lDiscountReasonDto.add(DiscountReasonDto.DiscountReasonToDiscountReasonDto(a));
        }
        discountReasonMap = lDiscountReasonDto.stream()
                .collect(Collectors.toMap(DiscountReasonDto::getId, Function.identity()));

        List<Cicle> lCicles = cicleService.getAllActive();
        List<CicleDto> lCiclesDto = new ArrayList<>();
        for (Cicle a : lCicles) {
            lCiclesDto.add(CicleDto.CicleToCicleDto(a));
        }
        cicleMap = lCiclesDto.stream()
                .collect(Collectors.toMap(CicleDto::getId, Function.identity()));

    }

    public List<PurchaseOrderFulfillment> getApprovedFulfillment(String status) {
        PurchaseOrderFulfillmentStatus approvedStatus = purchaseOrderFulfillmentStatusService.findByDescription(status);
        return purchaseOrderFulfillmentRepository.findAllBypurchaseOrderFulfillmentStatus(approvedStatus.getId());
    }

    private void calculateOCHoursForLoad(List<PurchaseOrderFulfillmentDto> purchaseOrderFulfillments) {
        System.out.println("Inicia actualización de horas ejecutadas y disponibles para " + purchaseOrderFulfillments.size() + " Hora inicial:" + LocalDateTime.now());
        purchaseOrderRepository.updatePurchaseOrderHours();
        System.out.println("finaliza actualización de horas ejecutadas y disponibles para " + purchaseOrderFulfillments.size() + " Hora inicial:" + LocalDateTime.now());
    }

    private void calculateOCHoursForEdit(PurchaseOrderFulfillmentDto request) {
        System.out.println("Inicia actualización de horas ejecutadas y disponibles para OC:" + request.getPurchaseOrder().getPurchaseOrderNumber() + " Hora inicial:" + LocalDateTime.now());
        purchaseOrderRepository.updatepurchaseorderhoursByid(request.getPurchaseOrder().getId());
        System.out.println("Finaliza actualización de horas ejecutadas y disponibles para OC:" + request.getPurchaseOrder().getPurchaseOrderNumber() + " Hora inicial:" + LocalDateTime.now());
    }

    private CicleDto getReportcicle(LocalDateTime now) {
        List<Cicle> ciclesList = cicleService.getAllActive();
        return CicleDto.CicleToCicleDto(ciclesList.stream()
                .filter(current -> CicleDto.CicleToCicleDto(current).getCicletype().getDescription().toUpperCase().contains("REPORTE DE CUMPLIMIENTOS DE EMPLEADOS")
                && current.getStartdate().isBefore(LocalDateTime.now())
                && current.getEnddate().isAfter(LocalDateTime.now()))
                .findFirst()
                .orElse(new Cicle()));  // Retorna un nuevo Cicle si no se encuentra ninguno

    }

    private CicleDto getApprovecicle(LocalDateTime now) {
        List<Cicle> ciclesList = cicleService.getAllActive();
        return CicleDto.CicleToCicleDto(ciclesList.stream()
                .filter(current -> CicleDto.CicleToCicleDto(current).getCicletype().getDescription().toUpperCase().contains("APROBACIÓN DE CUMPLIMIENTOS DE EMPLEADOS")
                && current.getStartdate().isBefore(LocalDateTime.now())
                && current.getEnddate().isAfter(LocalDateTime.now()))
                .findFirst()
                .orElse(new Cicle()));  // Retorna un nuevo Cicle si no se encuentra ninguno

    }
}

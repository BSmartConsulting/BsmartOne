package com.aza.api.service.masterData;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.RoleDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.dto.masterData.UserRateDto;
import com.aza.api.dto.masterData.UserStatusDto;
import com.aza.api.model.masterData.Role;
import com.aza.api.model.masterData.User;
import com.aza.api.model.masterData.UserRate;
import com.aza.api.model.masterData.UserRole;
import com.aza.api.model.masterData.UserStatus;
import com.aza.api.repository.masterData.UserRepository;
import com.aza.api.service.EmailService;
import com.aza.api.service.JwtService;
import com.aza.api.service.TransactionLogService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.util.GlobalExceptionHandler;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService implements UserServiceInterface {

    @Autowired
    private UserStatusService userStatusService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;
    @Autowired
    private UserRoleService userRoleService;
    @Autowired
    private UserRateService userRateService;

    @PersistenceContext
    private EntityManager entityManager;
    private static final int BATCH_SIZE = 250; // Ajustado a 500

    @PersistenceContext
    private EntityManager entityManagerRates;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleService roleService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private TransactionLogService transactionLogService;

    private static final LocalDateTime END_OF_TIME = LocalDateTime.of(9999, 12, 31, 23, 59, 59);
    private static final LocalDateTime START_TIME = LocalDateTime.of(9999, 12, 31, 23, 59, 59);

    private List<User> modifiedUserTypeList = new ArrayList<>();

    @Override
    public User create(User user, String operacion) {
        User savedUser = userRepository.save(user);
        updateUserRoles(savedUser, user.getRoles());
        sendRecoveryCode(user, operacion);
        return savedUser;

    }

    private void updateUserRoles(User user, Set<Long> roleIds) {
        // Obtener los roles actuales del usuario desde la lista en memoria
        List<UserRole> currentRoles = userRoleService.getAll().stream()
                .filter(ur -> ur.getUserId().equals(user.getId()))
                .collect(Collectors.toList());

        // Crear un set con los IDs de los roles actuales
        Set<Long> currentRoleIds = currentRoles.stream()
                .map(UserRole::getRoleId)
                .collect(Collectors.toSet());

        // Determinar los roles a eliminar y a agregar
        Set<Long> rolesToRemove = currentRoleIds.stream()
                .filter(roleId -> !roleIds.contains(roleId))
                .collect(Collectors.toSet());

        Set<Long> rolesToAdd = roleIds.stream()
                .filter(roleId -> !currentRoleIds.contains(roleId))
                .collect(Collectors.toSet());

        // Eliminar los roles que ya no deben estar asignados
        if (!rolesToRemove.isEmpty()) {
            List<UserRole> userRolesToRemove = currentRoles.stream()
                    .filter(ur -> rolesToRemove.contains(ur.getRoleId()))
                    .collect(Collectors.toList());
            userRoleService.deleteAll(userRolesToRemove);
            // También eliminarlos de la lista en memoria
        }

        // Agregar los nuevos roles
        if (!rolesToAdd.isEmpty()) {
            List<UserRole> newUserRoles = rolesToAdd.stream()
                    .map(roleId -> {
                        UserRole userRole = new UserRole();
                        userRole.setRoleId(roleId);
                        userRole.setUserId(user.getId());
                        userRole.setDeleted(false);
                        userRole.setCreationDate(LocalDateTime.now());
                        userRole.setLastUpdatedDate(LocalDateTime.now());
                        userRole.setLastUpdatedBy(user.getLastUpdatedBy());
                        userRole.setCreatedBy(user.getLastUpdatedBy());
                        return userRole;
                    })
                    .collect(Collectors.toList());

            userRoleService.saveAll(newUserRoles);
        }
    }

    @Override
    public List<User> getAll() {
        List<User> lusers = userRepository.findAll();
        for (User currentUser : lusers) {
            //Set<UserRole> userRoles = userRoleService.findByUserId(currentUser.getId());
            List<UserRole> userRoles = userRoleService.getAll();
            Set<Long> rolesId = new HashSet<>();
            for (UserRole currentUserRole : userRoles) {
                if (currentUser.getId() == currentUserRole.getUserId()) {
                    rolesId.add(currentUserRole.getRoleId());
                }
            }
            currentUser.setRoles(rolesId);
        }
        return lusers;
    }

    @Override
    public void delete(User user) {
        userRepository.delete(user);
    }

    @Override
    public void deleteAll() {
        userRepository.deleteAll();
    }

    @Override
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public void resetUser(UserDto request) {
        User user = UserDto.UserDtoToUser(request);
        Optional<UserStatus> defaultUserStatusOptional = userStatusService.findByDescription("ACTIVO");
        if (!defaultUserStatusOptional.isPresent()) {
            throw new RuntimeException("El estado por defecto: \"ACTIVO\" no existe");
        }
        UserStatus defaultUserStatus = defaultUserStatusOptional.get();
        user.setPassword(passwordEncoder.encode("Password123456$"));
        user.setStatus(defaultUserStatus.getId());
        user.setRequirespasswordchange(true);
        user.setFailedattempts(0);
        create(user, "RESET_USER");
    }

    public GenericResponse updatePassword(UserDto request) {

        request.setFailedattempts(0);
        UserStatus activeUserStatus = userStatusService.findByDescription("ACTIVO").get();
        request.setStatus(UserStatusDto.UserStatusToUserStatusDto(activeUserStatus));
        User currentUser = UserDto.UserDtoToUser(request);
        create(currentUser, "UPDATE_PASSWORD");
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(currentUser.getUsername()), currentUser);
        return GenericResponse.builder()
                .token(token)
                .data(UserDto.UserToUserDto(currentUser))
                .build();

    }

    public GenericResponse add(UserDto request) {
        if (request.getId() != null) {
            Optional<User> currentUser = findById(request.getId());
            Set<UserRole> userRoles = new HashSet<>();
            Set<Long> roles = new HashSet<>();
            for (RoleDto r : request.getRoles()) {
                roles.add(r.getId());
            }

            if(!currentUser.get().getUsertype().equals(request.getUsertype().getId()))
            {
                modifiedUserTypeList.add(currentUser.get());
                sendEmailsUserTypeChanges();
            }
            User user = User.builder()
                    .id(request.getId())
                    .username(request.getUsername())
                    .password(currentUser.get().getPassword())
                    .status(request.getStatus().getId())
                    .roles(roles)
                    .requirespasswordchange(request.isRequirespasswordchange())
                    .failedattempts(request.getFailedattempts())
                    .taxid(request.getTaxid())
                    .email(request.getEmail())
                    .azaprofile(request.getAzaprofile().getId())
                    .capacity(request.getCapacity())
                    .usertype(request.getUsertype().getId())
                    .fullname(request.getFullname())
                    .specialty(request.getSpecialty())
                    .corporateemail(request.getCorporateemail())
                    .licensenumber(request.getLicensenumber())
                    .technicalexperience(request.getTechnicalexperience())
                    .specialization(request.getSpecialization())
                    .coreprofession(request.getCoreprofession())
                    .otherformation(request.getOtherformation())
                    .cityofresidence(request.getCityofresidence())
                    .address(request.getAddress())
                    .failedattempts(request.getFailedattempts())
                    .cellphone(request.getCellphone())
                    .coodinator(request.getCoodinator())
                    .supportconsultant(request.getSupportconsultant())
                    .startdate(request.getStartdate())
                    .enddate(request.getEnddate())
                    .lastUpdatedBy(request.getLastUpdatedBy())
                    .lastUpdatedDate(request.getLastUpdatedDate())
                    .createdBy(request.getCreatedBy())
                    .creationDate(request.getCreationDate())
                    .deleted(request.getDeleted())
                    .build();
            create(user, "UPDATE_USER");

            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(request.getLastUpdatedBy()), user);
            return GenericResponse.builder()
                    .token(token)
                    .data(UserDto.UserToUserDto(user))
                    .build();

        } else {
            //
            //Optional<Role> defaultRoleOptional = roleService.findByDescription("USER"); // Asume que el ID del rol es 2
            Optional<Role> defaultRoleOptional = roleService.findByDescription("ADMIN"); // Asume que el ID del rol es 2
            Optional<UserStatus> defaultUserStatusOptional = userStatusService.findByDescription("ACTIVO");

            if (!defaultRoleOptional.isPresent()) {
                throw new RuntimeException("El rol por defecto: \"ADMIN\", no existe");
            }
            if (!defaultUserStatusOptional.isPresent()) {
                throw new RuntimeException("El estado por defecto: \"ACTIVO\" no existe");
            }
            Role defaultRole = defaultRoleOptional.get();
            UserStatus defaultUserStatus = defaultUserStatusOptional.get();
            // Asignar el rol al nuevo usuario
            Set<Long> roles = new HashSet<>();
            roles.add(defaultRole.getId());

            User user = User.builder()
                    .id(request.getId())
                    .username(request.getUsername())
                    .password(passwordEncoder.encode("Password123456$"))
                    .status(defaultUserStatus.getId())
                    .roles(roles)
                    .requirespasswordchange(true)
                    .failedattempts(request.getFailedattempts())
                    .taxid(request.getTaxid())
                    .email(request.getEmail())
                    .azaprofile(request.getAzaprofile() != null ? request.getAzaprofile().getId() : null)
                    .capacity(request.getCapacity() != null ? request.getCapacity() : "0")
                    .usertype(request.getUsertype().getId())
                    .fullname(request.getFullname())
                    .specialty(request.getSpecialty())
                    .corporateemail(request.getCorporateemail())
                    .licensenumber(request.getLicensenumber())
                    .technicalexperience(request.getTechnicalexperience())
                    .specialization(request.getSpecialization())
                    .coreprofession(request.getCoreprofession())
                    .otherformation(request.getOtherformation())
                    .cityofresidence(request.getCityofresidence())
                    .address(request.getAddress())
                    .failedattempts(request.getFailedattempts())
                    .coodinator(request.getCoodinator())
                    .supportconsultant(request.getSupportconsultant())
                    .startdate(request.getStartdate())
                    .enddate(request.getEnddate())
                    .cellphone(request.getCellphone())
                    .lastUpdatedBy(request.getLastUpdatedBy())
                    .lastUpdatedDate(request.getLastUpdatedDate())
                    .createdBy(request.getCreatedBy())
                    .creationDate(request.getCreationDate())
                    .deleted(request.getDeleted())
                    .build();
            create(user, "CREATE_USER");
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(request.getLastUpdatedBy()), user);
            return GenericResponse.builder()
                    .token(token)
                    .data(UserDto.UserToUserDto(user))
                    .build();
        }
    }

    @Transactional
    public GenericResponse saveAllUsers(List<UserDto> users, User authenticatedUser) {
        try {
            System.out.println("Inicia carga masiva de usuario a bd (api)" + LocalDateTime.now().toString());
            List<User> lusers = new ArrayList<>();
            List<User> lAllusers = getAllActive();
            
            modifiedUserTypeList.clear();
            
            for (UserDto cdto : users) {
                if (cdto.getStartdate().equals(LocalDateTime.MIN)) {
                    cdto.setStartdate(START_TIME);
                }
                if (cdto.getEnddate().equals(LocalDateTime.MAX)  || cdto.getEnddate().equals(LocalDateTime.MIN)) {
                    cdto.setEnddate(END_OF_TIME);
                }
                lusers.add(UserDto.UserDtoToUser(cdto));
                System.out.println("USER:" + cdto.toString());
            }

            // Crear un mapa para búsqueda rápida de usuarios existentes por taxid
            Map<String, User> existingUsersMap = new HashMap<>();
            for (User currentExist : lAllusers) {
                existingUsersMap.put(currentExist.getTaxid(), currentExist);
            }

            // Actualizar IDs en lusers
            for (User current : lusers) {
                User existingUser = existingUsersMap.get(current.getTaxid());
                if (existingUser != null) {
                    current.setId(existingUser.getId());
                    current.setCreatedBy(existingUser.getCreatedBy());
                    current.setCreationDate(existingUser.getCreationDate());
                    //almacenar lista de casos en que se cambie el tipo
                    if (!current.getUsertype().equals(existingUser.getUsertype())) {
                        modifiedUserTypeList.add(current);
                    }
                } else {
                    current.setCreatedBy(current.getLastUpdatedBy());
                    current.setCreationDate(current.getLastUpdatedDate());
                }
            }
            int batchCount = 0;
            System.out.println("Inicia carga masiva de usuario a bd proceso bacth" + LocalDateTime.now().toString());
            for (int i = 0; i < lusers.size(); i++) {
                entityManager.merge(lusers.get(i));
                batchCount++;

                if (batchCount % BATCH_SIZE == 0) {
                    // Flush and clear the entity manager to free memory.
                    System.out.println("Carga datos" + i);
                    entityManager.flush();
                    entityManager.clear();
                    batchCount = 0;
                }
            }

            if (batchCount > 0) {
                entityManager.flush();
                entityManager.clear();
            }

            Set<Long> defaultRole = new HashSet<>();
            for (Role r : roleService.getAllActive()) {
                if (r.getDescription().equalsIgnoreCase("ASESOR")) {
                    defaultRole.add(r.getId());
                    break;
                }
            }
            // Usa el usuario autenticado
            for (User current : lusers) {
                updateUserRoles(current, defaultRole);
            }
            sendEmailsUserTypeChanges();
            System.out.println("termina carga masiva de usuario a bd (api)" + LocalDateTime.now().toString());
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
            return GenericResponse.builder()
                    .token(token)
                    .data(users) // Ajusta esto según sea necesario
                    .build();
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            System.out.println("ERROR EN CARGA DE ARCHIVOS DE USUARIO:" + e.getMessage());
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
            return GenericResponse.builder()
                    .token(token)
                    .data(users) // Ajusta esto según sea necesario
                    .build();

        }
    }

    public User loadUserByUsername(String username) {
        System.out.println("Inicia carga masiva de usuario(Service)" + LocalDateTime.now().toString());
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("El usuario : " + username + " No existe"));
    }

    public String sendRecoveryCode(User user, String Operacion) {
        //modificar el texto segun la op
        String message = "";
        String messageTitle = "";
        switch (Operacion) {
            case "CREATE_USER":
                messageTitle = "Creación exitosa del usuario:" + user.getUsername();
                message = "Se ha creado exitosamente el usuario: " + user.getUsername()
                        + "\nPara iniciar sesión debe ingresar con el password: Password123456$"
                        + "\nAl iniciar sesión se solicitará cambiar contraseña, tenga en cuenta las siguientes restricciones:."
                        + "\n1. Debe contener mas de 8 carácteres"
                        + "\n2. Debe contener al menos una letra mayuscula"
                        + "\n3. Debe contener al menos una letra minuscula"
                        + "\n4. Debe contener al menos un número"
                        + "\n5. Debe contener al menos un caracter especial de la siguiente lista: @ # $ % ^ & + = * + - _ , ; : < > { } [ ]";
                emailService.sendSimpleMessage(user.getEmail(), messageTitle, message);
                break;
            case " UPDATE_USER":
                messageTitle = "Modificación exitosa del usuario:" + user.getUsername();
                message = "Se ha modificado exitosamente el usuario: " + user.getUsername()
                        + "\nPara iniciar sesión debe ingresar con el password: Password123456$"
                        + "\nAl iniciar sesión se solicitará cambiar contraseña, tenga en cuenta las siguientes restricciones:."
                        + "\n1. Debe contener mas de 8 carácteres"
                        + "\n2. Debe contener al menos una letra mayuscula"
                        + "\n3. Debe contener al menos una letra minuscula"
                        + "\n4. Debe contener al menos un número"
                        + "\n5. Debe contener al menos un caracter especial de la siguiente lista: @ # $ % ^ & + = * + - _ , ; : < > { } [ ]";
                break;
            case "RESET_USER":
                messageTitle = "Reinicio de cuenta exitosa para el usuario:" + user.getUsername();
                message = "Se ha reiniciado exitosamente el usuario: " + user.getUsername()
                        + "\nPara iniciar sesión debe ingresar con el password: Password123456$"
                        + "\nAl iniciar sesión se solicitará cambiar contraseña, tenga en cuenta las siguientes restricciones:."
                        + "\n1. Debe contener mas de 8 carácteres"
                        + "\n2. Debe contener al menos una letra mayuscula"
                        + "\n3. Debe contener al menos una letra minuscula"
                        + "\n4. Debe contener al menos un número"
                        + "\n5. Debe contener al menos un caracter especial de la siguiente lista: @ # $ % ^ & + = * + - _ , ; : < > { } [ ]";
                emailService.sendSimpleMessage(user.getEmail(), messageTitle, message);
                break;
            case "UPDATE_PASSWORD":
                messageTitle = "Cambio de password exitoso del usuario:" + user.getUsername();
                message = "Se ha modificado exitosamente el password del usuario: " + user.getUsername();
                emailService.sendSimpleMessage(user.getEmail(), messageTitle, message);
                break;

        }
        return "Correo enviado con éxito";
    }

    public List<User> getAllActive() {
        return userRepository.findAllByDeletedFalse();
    }

    @Transactional
    public GenericResponse saveAllUsersRate(List<UserRateDto> usersRate, User authenticatedUser) {
        System.out.println("Inicia carga masiva de tarifas a bd (api)" + LocalDateTime.now());

        // 1. Convertir DTOs a entidades
        List<UserRate> userRatesToSave = usersRate.stream()
                .map(UserRateDto::UserRateDtoToUserRate)
                .collect(Collectors.toList());

        // 2. Obtener tarifas activas
        List<UserRate> activeUserRates = userRateService.getAllActive();
        Map<String, UserRate> currentRatesMap = new HashMap<>();

        for (UserRate rate : activeUserRates) {
            if (END_OF_TIME.equals(rate.getEnddate())) {
                String key = getKey(rate);
                currentRatesMap.put(key, rate);
            }
        }

        List<UserRate> ratesToUpdateOrInsert = new ArrayList<>();
        List<UserRate> ratesToClose = new ArrayList<>();

        // 3. Comparar y preparar operaciones
        for (UserRate current : userRatesToSave) {
            String key = getKey(current);
            UserRate existingRate = currentRatesMap.get(key);

            if (existingRate != null) {
                if (current.getStartdate().isEqual(existingRate.getStartdate())) {
                    current.setId(existingRate.getId());
                    current.setCreatedBy(existingRate.getCreatedBy());
                    current.setCreationDate(existingRate.getCreationDate());
                } else {
                    existingRate.setEnddate(current.getStartdate());
                    existingRate.setLastUpdatedDate(LocalDateTime.now());
                    existingRate.setLastUpdatedBy(current.getLastUpdatedBy());
                    ratesToClose.add(existingRate);
                    current.setEnddate(END_OF_TIME);
                }
            } else {
                current.setEnddate(END_OF_TIME);
            }

            ratesToUpdateOrInsert.add(current);
        }

        // 4. Guardar o actualizar en batch
        processBatch(ratesToUpdateOrInsert);
        processBatch(ratesToClose);

        // 5. Convertir respuesta
        List<UserRateDto> responseDtos = ratesToUpdateOrInsert.stream()
                .map(UserRateDto::UserRateToUserRateDto)
                .collect(Collectors.toList());

        System.out.println("Termina carga masiva de tarifas a bd (api)" + LocalDateTime.now());

        // 6. Generar token y respuesta
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);

        return GenericResponse.builder()
                .token(token)
                .data(responseDtos)
                .build();
    }

    private String getKey(UserRate rate) {
        return rate.getUserid() + "-" + rate.getArlid() + "-" + rate.getRatetype();
    }

    private void processBatch(List<UserRate> rates) {
        if (rates.isEmpty()) {
            return;
        }

        int batchSize = 0;
        List<UserRate> batch = new ArrayList<>();

        for (UserRate rate : rates) {
            batch.add(rate);
            batchSize++;

            if (batchSize % BATCH_SIZE == 0) {
                flushBatch(batch);
                batch.clear();
            }
        }

        if (!batch.isEmpty()) {
            flushBatch(batch);
        }
    }

    private void flushBatch(List<UserRate> batch) {
        for (UserRate userRate : batch) {
            entityManagerRates.merge(userRate);
        }
        entityManagerRates.flush();
        entityManagerRates.clear(); // Opcional: limpia el contexto de persistencia para evitar sobrecarga de memoria
    }

    private void sendEmailsUserTypeChanges() {
        String messageTitle = "";
        String message = "";
        String email="direccionlogistica@azagestionriesgo.com";
        System.out.println("Email configurado: "+email);
        //String email = "jaimesarmientop@gmail.com";
        for (User currentUser : modifiedUserTypeList) {
            System.out.println("Email de cambio de tipo de usuario enviado para el usuario:" + currentUser.getFullname());
            System.out.println("Email de cambio de tipo de usuario enviado al correo:" + email);
            messageTitle = "Usuario con cambio de tipo:" + currentUser.getFullname();
            message = " Se ha realizado un cambio de tipo de usuario para : " + currentUser.getFullname()
                    + "\n Este cambio puede afectar procesos de liquidación y otros ";
            emailService.sendSimpleMessage(email, messageTitle, message);

        }

    }
}

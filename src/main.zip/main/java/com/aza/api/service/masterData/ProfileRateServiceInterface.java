/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.UserRate;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ProfileRateServiceInterface {

    UserRate create(UserRate profileRate);

    void delete(UserRate profileRate);

    void deleteAll();

    UserRate findById(Long id);

    List<UserRate> getAll();

}

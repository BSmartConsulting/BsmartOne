/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.model.PurchaseOrderFulfillmentSupportFile;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface PurchaseOrderFulfillmentSupportFileServiceInterface {

    GenericResponse add(PurchaseOrderFulfillmentSupportFile request);

    PurchaseOrderFulfillmentSupportFile create(PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFile);

    void delete(PurchaseOrderFulfillmentSupportFileService purchaseOrderFulfillmentSupportFile);

    void delete(PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFile);

    void deleteAll();

    Optional<PurchaseOrderFulfillmentSupportFile> findById(Long id);

    List<PurchaseOrderFulfillmentSupportFile> getAll();

    List<PurchaseOrderFulfillmentSupportFile> findByPurchaseOrderFulfillment(Long purchaseOrderFulfillment);

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Clasification;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ClasificationServiceInterface {

    Clasification create(Clasification clasification);

    void delete(Clasification clasification);

    void deleteAll();

    Clasification findById(Long id);

    List<Clasification> getAll();

}

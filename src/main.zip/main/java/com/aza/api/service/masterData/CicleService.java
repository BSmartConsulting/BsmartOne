/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Cicle;
import com.aza.api.repository.masterData.CicleRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class CicleService implements CicleServiceInterface {

    @Autowired
    private CicleRepository cicleRepository;

    @Override
    public Cicle create(Cicle cicle) {
        return cicleRepository.save(cicle);
        //return CicleRepository.save(new Cicle(cicle.getId(),cicle.getCodigo(),cicle.getDescripcion()));
    }

    @Override
    public List<Cicle> getAll() {
        return cicleRepository.findAll();
    }

    @Override
    public void delete(Cicle cicle) {
        cicleRepository.delete(cicle);
    }

    @Override
    public void deleteAll() {
        cicleRepository.deleteAll();
    }

    @Override
    public Cicle findById(Long id) {
        return cicleRepository.findById(id).get();
    }

    @Override
    public List<Cicle> getAllActive() {
        return cicleRepository.findAllByDeletedFalse();
    }

}

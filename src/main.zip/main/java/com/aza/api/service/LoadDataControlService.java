/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.model.LoadDataControl;
import com.aza.api.repository.LoadDataControlRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jaime
 */
@Service
public class LoadDataControlService implements LoadDataControlServiceInterface {

    @Autowired
    private LoadDataControlRepository loadDataControlRepository;

    @Override
    public LoadDataControl create(LoadDataControl loadDataControl) {
        return loadDataControlRepository.save(loadDataControl);
    }

    @Override
    public List<LoadDataControl> getAll() {
        return loadDataControlRepository.findAll();
    }

    @Override
    public void delete(LoadDataControl loadDataControl) {
        loadDataControlRepository.delete(loadDataControl);
    }

    @Override
    public void deleteAll() {
        loadDataControlRepository.deleteAll();
    }

    @Override
    public Optional<LoadDataControl> findById(Long id) {
        return loadDataControlRepository.findById(id);
    }
}

package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.DiscountDto;
import com.aza.api.dto.masterData.CicleDto;
import com.aza.api.dto.masterData.DiscountReasonDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.Discount;
import com.aza.api.model.TransactionLog;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.DiscountReason;
import com.aza.api.model.masterData.User;
import com.aza.api.repository.DiscountRepository;
import com.aza.api.repository.masterData.UserRepository;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.DiscountReasonService;
import com.aza.api.service.masterData.UserService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DiscountService implements DiscountServiceInterface {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @PersistenceContext
    private EntityManager entityManager;
    private static final int BATCH_SIZE = 250; // Ajustado a 500

    @Autowired
    private DiscountRepository discountRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CicleService cicleService;
    @Autowired
    private DiscountReasonService discountReasonService;
    @Autowired
    private UserService userService;

    @Autowired
    private TransactionLogService transactionLogService;

    private static Map<Long, CicleDto> cicleMap;
    private static Map<Long, DiscountReasonDto> discountReasonMap;
    private static Map<Long, UserDto> userMap;

    @Autowired
    public DiscountService(CicleService cicleService,
            DiscountReasonService discountReasonService,
            UserService userService) {
        this.cicleService = cicleService;
        this.discountReasonService = discountReasonService;
        this.userService = userService;
        this.jwtService = null;
        this.userDetailsServiceImpl = null;
    }

    @Override
    public Discount create(Discount discount) {
        Discount savedDiscount = discountRepository.save(discount);
        return savedDiscount;

    }

    @Override
    public List<Discount> getAll() {
        List<Discount> ldiscounts = discountRepository.findAll();
        return ldiscounts;
    }

    @Override
    public void delete(Discount discount) {
        discountRepository.delete(discount);
    }

    @Override
    public void deleteAll() {
        discountRepository.deleteAll();
    }

    @Override
    public Optional<Discount> findById(Long id) {
        return discountRepository.findById(id);
    }

    @Override
    public GenericResponse add(DiscountDto record) {
        if (record.getId() != null) {
            Optional<Discount> currentDiscount = findById(record.getId());
            Discount discount = Discount.builder()
                    .id(record.getId())
                    .discountReason(record.getDiscountReason() != null ? record.getDiscountReason().getId() : null)
                    .settlementCicle(record.getSettlementCicle() != null ? record.getSettlementCicle().getId() : null)
                    .userId(record.getUserId() != null ? record.getUserId().getId() : null)
                    .discountDate(record.getDiscountDate() != null ? record.getDiscountDate() : null)
                    .amount(record.getAmount())
                    .creationDate(record.getCreationDate())
                    .lastUpdatedDate(record.getLastUpdatedDate())
                    .createdBy(record.getCreatedBy())
                    .lastUpdatedBy(record.getLastUpdatedBy())
                    .deleted(record.getDeleted())
                    .build();
            create(discount);
            createMasterDataMap();
            addTransactionLog(record);
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(record.getLastUpdatedBy()), userRepository.findByUsername(record.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(DiscountDto.DiscountToDiscountDto(discount, userMap, cicleMap, discountReasonMap))
                    .build();

        } else {
            Discount discount = Discount.builder()
                    .id(record.getId())
                    .discountReason(record.getDiscountReason() != null ? record.getDiscountReason().getId() : null)
                    .settlementCicle(record.getSettlementCicle() != null ? record.getSettlementCicle().getId() : null)
                    .userId(record.getUserId() != null ? record.getUserId().getId() : null)
                    .discountDate(record.getDiscountDate() != null ? record.getDiscountDate() : null)
                    .amount(record.getAmount())
                    .creationDate(record.getCreationDate())
                    .lastUpdatedDate(record.getLastUpdatedDate())
                    .createdBy(record.getCreatedBy())
                    .lastUpdatedBy(record.getLastUpdatedBy())
                    .deleted(record.getDeleted())
                    .build();
            create(discount);
            createMasterDataMap();
            addTransactionLog(record);
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(record.getLastUpdatedBy()), userRepository.findByUsername(record.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(DiscountDto.DiscountToDiscountDto(discount, userMap, cicleMap, discountReasonMap))
                    .build();
        }
    }

    @Transactional
    public GenericResponse saveAllDiscounts(List<DiscountDto> discounts, User authenticatedUser) {
        System.out.println("Inicia carga masiva de descuentos a bd (api)" + LocalDateTime.now().toString());
        List<Discount> ldiscounts = new ArrayList<>();
        for (DiscountDto cdto : discounts) {
            ldiscounts.add(DiscountDto.DiscountDtoToDiscount(cdto));
        }

        // Crear un mapa para búsqueda rápida de OC existentes por numero de  orden
        Map<String, Discount> existingDiscountsMap = new HashMap<>();
        for (Discount currentExist : getAll()) {
            existingDiscountsMap.put(currentExist.getUserId() + "_" + currentExist.getDiscountReason() + "_" + currentExist.getSettlementCicle(), currentExist);
        }

        // Actualizar IDs en ldiscounts
        for (Discount current : ldiscounts) {
            Discount existingDiscount = existingDiscountsMap.get(current.getUserId() + "_" + current.getDiscountReason() + "_" + current.getSettlementCicle());
            if (existingDiscount != null) {
                current.setId(existingDiscount.getId());
                current.setCreatedBy(existingDiscount.getCreatedBy());
                current.setCreationDate(existingDiscount.getCreationDate());
            } else {
                current.setCreatedBy(current.getLastUpdatedBy());
                current.setCreationDate(current.getLastUpdatedDate());
            }
        }
        int batchCount = 0;
        System.out.println("Inicia carga masiva de de Descuentos a bd proceso bacth" + LocalDateTime.now().toString());
        for (int i = 0; i < ldiscounts.size(); i++) {
            entityManager.merge(ldiscounts.get(i));
            batchCount++;

            if (batchCount % BATCH_SIZE == 0) {
                // Flush and clear the entity manager to free memory.
                System.out.println("Carga datos" + i);
                entityManager.flush();
                entityManager.clear();
                batchCount = 0;
            }
        }

        if (batchCount > 0) {
            entityManager.flush();
            entityManager.clear();
        }

        System.out.println("termina carga masiva de OC a bd (api)" + LocalDateTime.now().toString());
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        addTransactionLogLoad(discounts);
        return GenericResponse.builder()
                .token(token)
                .data(discounts)
                .build();
    }

    public List<Discount> getAllActive() {
        return discountRepository.findAllByDeletedFalse();
    }

    private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Cicle> lCicles = cicleService.getAllActive();
        List<CicleDto> lCiclesDto = new ArrayList<>();
        for (Cicle c : lCicles) {
            lCiclesDto.add(CicleDto.CicleToCicleDto(c));
        }
        cicleMap = lCiclesDto.stream()
                .collect(Collectors.toMap(CicleDto::getId, Function.identity()));

        List<DiscountReason> lDiscountReasons = discountReasonService.getAllActive();
        List<DiscountReasonDto> lDiscountReasonsDto = new ArrayList<>();
        for (DiscountReason d : lDiscountReasons) {
            lDiscountReasonsDto.add(DiscountReasonDto.DiscountReasonToDiscountReasonDto(d));
        }
        discountReasonMap = lDiscountReasonsDto.stream()
                .collect(Collectors.toMap(DiscountReasonDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

    }

    private void addTransactionLogLoad(List<DiscountDto> discountList) {
        for (DiscountDto currentDiscount : discountList) {
            TransactionLog newTL = new TransactionLog();
            newTL.setLogType("DESCUENTOS");
            newTL.setUniqueKey(currentDiscount.getUserId().getTaxid()+ "_" + currentDiscount.getDiscountReason().getDescription() + "_" + currentDiscount.getSettlementCicle().getDescription());
            newTL.setUserId(currentDiscount.getLastUpdatedBy());
            newTL.setLastUpdatedDate(LocalDateTime.now());
            newTL.setCreationDate(LocalDateTime.now());
            newTL.setUpdatedDate(LocalDateTime.now());
            newTL.setCreatedBy(currentDiscount.getCreatedBy());
            newTL.setLastUpdatedBy(currentDiscount.getLastUpdatedBy());
            newTL.setDeleted(Boolean.FALSE);
            newTL.setPayLoad(setPayload(currentDiscount));
            transactionLogService.create(newTL);
        }
    }

    private void addTransactionLog(DiscountDto currentDiscount) {
        TransactionLog newTL = new TransactionLog();
        newTL.setLogType("DESCUENTOS");
        newTL.setUniqueKey(currentDiscount.getUserId().getTaxid()+ "_" + currentDiscount.getDiscountReason().getDescription() + "_" + currentDiscount.getSettlementCicle().getDescription());
        newTL.setUserId(currentDiscount.getLastUpdatedBy());
        newTL.setLastUpdatedDate(LocalDateTime.now());
        newTL.setCreationDate(LocalDateTime.now());
        newTL.setUpdatedDate(LocalDateTime.now());
        newTL.setCreatedBy(currentDiscount.getCreatedBy());
        newTL.setLastUpdatedBy(currentDiscount.getLastUpdatedBy());
        newTL.setDeleted(Boolean.FALSE);
        newTL.setPayLoad(setPayload(currentDiscount));
        transactionLogService.create(newTL);
    }

    private String setPayload(DiscountDto currentDiscount) {
        return "USUARIO:" + currentDiscount.getUserId().getFullname()
                + "\nMOTIVO DESCUENTO:" + currentDiscount.getDiscountReason().getDescription()    
                + "\nCICLO:" + currentDiscount.getSettlementCicle().getDescription()
                + "\nVALOR DESCUENTO:" + currentDiscount.getAmount();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.repository.masterData.PurchaseOrderStatusRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class PurchaseOrderStatusService implements PurchaseOrderStatusServiceInterface {

    @Autowired
    private PurchaseOrderStatusRepository purchaseOrderStatusRepository;

    @Override
    public PurchaseOrderStatus create(PurchaseOrderStatus purchaseOrderStatus) {
        return purchaseOrderStatusRepository.save(purchaseOrderStatus);
        //return PurchaseOrderStatusRepository.save(new PurchaseOrderStatus(purchaseOrderStatus.getId(),purchaseOrderStatus.getCodigo(),purchaseOrderStatus.getDescripcion()));
    }

    @Override
    public List<PurchaseOrderStatus> getAll() {
        return purchaseOrderStatusRepository.findAll();
    }

    @Override
    public void delete(PurchaseOrderStatus purchaseOrderStatus) {
        purchaseOrderStatusRepository.delete(purchaseOrderStatus);
    }

    @Override
    public void deleteAll() {
        purchaseOrderStatusRepository.deleteAll();
    }

    @Override
    public PurchaseOrderStatus findById(Long id) {
        return purchaseOrderStatusRepository.findById(id).get();
    }

    public List<PurchaseOrderStatus> getAllActive() {
        return purchaseOrderStatusRepository.findAllByDeletedFalse();
    }

}

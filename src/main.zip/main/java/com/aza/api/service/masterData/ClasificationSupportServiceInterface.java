/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ClasificationSupport;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ClasificationSupportServiceInterface {

    ClasificationSupport create(ClasificationSupport clasificationSupport);

    void delete(ClasificationSupport clasificationSupport);

    void deleteAll();

    ClasificationSupport findById(Long id);

    List<ClasificationSupport> getAll();

}

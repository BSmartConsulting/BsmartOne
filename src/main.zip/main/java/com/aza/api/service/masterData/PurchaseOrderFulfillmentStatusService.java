/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.PurchaseOrderFulfillmentStatus;
import com.aza.api.repository.masterData.PurchaseOrderFulfillmentStatusRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class PurchaseOrderFulfillmentStatusService implements PurchaseOrderFulfillmentStatusServiceInterface {

    @Autowired
    private PurchaseOrderFulfillmentStatusRepository purchaseOrderFulfillmentStatusRepository;

    @Override
    public PurchaseOrderFulfillmentStatus create(PurchaseOrderFulfillmentStatus purchaseOrderFulfillmentStatus) {
        return purchaseOrderFulfillmentStatusRepository.save(purchaseOrderFulfillmentStatus);
        //return PurchaseOrderFulfillmentStatusRepository.save(new PurchaseOrderFulfillmentStatus(purchaseOrderFulfillmentStatus.getId(),purchaseOrderFulfillmentStatus.getCodigo(),purchaseOrderFulfillmentStatus.getDescripcion()));
    }

    @Override
    public List<PurchaseOrderFulfillmentStatus> getAll() {
        return purchaseOrderFulfillmentStatusRepository.findAll();
    }

    @Override
    public void delete(PurchaseOrderFulfillmentStatus purchaseOrderFulfillmentStatus) {
        purchaseOrderFulfillmentStatusRepository.delete(purchaseOrderFulfillmentStatus);
    }

    @Override
    public void deleteAll() {
        purchaseOrderFulfillmentStatusRepository.deleteAll();
    }

    @Override
    public PurchaseOrderFulfillmentStatus findById(Long id) {
        return purchaseOrderFulfillmentStatusRepository.findById(id).get();
    }

    public List<PurchaseOrderFulfillmentStatus> getAllActive() {
        return purchaseOrderFulfillmentStatusRepository.findAllByDeletedFalse();
    }

    public PurchaseOrderFulfillmentStatus findByDescription(String status) {
        return purchaseOrderFulfillmentStatusRepository.findByDescription(status);
    }

}

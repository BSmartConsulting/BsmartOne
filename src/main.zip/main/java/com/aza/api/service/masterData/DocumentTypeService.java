/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.DocumentType;
import com.aza.api.repository.masterData.DocumentTypeRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class DocumentTypeService implements DocumentTypeServiceInterface {

    @Autowired
    private DocumentTypeRepository documentTypeRepository;

    @Override
    public DocumentType create(DocumentType documentType) {
        return documentTypeRepository.save(documentType);
        //return DocumentTypeRepository.save(new DocumentType(documentType.getId(),documentType.getCodigo(),documentType.getDescripcion()));
    }

    @Override
    public List<DocumentType> getAll() {
        return documentTypeRepository.findAll();
    }

    @Override
    public void delete(DocumentType documentType) {
        documentTypeRepository.delete(documentType);
    }

    @Override
    public void deleteAll() {
        documentTypeRepository.deleteAll();
    }

    @Override
    public DocumentType findById(Long id) {
        return documentTypeRepository.findById(id).get();
    }

}

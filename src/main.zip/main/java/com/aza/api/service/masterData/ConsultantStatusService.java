/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ConsultantStatus;
import com.aza.api.repository.masterData.ConsultantStatusRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ConsultantStatusService implements ConsultantStatusServiceInterface {

    @Autowired
    private ConsultantStatusRepository consultantStatusRepository;

    @Override
    public ConsultantStatus create(ConsultantStatus consultantStatus) {
        return consultantStatusRepository.save(consultantStatus);
        //return ConsultantStatusRepository.save(new ConsultantStatus(consultantStatus.getId(),consultantStatus.getCodigo(),consultantStatus.getDescripcion()));
    }

    @Override
    public List<ConsultantStatus> getAll() {
        return consultantStatusRepository.findAll();
    }

    @Override
    public void delete(ConsultantStatus consultantStatus) {
        consultantStatusRepository.delete(consultantStatus);
    }

    @Override
    public void deleteAll() {
        consultantStatusRepository.deleteAll();
    }

    @Override
    public ConsultantStatus findById(Long id) {
        return consultantStatusRepository.findById(id).get();
    }

    public List<ConsultantStatus> getAllActive() {
        return consultantStatusRepository.findAllByDeletedFalse();
    }

}

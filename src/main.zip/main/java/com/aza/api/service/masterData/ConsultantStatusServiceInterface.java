/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ConsultantStatus;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ConsultantStatusServiceInterface {

    ConsultantStatus create(ConsultantStatus consultantStatus);

    void delete(ConsultantStatus consultantStatus);

    void deleteAll();

    ConsultantStatus findById(Long id);

    List<ConsultantStatus> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.model.TransactionLog;
import com.aza.api.repository.TransactionLogRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jaime
 */
@Service
public class TransactionLogService implements TransactionLogServiceInterface {

    @Autowired
    private TransactionLogRepository transactionLogRepository;

    @Override
    public TransactionLog create(TransactionLog transactionLog) {
        return transactionLogRepository.save(transactionLog);
    }

    @Override
    public List<TransactionLog> getAll() {
        return transactionLogRepository.findAll();
    }

    @Override
    public void delete(TransactionLog transactionLog) {
        transactionLogRepository.delete(transactionLog);
    }

    @Override
    public void deleteAll() {
        transactionLogRepository.deleteAll();
    }

    @Override
    public Optional<TransactionLog> findById(Long id) {
        return transactionLogRepository.findById(id);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.DiscountReason;
import com.aza.api.repository.masterData.DiscountReasonRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class DiscountReasonService implements DiscountReasonServiceInterface {

    @Autowired
    private DiscountReasonRepository discountReasonRepository;

    @Override
    public DiscountReason create(DiscountReason discountReason) {
        return discountReasonRepository.save(discountReason);
        //return DiscountReasonRepository.save(new DiscountReason(discountReason.getId(),discountReason.getCodigo(),discountReason.getDescripcion()));
    }

    @Override
    public List<DiscountReason> getAll() {
        return discountReasonRepository.findAll();
    }

    @Override
    public void delete(DiscountReason discountReason) {
        discountReasonRepository.delete(discountReason);
    }

    @Override
    public void deleteAll() {
        discountReasonRepository.deleteAll();
    }

    @Override
    public DiscountReason findById(Long id) {
        return discountReasonRepository.findById(id).get();
    }

    public List<DiscountReason> getAllActive() {
        return discountReasonRepository.findAllByDeletedFalse();
    }

}

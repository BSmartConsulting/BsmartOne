/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.UserType;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface UserTypeServiceInterface {

    UserType create(UserType userType);

    void delete(UserType userType);

    void deleteAll();

    Optional<UserType> findById(Long id);

    List<UserType> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.CicleType;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface CicleTypeServiceInterface {

    CicleType create(CicleType cicleType);

    void delete(CicleType cicleType);

    void deleteAll();

    CicleType findById(Long id);

    List<CicleType> getAll();

}

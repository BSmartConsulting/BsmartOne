/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.DocumentType;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface DocumentTypeServiceInterface {

    DocumentType create(DocumentType documentType);

    void delete(DocumentType documentType);

    void deleteAll();

    DocumentType findById(Long id);

    List<DocumentType> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.model.PurchaseOrderFulfillmentSupportFile;
import com.aza.api.repository.PurchaseOrderFulfillmentSupportFileRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jaime
 */
@Service
public class PurchaseOrderFulfillmentSupportFileService implements PurchaseOrderFulfillmentSupportFileServiceInterface {

    @Autowired
    private PurchaseOrderFulfillmentSupportFileRepository purchaseOrderFulfillmentSupportFileRepository;

    @Override
    public PurchaseOrderFulfillmentSupportFile create(PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFile) {
        return purchaseOrderFulfillmentSupportFileRepository.save(purchaseOrderFulfillmentSupportFile);
    }

    @Override
    public List<PurchaseOrderFulfillmentSupportFile> getAll() {
        return purchaseOrderFulfillmentSupportFileRepository.findAllByDeletedFalse();
    }

    @Override
    public void delete(PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFile) {
        purchaseOrderFulfillmentSupportFileRepository.delete(purchaseOrderFulfillmentSupportFile);
    }

    @Override
    public void deleteAll() {
        purchaseOrderFulfillmentSupportFileRepository.deleteAll();
    }

    @Override
    public Optional<PurchaseOrderFulfillmentSupportFile> findById(Long id) {
        return purchaseOrderFulfillmentSupportFileRepository.findById(id);
    }

    public GenericResponse add(PurchaseOrderFulfillmentSupportFile request) {
        return null;
    }

    @Override
    public void delete(PurchaseOrderFulfillmentSupportFileService purchaseOrderFulfillmentSupportFile) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<PurchaseOrderFulfillmentSupportFile> findByPurchaseOrderFulfillment(Long purchaseOrderFulfillment) {
        //return purchaseOrderFulfillmentSupportFileRepository.findByPurchaseOrderFulfillment(purchaseOrderFulfillment);
        return purchaseOrderFulfillmentSupportFileRepository.findByPurchaseOrderFulfillmentAndDeletedFalse(purchaseOrderFulfillment);
    }

}

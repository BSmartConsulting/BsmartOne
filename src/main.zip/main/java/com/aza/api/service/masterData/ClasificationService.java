/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Clasification;
import com.aza.api.repository.masterData.ClasificationRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ClasificationService implements ClasificationServiceInterface {

    @Autowired
    private ClasificationRepository clasificationRepository;

    @Override
    public Clasification create(Clasification clasification) {
        return clasificationRepository.save(clasification);
        //return ClasificationRepository.save(new Clasification(clasification.getId(),clasification.getCodigo(),clasification.getDescripcion()));
    }

    @Override
    public List<Clasification> getAll() {
        return clasificationRepository.findAll();
    }

    @Override
    public void delete(Clasification clasification) {
        clasificationRepository.delete(clasification);
    }

    @Override
    public void deleteAll() {
        clasificationRepository.deleteAll();
    }

    @Override
    public Clasification findById(Long id) {
        return clasificationRepository.findById(id).get();
    }

    public List<Clasification> getAllActive() {
        return clasificationRepository.findAllByDeletedFalse();
    }

}

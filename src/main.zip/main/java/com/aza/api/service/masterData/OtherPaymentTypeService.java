/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.OtherPaymentType;
import com.aza.api.repository.masterData.OtherPaymentTypeRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jaime
 */
@Service
public class OtherPaymentTypeService implements OtherPaymentTypeServiceInterface {

    @Autowired
    private OtherPaymentTypeRepository otherPaymentTypesRepository;

    @Override
    public OtherPaymentType create(OtherPaymentType userType) {
        return otherPaymentTypesRepository.save(userType);
    }

    @Override
    public List<OtherPaymentType> getAll() {
        return otherPaymentTypesRepository.findAll();
    }

    @Override
    public void delete(OtherPaymentType userType) {
        otherPaymentTypesRepository.delete(userType);
    }

    @Override
    public void deleteAll() {
        otherPaymentTypesRepository.deleteAll();
    }

    @Override
    public Optional<OtherPaymentType> findById(Long id) {
        return otherPaymentTypesRepository.findById(id);
    }

    public List<OtherPaymentType> getAllActive() {
        return otherPaymentTypesRepository.findAllByDeletedFalse();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ClasificationSupport;
import com.aza.api.repository.masterData.ClasificationSupportRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ClasificationSupportService implements ClasificationSupportServiceInterface {

    @Autowired
    private ClasificationSupportRepository clasificationSupportRepository;

    @Override
    public ClasificationSupport create(ClasificationSupport clasificationSupport) {
        return clasificationSupportRepository.save(clasificationSupport);
        //return ClasificationSupportRepository.save(new ClasificationSupport(clasificationSupport.getId(),clasificationSupport.getCodigo(),clasificationSupport.getDescripcion()));
    }

    @Override
    public List<ClasificationSupport> getAll() {
        return clasificationSupportRepository.findAll();
    }

    @Override
    public void delete(ClasificationSupport clasificationSupport) {
        clasificationSupportRepository.delete(clasificationSupport);
    }

    @Override
    public void deleteAll() {
        clasificationSupportRepository.deleteAll();
    }

    @Override
    public ClasificationSupport findById(Long id) {
        return clasificationSupportRepository.findById(id).get();
    }

    public List<ClasificationSupport> getAllActive() {
        return clasificationSupportRepository.findAllByDeletedFalse();
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.DiscountDto;
import com.aza.api.model.Discount;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface DiscountServiceInterface {

    GenericResponse add(DiscountDto request);

    Discount create(Discount discount);

    void delete(Discount discount);

    void deleteAll();

    Optional<Discount> findById(Long id);

    List<Discount> getAll();

}

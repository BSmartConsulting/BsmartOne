/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.DiscountReason;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface DiscountReasonServiceInterface {

    DiscountReason create(DiscountReason discountReason);

    void delete(DiscountReason discountReason);

    void deleteAll();

    DiscountReason findById(Long id);

    List<DiscountReason> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ConsultantSpecialty;
import com.aza.api.repository.masterData.ConsultantSpecialtyRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ConsultantSpecialtyService implements ConsultantSpecialtyServiceInterface {

    @Autowired
    private ConsultantSpecialtyRepository consultantSpecialtyRepository;

    @Override
    public ConsultantSpecialty create(ConsultantSpecialty consultantSpecialty) {
        return consultantSpecialtyRepository.save(consultantSpecialty);
        //return ConsultantSpecialtyRepository.save(new ConsultantSpecialty(consultantSpecialty.getId(),consultantSpecialty.getCodigo(),consultantSpecialty.getDescripcion()));
    }

    @Override
    public List<ConsultantSpecialty> getAll() {
        return consultantSpecialtyRepository.findAll();
    }

    @Override
    public void delete(ConsultantSpecialty consultantSpecialty) {
        consultantSpecialtyRepository.delete(consultantSpecialty);
    }

    @Override
    public void deleteAll() {
        consultantSpecialtyRepository.deleteAll();
    }

    @Override
    public ConsultantSpecialty findById(Long id) {
        return consultantSpecialtyRepository.findById(id).get();
    }

    public List<ConsultantSpecialty> getAllActive() {
        return consultantSpecialtyRepository.findAllByDeletedFalse();
    }

}

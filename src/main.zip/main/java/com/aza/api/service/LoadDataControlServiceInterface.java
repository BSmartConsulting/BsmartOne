/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.model.LoadDataControl;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface LoadDataControlServiceInterface {

    LoadDataControl create(LoadDataControl loadDataControl);

    void delete(LoadDataControl loadDataControl);

    void deleteAll();

    Optional<LoadDataControl> findById(Long id);

    List<LoadDataControl> getAll();

}

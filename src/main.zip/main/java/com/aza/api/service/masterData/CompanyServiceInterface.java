/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Company;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface CompanyServiceInterface {

    Company create(Company company);

    void delete(Company company);

    void deleteAll();

    Company findById(Long id);

    List<Company> getAll();

}

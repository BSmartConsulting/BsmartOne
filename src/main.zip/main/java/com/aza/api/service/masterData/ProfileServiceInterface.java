/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Profile;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ProfileServiceInterface {

    Profile create(Profile profile);

    void delete(Profile profile);

    void deleteAll();

    Profile findById(Long id);

    List<Profile> getAll();

}

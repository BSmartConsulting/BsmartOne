/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.OtherPaymentDto;
import com.aza.api.model.OtherPayment;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface OtherPaymentServiceInterface {

    GenericResponse add(OtherPaymentDto request);

    OtherPayment create(OtherPayment discount);

    void delete(OtherPayment discount);

    void deleteAll();

    Optional<OtherPayment> findById(Long id);

    List<OtherPayment> getAll();

}

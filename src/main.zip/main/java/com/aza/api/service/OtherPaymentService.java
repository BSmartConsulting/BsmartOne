package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.OtherPaymentDto;
import com.aza.api.dto.masterData.CicleDto;
import com.aza.api.dto.masterData.OtherPaymentTypeDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.OtherPayment;
import com.aza.api.model.TransactionLog;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.OtherPaymentType;
import com.aza.api.model.masterData.User;
import com.aza.api.repository.OtherPaymentRepository;
import com.aza.api.repository.masterData.UserRepository;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.OtherPaymentTypeService;
import com.aza.api.service.masterData.UserService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OtherPaymentService implements OtherPaymentServiceInterface {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @PersistenceContext
    private EntityManager entityManager;
    private static final int BATCH_SIZE = 250; // Ajustado a 500

    @Autowired
    private OtherPaymentRepository discountRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CicleService cicleService;
    @Autowired
    private OtherPaymentTypeService otherPaymentTypeService;
    @Autowired
    private UserService userService;

    @Autowired
    private TransactionLogService transactionLogService;

    private static Map<Long, CicleDto> cicleMap;
    private static Map<Long, OtherPaymentTypeDto> otherPaymentTypeMap;
    private static Map<Long, UserDto> userMap;

    @Autowired
    public OtherPaymentService(CicleService cicleService,
            OtherPaymentTypeService otherPaymentTypeService,
            UserService userService) {
        this.cicleService = cicleService;
        this.otherPaymentTypeService = otherPaymentTypeService;
        this.userService = userService;
        this.jwtService = null;
        this.userDetailsServiceImpl = null;
    }

    @Override
    public OtherPayment create(OtherPayment discount) {
        OtherPayment savedOtherPayment = discountRepository.save(discount);
        return savedOtherPayment;

    }

    @Override
    public List<OtherPayment> getAll() {
        List<OtherPayment> ldiscounts = discountRepository.findAll();
        return ldiscounts;
    }

    @Override
    public void delete(OtherPayment discount) {
        discountRepository.delete(discount);
    }

    @Override
    public void deleteAll() {
        discountRepository.deleteAll();
    }

    @Override
    public Optional<OtherPayment> findById(Long id) {
        return discountRepository.findById(id);
    }

    @Override
    public GenericResponse add(OtherPaymentDto record) {
        if (record.getId() != null) {
            Optional<OtherPayment> currentOtherPayment = findById(record.getId());
            OtherPayment discount = OtherPayment.builder()
                    .id(record.getId())
                    .otherpaymenttype(record.getOtherPaymentType()!= null ? record.getOtherPaymentType().getId() : null)
                    .settlementCicle(record.getSettlementCicle() != null ? record.getSettlementCicle().getId() : null)
                    .user(record.getUser() != null ? record.getUser().getId() : null)
                    .amount(record.getAmount())
                    .creationDate(record.getCreationDate())
                    .lastUpdatedDate(record.getLastUpdatedDate())
                    .createdBy(record.getCreatedBy())
                    .lastUpdatedBy(record.getLastUpdatedBy())
                    .deleted(record.getDeleted())
                    .build();
            create(discount);
            createMasterDataMap();
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(record.getLastUpdatedBy()), userRepository.findByUsername(record.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(OtherPaymentDto.OtherPaymentToOtherPaymentDto(discount, userMap, cicleMap, otherPaymentTypeMap))
                    .build();

        } else {
            OtherPayment discount = OtherPayment.builder()
                    .id(record.getId())
                    .otherpaymenttype(record.getOtherPaymentType()!= null ? record.getOtherPaymentType().getId() : null)
                    .settlementCicle(record.getSettlementCicle() != null ? record.getSettlementCicle().getId() : null)
                    .user(record.getUser() != null ? record.getUser().getId() : null)
                    .amount(record.getAmount())
                    .creationDate(record.getCreationDate())
                    .lastUpdatedDate(record.getLastUpdatedDate())
                    .createdBy(record.getCreatedBy())
                    .lastUpdatedBy(record.getLastUpdatedBy())
                    .deleted(record.getDeleted())
                    .build();
            create(discount);
            createMasterDataMap();
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(record.getLastUpdatedBy()), userRepository.findByUsername(record.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(OtherPaymentDto.OtherPaymentToOtherPaymentDto(discount, userMap, cicleMap, otherPaymentTypeMap))
                    .build();
        }
    }

    @Transactional
    public GenericResponse saveAllOtherPayments(List<OtherPaymentDto> discounts, User authenticatedUser) {
        System.out.println("Inicia carga masiva de descuentos a bd (api)" + LocalDateTime.now().toString());
        List<OtherPayment> ldiscounts = new ArrayList<>();
        for (OtherPaymentDto cdto : discounts) {
            ldiscounts.add(OtherPaymentDto.OtherPaymentDtoToOtherPayment(cdto));
        }

        // Crear un mapa para búsqueda rápida de OC existentes por numero de  orden
        Map<String, OtherPayment> existingOtherPaymentsMap = new HashMap<>();
        for (OtherPayment currentExist : getAll()) {
            existingOtherPaymentsMap.put(currentExist.getUser() + "_" + currentExist.getOtherpaymenttype()+ "_" + currentExist.getSettlementCicle(), currentExist);
        }

        // Actualizar IDs en ldiscounts
        for (OtherPayment current : ldiscounts) {
            OtherPayment existingOtherPayment = existingOtherPaymentsMap.get(current.getUser() + "_" + current.getOtherpaymenttype()+ "_" + current.getSettlementCicle());
            if (existingOtherPayment != null) {
                current.setId(existingOtherPayment.getId());
                current.setCreatedBy(existingOtherPayment.getCreatedBy());
                current.setCreationDate(existingOtherPayment.getCreationDate());
            } else {
                current.setCreatedBy(current.getLastUpdatedBy());
                current.setCreationDate(current.getLastUpdatedDate());
            }
        }
        int batchCount = 0;
        System.out.println("Inicia carga masiva de de Descuentos a bd proceso bacth" + LocalDateTime.now().toString());
        for (int i = 0; i < ldiscounts.size(); i++) {
            entityManager.merge(ldiscounts.get(i));
            batchCount++;

            if (batchCount % BATCH_SIZE == 0) {
                // Flush and clear the entity manager to free memory.
                System.out.println("Carga datos" + i);
                entityManager.flush();
                entityManager.clear();
                batchCount = 0;
            }
        }

        if (batchCount > 0) {
            entityManager.flush();
            entityManager.clear();
        }

        System.out.println("termina carga masiva de OC a bd (api)" + LocalDateTime.now().toString());
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.builder()
                .token(token)
                .data(discounts)
                .build();
    }

    public List<OtherPayment> getAllActive() {
        return discountRepository.findAllByDeletedFalse();
    }

    private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Cicle> lCicles = cicleService.getAllActive();
        List<CicleDto> lCiclesDto = new ArrayList<>();
        for (Cicle c : lCicles) {
            lCiclesDto.add(CicleDto.CicleToCicleDto(c));
        }
        cicleMap = lCiclesDto.stream()
                .collect(Collectors.toMap(CicleDto::getId, Function.identity()));

        List<OtherPaymentType> lOtherPaymentTypes = otherPaymentTypeService.getAllActive();
        List<OtherPaymentTypeDto> lOtherPaymentTypesDto = new ArrayList<>();
        for (OtherPaymentType d : lOtherPaymentTypes) {
            lOtherPaymentTypesDto.add(OtherPaymentTypeDto.OtherPaymentTypeToOtherPaymentTypeDto(d));
        }
        otherPaymentTypeMap = lOtherPaymentTypesDto.stream()
                .collect(Collectors.toMap(OtherPaymentTypeDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

    }
}

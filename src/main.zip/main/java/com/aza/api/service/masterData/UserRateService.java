/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.UserRate;
import com.aza.api.repository.masterData.ProfileRateRepository;
import com.aza.api.service.TransactionLogService;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class UserRateService implements ProfileRateServiceInterface {

    @Autowired
    private ProfileRateRepository profileRateRepository;

    @Autowired
    private TransactionLogService transactionLogService;

    private static final LocalDateTime END_OF_TIME = LocalDateTime.of(9999, 12, 31, 23, 59, 59);

    @Override
    public UserRate create(UserRate currentRate) {
        boolean newRate = true;
        List<UserRate> userRateList = getAll();
        if(currentRate.getId()!=null)
        {
            newRate=false;
        }
        if (currentRate.getId() == null) {
            for (UserRate current : userRateList) {
                if (current.getArlid().equals(currentRate.getArlid())
                        && current.getUserid().equals(currentRate.getUserid())
                        && current.getRatetype().equals(currentRate.getRatetype())
                        && current.getStartdate().equals(currentRate.getStartdate())) {
                    currentRate.setId(current.getId());
                    currentRate.setDeleted(false);
                    newRate = false;
                    break;
                }
            }
        }
        UserRate resp = profileRateRepository.save(currentRate);
        if (newRate) {
            for (UserRate current : userRateList) {
                if (current.getArlid().equals(currentRate.getArlid())
                        && current.getUserid().equals(currentRate.getUserid())
                        && current.getRatetype().equals(currentRate.getRatetype())
                        && current.getEnddate().equals(END_OF_TIME)) {
                    current.setEnddate(currentRate.getStartdate());
                    resp = profileRateRepository.save(current);
                    break;
                }
            }
        }
        return resp;
    }

    @Override
    public List<UserRate> getAll() {
        return profileRateRepository.findAll();
    }

    @Override
    public void delete(UserRate profileRate) {
        profileRateRepository.delete(profileRate);
    }

    @Override
    public void deleteAll() {
        profileRateRepository.deleteAll();
    }

    @Override
    public UserRate findById(Long id) {
        return profileRateRepository.findById(id).get();
    }

    public List<UserRate> getAllActive() {
        return profileRateRepository.findAllByDeletedFalse();
    }

}

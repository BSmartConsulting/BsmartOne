/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.FrontEndMessage;
import com.aza.api.repository.masterData.FrontEndMessageRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jaime
 */
@Service
public class FrontEndMessageService implements FrontEndMessageServiceInterface {

    @Autowired
    private FrontEndMessageRepository frontEndMessagesRepository;

    @Override
    public FrontEndMessage create(FrontEndMessage frontEndMessage) {
        return frontEndMessagesRepository.save(frontEndMessage);
    }

    @Override
    public List<FrontEndMessage> getAll() {
        return frontEndMessagesRepository.findAll();
    }

    @Override
    public void delete(FrontEndMessage frontEndMessage) {
        frontEndMessagesRepository.delete(frontEndMessage);
    }

    @Override
    public void deleteAll() {
        frontEndMessagesRepository.deleteAll();
    }

    @Override
    public FrontEndMessage findById(long id) {
        return frontEndMessagesRepository.findById(id);
    }

    public List<FrontEndMessage> getAllActive() {
        return frontEndMessagesRepository.findAllByDeletedFalse();
    }

}

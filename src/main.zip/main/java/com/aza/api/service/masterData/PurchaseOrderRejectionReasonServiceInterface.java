/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.PurchaseOrderRejectionReason;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface PurchaseOrderRejectionReasonServiceInterface {

    PurchaseOrderRejectionReason create(PurchaseOrderRejectionReason purchaseOrderRejectionReason);

    void delete(PurchaseOrderRejectionReason purchaseOrderRejectionReason);

    void deleteAll();

    PurchaseOrderRejectionReason findById(Long id);

    List<PurchaseOrderRejectionReason> getAll();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ARL;
import com.aza.api.repository.masterData.ARLRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ARLService implements ARLServiceInterface {

    @Autowired
    private ARLRepository arlRepository;

    @Override
    public ARL create(ARL arl) {
        return arlRepository.save(arl);
    }

    @Override
    public List<ARL> getAll() {
        return arlRepository.findAll();
    }

    @Override
    public void delete(ARL arl) {
        arlRepository.delete(arl);
    }

    @Override
    public void deleteAll() {
        arlRepository.deleteAll();
    }

    @Override
    public ARL findById(Long id) {
        return arlRepository.findById(id).get();
    }

    @Override
    public List<ARL> getAllActive() {
        return arlRepository.findAllByDeletedFalse();
    }

    public ARL findByDescription(String arl) {
        return arlRepository.findByDescription(arl);
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.PurchaseOrderRejectionReason;
import com.aza.api.repository.masterData.PurchaseOrderRejectionReasonRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class PurchaseOrderRejectionReasonService implements PurchaseOrderRejectionReasonServiceInterface {

    @Autowired
    private PurchaseOrderRejectionReasonRepository purchaseOrderRejectionReasonRepository;

    @Override
    public PurchaseOrderRejectionReason create(PurchaseOrderRejectionReason purchaseOrderRejectionReason) {
        return purchaseOrderRejectionReasonRepository.save(purchaseOrderRejectionReason);
        //return PurchaseOrderRejectionReasonRepository.save(new PurchaseOrderRejectionReason(purchaseOrderRejectionReason.getId(),purchaseOrderRejectionReason.getCodigo(),purchaseOrderRejectionReason.getDescripcion()));
    }

    @Override
    public List<PurchaseOrderRejectionReason> getAll() {
        return purchaseOrderRejectionReasonRepository.findAll();
    }

    @Override
    public void delete(PurchaseOrderRejectionReason purchaseOrderRejectionReason) {
        purchaseOrderRejectionReasonRepository.delete(purchaseOrderRejectionReason);
    }

    @Override
    public void deleteAll() {
        purchaseOrderRejectionReasonRepository.deleteAll();
    }

    @Override
    public PurchaseOrderRejectionReason findById(Long id) {
        return purchaseOrderRejectionReasonRepository.findById(id).get();
    }

    public List<PurchaseOrderRejectionReason> getAllActive() {
        return purchaseOrderRejectionReasonRepository.findAllByDeletedFalse();
    }

}

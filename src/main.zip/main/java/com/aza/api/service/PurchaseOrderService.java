package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.PurchaseOrderDto;
import com.aza.api.dto.masterData.ARLDto;
import com.aza.api.dto.masterData.CityDto;
import com.aza.api.dto.masterData.ClasificationDto;
import com.aza.api.dto.masterData.CompanyDto;
import com.aza.api.dto.masterData.ProductDto;
import com.aza.api.dto.masterData.PurchaseOrderStatusDto;
import com.aza.api.dto.masterData.TaskDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.PurchaseOrder;
import com.aza.api.model.masterData.ARL;
import com.aza.api.model.masterData.City;
import com.aza.api.model.masterData.Clasification;
import com.aza.api.model.masterData.Company;
import com.aza.api.model.masterData.Product;
import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.model.masterData.Task;
import com.aza.api.model.masterData.User;
import com.aza.api.repository.PurchaseOrderRepository;
import com.aza.api.repository.masterData.UserRepository;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.CityService;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PurchaseOrderService implements PurchaseOrderServiceInterface {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @PersistenceContext
    private EntityManager entityManager;
    private static final int BATCH_SIZE = 250; // Ajustado a 500

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CompanyService companyService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ClasificationService clasificationService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private UserService userService;
    @Autowired
    private CityService cityService;
    @Autowired
    private PurchaseOrderStatusService purchaseOrderStatusService;
    @Autowired
    private ARLService arlService;

    @Autowired
    private EmailService emailService;

    private static Map<Long, CompanyDto> companyMap;
    private static Map<Long, ProductDto> productMap;
    private static Map<Long, TaskDto> taskMap;
    private static Map<Long, ClasificationDto> clasificationMap;
    private static Map<Long, UserDto> userMap;
    private static Map<Long, CityDto> cityMap;
    private static Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap;
    private static Map<Long, ARLDto> arlMap;

    @Autowired
    public PurchaseOrderService(CompanyService companyService,
            ProductService productService,
            ClasificationService clasificationService,
            TaskService taskService,
            UserService userService,
            CityService cityService,
            PurchaseOrderStatusService purchaseOrderStatusService,
            ARLService arlService) {
        this.companyService = companyService;
        this.productService = productService;
        this.clasificationService = clasificationService;
        this.taskService = taskService;
        this.userService = userService;
        this.cityService = cityService;
        this.purchaseOrderStatusService = purchaseOrderStatusService;
        this.arlService = arlService;
        this.jwtService = null;
        this.userDetailsServiceImpl = null;
    }

    @Override
    public PurchaseOrder create(PurchaseOrder purchaseOrder) {
        PurchaseOrder savedPurchaseOrder = purchaseOrderRepository.save(purchaseOrder);
        return savedPurchaseOrder;

    }

    @Override
    public List<PurchaseOrder> getAll() {
        List<PurchaseOrder> lpurchaseOrders = purchaseOrderRepository.findAll();
        return lpurchaseOrders;
    }

    @Override
    public void delete(PurchaseOrder purchaseOrder) {
        purchaseOrderRepository.delete(purchaseOrder);
    }

    @Override
    public void deleteAll() {
        purchaseOrderRepository.deleteAll();
    }

    @Override
    public Optional<PurchaseOrder> findById(Long id) {
        return purchaseOrderRepository.findById(id);
    }

    @Override
    public GenericResponse add(PurchaseOrderDto request, String op) {
        if (request.getId() != null) {
            Optional<PurchaseOrder> currentPurchaseOrder = findById(request.getId());
            PurchaseOrder purchaseOrder = PurchaseOrder.builder()
                    .id(request.getId())
                    .purchaseOrderNumber(currentPurchaseOrder.get().getPurchaseOrderNumber())
                    .company(request.getCompany().getId())
                    .product(request.getProduct().getId())
                    .task(request.getTask().getId())
                    .clasification(request.getClasification().getId())
                    .user(request.getUser().getId())
                    .approvalDate(request.getApprovalDate())
                    .cityOfOrigin(request.getCityOfOrigin().getId())
                    .destinationCity(request.getDestinationCity().getId())
                    .purchaseOrderStatus(request.getPurchaseOrderStatus().getId())
                    .requestedHours(request.getRequestedHours())
                    .executedhours(request.getExecutedhours())
                    .availablehours(request.getAvailablehours())
                    .observation(request.getObservation())
                    .arl(request.getArl().getId())
                    .requiresReport(request.isRequiresReport())
                    .requiresTransportation(request.isRequiresTransportation())
                    .customPurchaseOrderRate(request != null ? Boolean.TRUE.equals(request.isCustomPurchaseOrderRate()) : false)
                    .customPurchaseOrderRateValue(request.getCustomPurchaseOrderRateValue() != null ? request.getCustomPurchaseOrderRateValue() : Double.valueOf("0"))
                    .creationDate(currentPurchaseOrder.get().getCreationDate())
                    .lastUpdatedDate(request.getLastUpdatedDate())
                    .createdBy(currentPurchaseOrder.get().getCreatedBy())
                    .lastUpdatedBy(request.getLastUpdatedBy())
                    .deleted(request.getDeleted())
                    .build();
            create(purchaseOrder);
            createMasterDataMap();
            PurchaseOrderDto poDto = PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(purchaseOrder,
                    companyMap, productMap, taskMap, clasificationMap, userMap, cityMap, purchaseOrderStatusMap, arlMap);

            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(request.getLastUpdatedBy()), userRepository.findByUsername(request.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(poDto)
                    .build();

        } else {
            PurchaseOrder purchaseOrder = PurchaseOrder.builder()
                    .id(request.getId())
                    .purchaseOrderNumber(request.getPurchaseOrderNumber())
                    .company(request.getCompany().getId())
                    .product(request.getProduct().getId())
                    .task(request.getTask().getId())
                    .clasification(request.getClasification().getId())
                    .user(request.getUser().getId())
                    .approvalDate(request.getApprovalDate())
                    .cityOfOrigin(request.getCityOfOrigin().getId())
                    .destinationCity(request.getDestinationCity().getId())
                    .purchaseOrderStatus(request.getPurchaseOrderStatus().getId())
                    .requestedHours(request.getRequestedHours())
                    .executedhours(request.getExecutedhours())
                    .availablehours(request.getAvailablehours())
                    .arl(request.getArl().getId())
                    .requiresReport(request.isRequiresReport())
                    .requiresTransportation(request.isRequiresTransportation())
                    .observation(request.getObservation())
                    .customPurchaseOrderRate(request != null ? Boolean.TRUE.equals(request.isCustomPurchaseOrderRate()) : false)
                    .customPurchaseOrderRateValue(request.getCustomPurchaseOrderRateValue() != null ? request.getCustomPurchaseOrderRateValue() : Double.valueOf("0"))
                    .creationDate(request.getCreationDate())
                    .lastUpdatedDate(request.getLastUpdatedDate())
                    .createdBy(request.getCreatedBy())
                    .lastUpdatedBy(request.getLastUpdatedBy())
                    .deleted(request.getDeleted())
                    .build();
            create(purchaseOrder);
            createMasterDataMap();
            PurchaseOrderDto poDto = PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(purchaseOrder,
                    companyMap, productMap, taskMap, clasificationMap, userMap, cityMap, purchaseOrderStatusMap, arlMap);
            if (!op.equals("RECALCULATEHOURS")) {
                sendNotificationEmail(poDto, "N");
            }
            String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(request.getLastUpdatedBy()), userRepository.findByUsername(request.getLastUpdatedBy()).get());
            return GenericResponse.builder()
                    .token(token)
                    .data(poDto)
                    .build();
        }
    }

    @Transactional
    public GenericResponse saveAllPurchaseOrders(List<PurchaseOrderDto> purchaseOrders, User authenticatedUser) {
        System.out.println("Inicia carga masiva de OC a bd (api)" + LocalDateTime.now().toString());
        List<PurchaseOrder> lpurchaseOrders = new ArrayList<>();
        for (PurchaseOrderDto cdto : purchaseOrders) {
            lpurchaseOrders.add(PurchaseOrderDto.PurchaseOrderDtoToPurchaseOrder(cdto));
        }

        // Crear un mapa para búsqueda rápida de OC existentes por numero de orden
        Map<String, PurchaseOrder> existingPurchaseOrdersMap = new HashMap<>();
        for (PurchaseOrder currentExist : getAll()) {
            existingPurchaseOrdersMap.put(currentExist.getPurchaseOrderNumber(), currentExist);
        }

        // Actualizar IDs en lpurchaseOrders
        for (PurchaseOrder current : lpurchaseOrders) {
            PurchaseOrder existingPurchaseOrder = existingPurchaseOrdersMap.get(current.getPurchaseOrderNumber());
            if (existingPurchaseOrder != null) {
                current.setId(existingPurchaseOrder.getId());
                current.setCreatedBy(existingPurchaseOrder.getCreatedBy());
                current.setCreationDate(existingPurchaseOrder.getCreationDate());
            } else {
                current.setCreatedBy(current.getLastUpdatedBy());
                current.setCreationDate(current.getLastUpdatedDate());
            }
        }

        int batchCount = 0;
        System.out.println("Inicia carga masiva de OC a bd proceso batch" + LocalDateTime.now().toString());
        for (int i = 0; i < lpurchaseOrders.size(); i++) {
            try {
                // Intentar hacer el merge de la OC
                entityManager.merge(lpurchaseOrders.get(i));
                batchCount++;

                // Si llega al límite del batch, hacer flush y clear
                if (batchCount % BATCH_SIZE == 0) {
                    System.out.println("Carga datos OC número: " + lpurchaseOrders.get(i).getPurchaseOrderNumber());
                    entityManager.flush();
                    entityManager.clear();
                    batchCount = 0;
                }
            } catch (org.hibernate.PropertyValueException e) {
                // Capturar la excepción específica de Hibernate y registrar el número de la OC que falló
                System.err.println("Error al guardar la OC número: " + lpurchaseOrders.get(i).getPurchaseOrderNumber());
                e.printStackTrace();
                // Lanzar una nueva excepción con el mensaje detallado
                throw new RuntimeException("Error al guardar la OC con número: " + lpurchaseOrders.get(i).getPurchaseOrderNumber() + " debido a un valor nulo en propiedad obligatoria.", e);
            } catch (Exception e) {
                // Capturar otras excepciones y registrar el número de la OC que falló
                System.err.println("Error al guardar la OC número: " + lpurchaseOrders.get(i).getPurchaseOrderNumber());
                e.printStackTrace();
                throw new RuntimeException("Error inesperado al guardar la OC con número: " + lpurchaseOrders.get(i).getPurchaseOrderNumber(), e);
            }
        }

        // Si hay elementos restantes en el batch, hacer flush y clear
        if (batchCount > 0) {
            entityManager.flush();
            entityManager.clear();
        }

        System.out.println("Termina carga masiva de OC a bd (api)" + LocalDateTime.now().toString());

        if (!purchaseOrders.get(0).getArl().getDescription().toLowerCase().contains("sura")) {
            System.out.println("Inicia envío de correo de notificación de nueva OC creada a usuario:" + LocalDateTime.now().toString());
            for (PurchaseOrderDto currentNew : purchaseOrders) {
                sendNotificationEmail(currentNew, "N");
            }
        }

        System.out.println("Termina carga masiva de OC a bd (api)" + LocalDateTime.now().toString());

        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);

        return GenericResponse.builder()
                .token(token)
                .data(purchaseOrders)
                .build();
    }

    @Override
    public PurchaseOrder loadPurchaseOrderByPurchaseOrderNumber(String purchaseOrderNumber) {
        System.out.println("Inicia carga masiva de OC(Service)" + LocalDateTime.now().toString());
        return purchaseOrderRepository.findByPurchaseOrderNumber(purchaseOrderNumber)
                .orElseThrow(() -> new RuntimeException("PurchaseOrder not found: " + purchaseOrderNumber));
    }

    @Override
    public Optional<PurchaseOrder> findByPurchaseOrderNumber(String purchaseOrderNumber) {
        return purchaseOrderRepository.findByPurchaseOrderNumber(purchaseOrderNumber);
    }

    public List<PurchaseOrder> getAllActive() {
        return purchaseOrderRepository.findAllByDeletedFalse();
    }

    private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Company> lcompanies = companyService.getAllActive();
        List<CompanyDto> lcompaniesDto = new ArrayList<>();
        for (Company c : lcompanies) {
            lcompaniesDto.add(CompanyDto.CompanyToCompanyDto(c));
        }
        companyMap = lcompaniesDto.stream()
                .collect(Collectors.toMap(CompanyDto::getId, Function.identity()));

        List<Product> lproducts = productService.getAllActive();
        List<ProductDto> lproductsDto = new ArrayList<>();
        for (Product p : lproducts) {
            lproductsDto.add(ProductDto.ProductToProductDto(p));
        }
        productMap = lproductsDto.stream()
                .collect(Collectors.toMap(ProductDto::getId, Function.identity()));

        List<Task> ltasks = taskService.getAllActive();
        List<TaskDto> ltasksDto = new ArrayList<>();
        for (Task t : ltasks) {
            ltasksDto.add(TaskDto.TaskToTaskDto(t));
        }
        taskMap = ltasksDto.stream()
                .collect(Collectors.toMap(TaskDto::getId, Function.identity()));

        List<Clasification> lclasification = clasificationService.getAllActive();
        List<ClasificationDto> lclasificationDto = new ArrayList<>();
        for (Clasification c : lclasification) {
            lclasificationDto.add(ClasificationDto.ClasificationToClasificationDto(c));
        }
        clasificationMap = lclasificationDto.stream()
                .collect(Collectors.toMap(ClasificationDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

        List<City> lcities = cityService.getAllActive();
        List<CityDto> lcitiesDto = new ArrayList<>();
        for (City c : lcities) {
            lcitiesDto.add(CityDto.CityToCityDto(c));
        }
        cityMap = lcitiesDto.stream()
                .collect(Collectors.toMap(CityDto::getId, Function.identity()));

        List<PurchaseOrderStatus> lpurchaseOrderStatus = purchaseOrderStatusService.getAllActive();
        List<PurchaseOrderStatusDto> lpurchaseOrderStatusDto = new ArrayList<>();
        for (PurchaseOrderStatus p : lpurchaseOrderStatus) {
            lpurchaseOrderStatusDto.add(PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(p));
        }
        purchaseOrderStatusMap = lpurchaseOrderStatusDto.stream()
                .collect(Collectors.toMap(PurchaseOrderStatusDto::getId, Function.identity()));

        List<ARL> larl = arlService.getAllActive();
        List<ARLDto> larlDto = new ArrayList<>();
        for (ARL a : larl) {
            larlDto.add(ARLDto.ARLToARLDto(a));
        }
        arlMap = larlDto.stream()
                .collect(Collectors.toMap(ARLDto::getId, Function.identity()));

    }

    public List<PurchaseOrder> getAllActivePurchaseOrderByArl(String arl) {
        return purchaseOrderRepository.findAllByDeletedFalseAndArl(arlService.findByDescription(arl).getId());
    }

    private void sendNotificationEmail(PurchaseOrderDto c, String u) {
        if (u.equals("N") && !c.getArl().getDescription().toLowerCase().contains("sura")) {
            String messageTitle = "Nueva OC Asignada:" + c.getPurchaseOrderNumber() + " Empresa: " + c.getCompany().getCompanyname();
            String message = "Se ha generado una OC a su nombre, por favor gestione los cumplimmientos."
                    + "\nEmpresa: " + c.getCompany().getCompanyname()
                    + "\nProducto: " + c.getProduct().getDescription()
                    + "\nTarea: " + c.getTask().getDescription()
                    + "\nClasificacion: " + c.getClasification().getDescription()
                    + "\nCiudad Origen: " + c.getCityOfOrigin().getCity()
                    + "\nCiudad Destino: " + c.getDestinationCity().getCity()
                    + "\nCantidad Pedida: " + c.getRequestedHours()
                    + "\nRequiere Informe: " + (c.isRequiresReport() ? "SI" : "NO")
                    + "\nRequiere Transporte: " + (c.isRequiresTransportation() ? "SI" : "NO")
                    + "\nObservaciones: " + (c.getObservation() != null ? c.getObservation() : "Ninguna");
            emailService.sendSimpleMessage(c.getUser().getEmail(), messageTitle, message);

        }
//        if (u.equals("U")) {
//            String messageTitle = "Se ha modificado una OC asignada:" + c.getPurchaseOrderNumber();
//            String message = "Se ha modificado una OC, por favor revise y gestione los cumplimmientos."
//                    + "\nEmpresa: " + c.getCompany().getCompanyname()
//                    + "\nProducto: " + c.getProduct().getDescription()
//                    + "\nTarea: " + c.getTask().getDescription()
//                    + "\nClasificacion: " + c.getClasification().getDescription()
//                    + "\nCiudad Origen: " + c.getCityOfOrigin().getCity()
//                    + "\nCiudad Destino: " + c.getDestinationCity().getCity()
//                    + "\nCantidad Pedida: " + c.getRequestedHours()
//                    + "\nRequiere Informe: " + (c.isRequiresReport() ? "SI" : "NO")
//                    + "\nRequiere Transporte: " + (c.isRequiresTransportation() ? "SI" : "NO")
//                    + "\nObservaciones: " + (c.getObservation() != null ? c.getObservation() : "Ninguna");
//            emailService.sendSimpleMessage(c.getUser().getEmail(), messageTitle, message);
//
//        }

    }

}

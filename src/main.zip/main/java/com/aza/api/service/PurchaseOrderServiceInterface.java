/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.PurchaseOrderDto;
import com.aza.api.model.PurchaseOrder;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface PurchaseOrderServiceInterface {

    GenericResponse add(PurchaseOrderDto request, String op);

    PurchaseOrder create(PurchaseOrder purchaseOrder);

    void delete(PurchaseOrder purchaseOrder);

    void deleteAll();

    Optional<PurchaseOrder> findById(Long id);

    Optional<PurchaseOrder> findByPurchaseOrderNumber(String purchaseOrderNumber);

    List<PurchaseOrder> getAll();

    PurchaseOrder loadPurchaseOrderByPurchaseOrderNumber(String purchaseOrderNumber);

}

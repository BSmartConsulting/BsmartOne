/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.FrontEndMessage;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface FrontEndMessageServiceInterface {

    FrontEndMessage create(FrontEndMessage frontEndMessage);

    void delete(FrontEndMessage frontEndMessage);

    void deleteAll();

    FrontEndMessage findById(long id);

    List<FrontEndMessage> getAll();

}

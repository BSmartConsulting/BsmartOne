/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Task;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface TaskServiceInterface {

    Task create(Task task);

    void delete(Task task);

    void deleteAll();

    Task findById(Long id);

    List<Task> getAll();

}

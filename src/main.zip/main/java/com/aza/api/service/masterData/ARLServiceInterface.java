/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ARL;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ARLServiceInterface {

    ARL create(ARL arl);

    void delete(ARL arl);

    void deleteAll();

    ARL findById(Long id);

    List<ARL> getAll();

    List<ARL> getAllActive();
}

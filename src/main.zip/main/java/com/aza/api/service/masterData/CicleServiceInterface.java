/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Cicle;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface CicleServiceInterface {

    Cicle create(Cicle cicle);

    void delete(Cicle cicle);

    void deleteAll();

    Cicle findById(Long id);

    List<Cicle> getAll();

    List<Cicle> getAllActive();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Product;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface ProductServiceInterface {

    Product create(Product product);

    void delete(Product product);

    void deleteAll();

    Product findById(Long id);

    List<Product> getAll();

}

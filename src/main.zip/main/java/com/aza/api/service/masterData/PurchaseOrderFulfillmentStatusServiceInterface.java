/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.PurchaseOrderFulfillmentStatus;
import java.util.List;

/**
 *
 * @author jaime
 */
public interface PurchaseOrderFulfillmentStatusServiceInterface {

    PurchaseOrderFulfillmentStatus create(PurchaseOrderFulfillmentStatus purchaseOrderFulfillmentStatus);

    void delete(PurchaseOrderFulfillmentStatus purchaseOrderFulfillmentStatus);

    void deleteAll();

    PurchaseOrderFulfillmentStatus findById(Long id);

    List<PurchaseOrderFulfillmentStatus> getAll();

}

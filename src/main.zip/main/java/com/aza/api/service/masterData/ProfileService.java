/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.Profile;
import com.aza.api.repository.masterData.ProfileRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ProfileService implements ProfileServiceInterface {

    @Autowired
    private ProfileRepository profileRepository;

    @Override
    public Profile create(Profile profile) {
        return profileRepository.save(profile);
        //return ProfileRepository.save(new Profile(profile.getId(),profile.getCodigo(),profile.getDescripcion()));
    }

    @Override
    public List<Profile> getAll() {
        return profileRepository.findAll();
    }

    @Override
    public void delete(Profile profile) {
        profileRepository.delete(profile);
    }

    @Override
    public void deleteAll() {
        profileRepository.deleteAll();
    }

    @Override
    public Profile findById(Long id) {
        return profileRepository.findById(id).get();
    }

    public List<Profile> getAllActive() {
        return profileRepository.findAllByDeletedFalse();
    }

}

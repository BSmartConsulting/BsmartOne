/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.UserType;
import com.aza.api.repository.masterData.UserTypeRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jaime
 */
@Service
public class UserTypeService implements UserTypeServiceInterface {

    @Autowired
    private UserTypeRepository userTypesRepository;

    @Override
    public UserType create(UserType userType) {
        return userTypesRepository.save(userType);
    }

    @Override
    public List<UserType> getAll() {
        return userTypesRepository.findAll();
    }

    @Override
    public void delete(UserType userType) {
        userTypesRepository.delete(userType);
    }

    @Override
    public void deleteAll() {
        userTypesRepository.deleteAll();
    }

    @Override
    public Optional<UserType> findById(Long id) {
        return userTypesRepository.findById(id);
    }

    public List<UserType> getAllActive() {
        return userTypesRepository.findAllByDeletedFalse();
    }
}

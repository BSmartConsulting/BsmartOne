/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.service;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.PurchaseOrderFulfillmentDto;
import com.aza.api.model.PurchaseOrderFulfillment;
import com.aza.api.model.masterData.User;
import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author jaime
 */
public interface PurchaseOrderFulfillmentServiceInterface {

    GenericResponse add(PurchaseOrderFulfillmentDto request);

    //@Override
    PurchaseOrderFulfillment create(PurchaseOrderFulfillment purchaseOrderFulfillment);

    void delete(PurchaseOrderFulfillment purchaseOrderFulfillment);

    void deleteAll();

    Optional<PurchaseOrderFulfillment> findById(Long id);

    List<PurchaseOrderFulfillment> getAll();

    //PurchaseOrderFulfillment loadPurchaseOrderFulfillmentByPurchaseOrderFulfillmentNumber(String purchaseOrderFulfillmentNumber);
    @Transactional
    GenericResponse saveAllPurchaseOrderFulfillments(List<PurchaseOrderFulfillmentDto> purchaseOrderFulfillments, User authenticatedUser);

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.service.masterData;

import com.aza.api.model.masterData.ServiceType;
import com.aza.api.repository.masterData.ServiceTypeRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author jaime
 */
@Service
public class ServiceTypeService implements ServiceTypeServiceInterface {

    @Autowired
    private ServiceTypeRepository serviceTypeRepository;

    @Override
    public ServiceType create(ServiceType serviceType) {
        return serviceTypeRepository.save(serviceType);
        //return ServiceTypeRepository.save(new ServiceType(serviceType.getId(),serviceType.getCodigo(),serviceType.getDescripcion()));
    }

    @Override
    public List<ServiceType> getAll() {
        return serviceTypeRepository.findAll();
    }

    @Override
    public void delete(ServiceType serviceType) {
        serviceTypeRepository.delete(serviceType);
    }

    @Override
    public void deleteAll() {
        serviceTypeRepository.deleteAll();
    }

    @Override
    public ServiceType findById(Long id) {
        return serviceTypeRepository.findById(id).get();
    }

    public List<ServiceType> getAllActive() {
        return serviceTypeRepository.findAllByDeletedFalse();
    }

}

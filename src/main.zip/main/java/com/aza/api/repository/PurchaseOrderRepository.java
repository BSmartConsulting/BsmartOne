/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.repository;

import com.aza.api.model.PurchaseOrder;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {

    Optional<PurchaseOrder> findByPurchaseOrderNumber(String purchaseOrderNumber);

    public List<PurchaseOrder> findAllByDeletedFalse();

    public List<PurchaseOrder> findAllByDeletedFalseAndArl(Long arl);

    @Procedure(procedureName = "updatepurchaseorderhours")
    void updatePurchaseOrderHours();

    @Procedure(procedureName = "updatepurchaseorderhours_by_id")
    void updatepurchaseorderhoursByid(@Param("purchaseorderid") Long id);   

}

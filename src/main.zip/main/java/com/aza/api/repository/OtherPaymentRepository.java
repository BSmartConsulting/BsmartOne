/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.repository;

import com.aza.api.model.OtherPayment;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OtherPaymentRepository extends JpaRepository<OtherPayment, Long> {

    public List<OtherPayment> findAllByDeletedFalse();

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.repository.masterData;

import com.aza.api.model.masterData.ARL;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ARLRepository extends JpaRepository<ARL, Long> {

    public List<ARL> findAllByDeletedFalse();

    public ARL findByDescription(String arl);

}

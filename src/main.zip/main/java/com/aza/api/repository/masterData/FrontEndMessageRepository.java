/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/springframework/Repository.java to edit this template
 */
package com.aza.api.repository.masterData;

import com.aza.api.model.masterData.FrontEndMessage;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author jaime
 */
@Repository
public interface FrontEndMessageRepository extends JpaRepository<FrontEndMessage, Integer> {

    public FrontEndMessage findById(long id);

    public List<FrontEndMessage> findAllByDeletedFalse();

}

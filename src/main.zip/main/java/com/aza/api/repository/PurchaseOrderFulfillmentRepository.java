/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.repository;

import com.aza.api.model.PurchaseOrderFulfillment;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseOrderFulfillmentRepository extends JpaRepository<PurchaseOrderFulfillment, Long> {

    public List<PurchaseOrderFulfillment> findByPurchaseOrder(Long purchaseOrder);

    public List<PurchaseOrderFulfillment> findAllByDeletedFalse();

    public List<PurchaseOrderFulfillment> findAllBypurchaseOrderFulfillmentStatus(Long id);

}

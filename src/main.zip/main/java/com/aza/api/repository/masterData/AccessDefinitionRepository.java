/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.repository.masterData;

import com.aza.api.model.masterData.AccessDefinition;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccessDefinitionRepository extends JpaRepository<AccessDefinition, Long> {

    public List<AccessDefinition> findAllByDeletedFalse();

}

package com.aza.api.repository.masterData;

import com.aza.api.model.masterData.OtherPaymentType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OtherPaymentTypeRepository extends JpaRepository<OtherPaymentType, Long> {

    Optional<OtherPaymentType> findByCode(String code);

    public List<OtherPaymentType> findAllByDeletedFalse();

}

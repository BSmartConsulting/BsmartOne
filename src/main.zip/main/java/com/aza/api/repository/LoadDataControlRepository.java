/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.aza.api.repository;

import com.aza.api.model.LoadDataControl;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoadDataControlRepository extends JpaRepository<LoadDataControl, Long> {

}

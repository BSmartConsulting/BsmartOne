package com.aza.api.repository.masterData;

import com.aza.api.model.masterData.UserType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserTypeRepository extends JpaRepository<UserType, Long> {

    Optional<UserType> findByCode(String code);

    public List<UserType> findAllByDeletedFalse();

}

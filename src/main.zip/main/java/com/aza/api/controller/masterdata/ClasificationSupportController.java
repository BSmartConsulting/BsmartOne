/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ClasificationSupportDto;
import com.aza.api.model.masterData.ClasificationSupport;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ClasificationSupportService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ClasificationSupportController {

    @Autowired
    private ClasificationSupportService clasificationSupportService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/clasificationSupport")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de ClasificationSupport:" + LocalDateTime.now());
            // Obtén solo las ClasificationSupport activas (no eliminadas)
            List<ClasificationSupport> lClasificationSupport = clasificationSupportService.getAllActive();
            // Usa Streams para transformar las entidades ClasificationSupport en DTOs
            List<ClasificationSupportDto> lClasificationSupportDto = lClasificationSupport.stream()
                    .map(ClasificationSupportDto::ClasificationSupportToClasificationSupportDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de ClasificationSupport:" + LocalDateTime.now() + " con: " + lClasificationSupportDto.size() + " registros");
            return serviceResponse(lClasificationSupportDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/clasificationSupport/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de ClasificationSupport:" + LocalDateTime.now());
            // Obtén solo las ClasificationSupport activas (no eliminadas)
            List<ClasificationSupport> lClasificationSupport = clasificationSupportService.getAllActive();
            // Usa Streams para transformar las entidades ClasificationSupport en DTOs
            ClasificationSupportDto lClasificationSupportDto = ClasificationSupportDto.ClasificationSupportToClasificationSupportDto(lClasificationSupport.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de ClasificationSupport:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lClasificationSupportDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/clasificationSupport")
    public ResponseEntity<GenericResponse> post(@RequestBody ClasificationSupportDto clasificationSupportdto) {
        try {
            if (clasificationSupportdto.getId() == null) {
                List<ClasificationSupport> clasificationSupportList = clasificationSupportService.getAll();
                for (ClasificationSupport current : clasificationSupportList) {
                    if (current.getArl() == clasificationSupportdto.getArl().getId()
                            && current.getClasification() == clasificationSupportdto.getClasification().getId()) {
                        clasificationSupportdto.setId(current.getId());
                        clasificationSupportdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ClasificationSupportDto a ClasificationSupport y crear el registro
            ClasificationSupport tmp = ClasificationSupportDto.ClasificationSupportDtoToClasificationSupport(clasificationSupportdto);
            ClasificationSupportDto result = ClasificationSupportDto.ClasificationSupportToClasificationSupportDto(clasificationSupportService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/clasificationSupport/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            ClasificationSupport current = clasificationSupportService.findById(id);
            current.setDeleted(false);
            ClasificationSupportDto result = ClasificationSupportDto.ClasificationSupportToClasificationSupportDto(clasificationSupportService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/clasificationSupport")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<ClasificationSupport> allClasificationSupport = clasificationSupportService.getAll();
            for (ClasificationSupport current : allClasificationSupport) {
                current.setDeleted(false);
                clasificationSupportService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.PurchaseOrderDto;
import com.aza.api.dto.PurchaseOrderFulfillmentDto;
import com.aza.api.dto.masterData.ARLDto;
import com.aza.api.dto.masterData.CicleDto;
import com.aza.api.dto.masterData.CityDto;
import com.aza.api.dto.masterData.ClasificationDto;
import com.aza.api.dto.masterData.CompanyDto;
import com.aza.api.dto.masterData.DiscountReasonDto;
import com.aza.api.dto.masterData.ProductDto;
import com.aza.api.dto.masterData.PurchaseOrderFulfillmentStatusDto;
import com.aza.api.dto.masterData.PurchaseOrderRejectionReasonDto;
import com.aza.api.dto.masterData.PurchaseOrderStatusDto;
import com.aza.api.dto.masterData.ServiceTypeDto;
import com.aza.api.dto.masterData.TaskDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.PurchaseOrder;
import com.aza.api.model.PurchaseOrderFulfillment;
import com.aza.api.model.PurchaseOrderFulfillmentSupportFile;
import com.aza.api.model.masterData.ARL;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.City;
import com.aza.api.model.masterData.Clasification;
import com.aza.api.model.masterData.Company;
import com.aza.api.model.masterData.DiscountReason;
import com.aza.api.model.masterData.Product;
import com.aza.api.model.masterData.PurchaseOrderFulfillmentStatus;
import com.aza.api.model.masterData.PurchaseOrderRejectionReason;
import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.model.masterData.ServiceType;
import com.aza.api.model.masterData.Task;
import com.aza.api.model.masterData.User;
import com.aza.api.service.EmailService;
import com.aza.api.service.JwtService;
import com.aza.api.service.PurchaseOrderFulfillmentService;
import com.aza.api.service.PurchaseOrderFulfillmentSupportFileService;
import com.aza.api.service.PurchaseOrderService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.CityService;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.DiscountReasonService;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.PurchaseOrderFulfillmentStatusService;
import com.aza.api.service.masterData.PurchaseOrderRejectionReasonService;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.ServiceTypeService;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author jaime
 */
@RestController
@RequestMapping("/api/v1")
public class PurchaseOrderFulfillmentController {

    @Autowired
    private PurchaseOrderFulfillmentService purchaseOrderFulfillmentService;

    @Autowired
    private PurchaseOrderFulfillmentSupportFileService purchaseOrderFulfillmentSupportFileService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @Autowired
    private UserService userService;
    @Autowired
    private PurchaseOrderService purchaseOrderService;
    @Autowired
    private PurchaseOrderFulfillmentStatusService purchaseOrderFulfillmentStatusService;
    @Autowired
    private ServiceTypeService serviceTypeService;
    @Autowired
    private PurchaseOrderRejectionReasonService purchaseOrderRejectionReasonService;
    @Autowired
    private CityService cityService;
    @Autowired
    private DiscountReasonService discountReasonService;
    @Autowired
    private CompanyService companyService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ClasificationService clasificationService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private PurchaseOrderStatusService purchaseOrderStatusService;
    @Autowired
    private ARLService arlService;
    @Autowired
    private CicleService cicleService;

    @Autowired
    private EmailService emailService;

    private Map<Long, CompanyDto> companyMap;
    private Map<Long, ProductDto> productMap;
    private Map<Long, TaskDto> taskMap;
    private Map<Long, ClasificationDto> clasificationMap;
    private Map<Long, UserDto> userMap;
    private Map<Long, CityDto> cityMap;
    private Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap;
    private Map<Long, ARLDto> arlMap;
    private Map<Long, PurchaseOrderDto> purchaseOrderMap;
    private Map<Long, PurchaseOrderFulfillmentStatusDto> purchaseOrderFulfillmentStatusMap;
    private Map<Long, ServiceTypeDto> serviceTypeMap;
    private Map<Long, PurchaseOrderRejectionReasonDto> purchaseOrderRejectionReasonMap;
    private Map<Long, DiscountReasonDto> discountReasonMap;
    private Map<Long, CicleDto> cicleMap;

    @GetMapping("/transactional/purchaseOrderFulfillment")
    public GenericResponse list() {
        System.out.println("Inicia carga de OC:" + LocalDateTime.now());
        // Obtén solo las PurchaseOrderFulfillment activas (no eliminadas)
        List<PurchaseOrderFulfillment> lPurchaseOrderFulfillment = purchaseOrderFulfillmentService.getAllActive();
        // Usa Streams para transformar las entidades PurchaseOrderFulfillment en DTOs
        createMasterDataMap();
        List<PurchaseOrderFulfillmentDto> lPurchaseOrderFulfillmentDto = lPurchaseOrderFulfillment.stream()
                .map(purchaseOrderFulfillment -> PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(
                purchaseOrderFulfillment,
                companyMap,
                productMap,
                taskMap,
                clasificationMap,
                userMap,
                cityMap,
                purchaseOrderStatusMap,
                arlMap,
                purchaseOrderMap,
                purchaseOrderFulfillmentStatusMap,
                serviceTypeMap,
                purchaseOrderRejectionReasonMap,
                discountReasonMap,
                cicleMap
        ))
                .collect(Collectors.toList());

        System.out.println("Finaliza carga de OC:" + LocalDateTime.now() + " con: " + lPurchaseOrderFulfillmentDto.size() + " registros");
        return serviceResponse(lPurchaseOrderFulfillmentDto, "OK");
    }

    @GetMapping("/transactional/purchaseOrderFulfillment/{id}")
    public ResponseEntity<PurchaseOrderFulfillmentDto> get(@PathVariable long id) {
        System.out.println("Inicia carga de Cumplimientos:" + LocalDateTime.now());
        // Obtén solo las PurchaseOrder activas (no eliminadas)
        List<PurchaseOrderFulfillment> lPurchaseOrderFulfillment = purchaseOrderFulfillmentService.getAllActive();
        // Usa Streams para transformar las entidades PurchaseOrder en DTOs
        PurchaseOrderFulfillmentDto lPurchaseOrderFulfillmentDto = PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(lPurchaseOrderFulfillment.stream()
                .filter(current -> current.getId() == id)
                .findFirst()
                .orElse(null),
                companyMap,
                productMap,
                taskMap,
                clasificationMap,
                userMap,
                cityMap,
                purchaseOrderStatusMap,
                arlMap,
                purchaseOrderMap,
                purchaseOrderFulfillmentStatusMap,
                serviceTypeMap,
                purchaseOrderRejectionReasonMap,
                discountReasonMap,
                cicleMap
        );
        System.out.println("Finaliza busqueda  de Cumplimientos:" + LocalDateTime.now() + " con: id: " + id);
        return ResponseEntity.ok(lPurchaseOrderFulfillmentDto);
    }

    @GetMapping("transactional/purchaseOrderFulfillment/getApprovedFulfillment/{approvedStatus}")
    public GenericResponse<List<PurchaseOrderFulfillmentDto>> getApprovedFulfillment(@PathVariable String approvedStatus) {
        System.out.println("Inicia carga de Cumplimientos:" + LocalDateTime.now());
        // Obtén solo las PurchaseOrder activas (no eliminadas)
        //List<PurchaseOrderFulfillment> lPurchaseOrderFulfillment = purchaseOrderFulfillmentService.getApprovedFulfillment(approvedStatus);
        // Usa Streams para transformar las entidades PurchaseOrder en DTOs
        
        List<PurchaseOrderFulfillment> lPurchaseOrderFulfillment = purchaseOrderFulfillmentService.getApprovedFulfillment(approvedStatus).stream()
        .filter(pof -> !pof.getDeleted()) // Filtra solo los registros donde deleted es falso
        .collect(Collectors.toList());
        createMasterDataMap();
        List<PurchaseOrderFulfillmentDto> lPurchaseOrderFulfillmentDto = lPurchaseOrderFulfillment.stream()
                .map(purchaseOrderFulfillment -> PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(
                purchaseOrderFulfillment,
                companyMap,
                productMap,
                taskMap,
                clasificationMap,
                userMap,
                cityMap,
                purchaseOrderStatusMap,
                arlMap,
                purchaseOrderMap,
                purchaseOrderFulfillmentStatusMap,
                serviceTypeMap,
                purchaseOrderRejectionReasonMap,
                discountReasonMap,
                cicleMap
        ))
                .collect(Collectors.toList());

        System.out.println("Finaliza carga de OC:" + LocalDateTime.now() + " con: " + lPurchaseOrderFulfillmentDto.size() + " registros");
        return serviceResponse(lPurchaseOrderFulfillmentDto, "OK");
    }

    @PostMapping("/transactional/purchaseOrderFulfillment")
    public ResponseEntity<GenericResponse> post(@RequestBody PurchaseOrderFulfillmentDto purchaseOrderFulfillmentdto) {
        try {
            if (purchaseOrderFulfillmentdto.getId() == null) {
                List<PurchaseOrderFulfillment> purchaseOrderFulfillmentList = purchaseOrderFulfillmentService.getAll();
                for (PurchaseOrderFulfillment current : purchaseOrderFulfillmentList) {
                    if (current.getPurchaseOrder() == purchaseOrderFulfillmentdto.getPurchaseOrder().getId()
                            && current.getAppointmentDate() == purchaseOrderFulfillmentdto.getAppointmentDate()) {
                        purchaseOrderFulfillmentdto.setId(current.getId());
                        break;
                    }
                }
            }

            PurchaseOrderFulfillmentDto result = (PurchaseOrderFulfillmentDto) purchaseOrderFulfillmentService.add(purchaseOrderFulfillmentdto).getData();

            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/transactional/purchaseOrderFulfillment/sendRejectionEmail")
    public ResponseEntity<GenericResponse> postSendeRejectionEmail(@RequestBody PurchaseOrderFulfillmentDto purchaseOrderFulfillmentdto) {
        try {
            String message = "";
            String messageTitle = "";
            messageTitle = "Cumplimiento rechazado empresa " + purchaseOrderFulfillmentdto.getPurchaseOrder().getCompany().getCompanyname()+ " OC "+ purchaseOrderFulfillmentdto.getPurchaseOrder().getPurchaseOrderNumber();
            message = "Se ha generado un rechazo para un cumplimiento asociado a la OC: " + purchaseOrderFulfillmentdto.getPurchaseOrder().getPurchaseOrderNumber()
                    + "\nPor favor revise la bandeja de cumplimientos rechazados en la aplicación, solucione los inconvenientes y vuelva a enviar al analista para aprobación";
            emailService.sendSimpleMessage(purchaseOrderFulfillmentdto.getUser().getEmail(), messageTitle, message);
            return new ResponseEntity<>(serviceResponse(purchaseOrderFulfillmentdto, "OK"), HttpStatus.CREATED);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/transactional/purchaseOrderFulfillmentSupportFile/{id}")
    public GenericResponse getPurchaseOrderFulfillmentSupportFile(@PathVariable long id
    ) {
        try {
            System.out.println("Inicia carga de ARL:" + LocalDateTime.now());
            // Obtén solo las ARL activas (no eliminadas)
            List<PurchaseOrderFulfillmentSupportFile> lpurchaseOrderFulfillmentSupportFilesTmp = purchaseOrderFulfillmentSupportFileService.findByPurchaseOrderFulfillment(id);
            // Usa Streams para transformar las entidades ARL en DTOs
            List<PurchaseOrderFulfillmentSupportFile> lpurchaseOrderFulfillmentSupportFiles = new ArrayList<>();
            for (PurchaseOrderFulfillmentSupportFile current : lpurchaseOrderFulfillmentSupportFilesTmp) {
                if (!current.getDeleted()) {
                    lpurchaseOrderFulfillmentSupportFiles.add(current);
                }
            }
            System.out.println("Finaliza busqueda  de Archivos de soporte :" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lpurchaseOrderFulfillmentSupportFiles, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/transactional/purchaseOrderFulfillmentSupportFile")
    public ResponseEntity<GenericResponse> postSaveSupportFile(@RequestBody PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFile
    ) {
        try {
            List<PurchaseOrderFulfillmentSupportFile> fileList = purchaseOrderFulfillmentSupportFileService.findByPurchaseOrderFulfillment(purchaseOrderFulfillmentSupportFile.getPurchaseOrderFulfillment());
            PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFileUpdate = purchaseOrderFulfillmentSupportFile;
            for (PurchaseOrderFulfillmentSupportFile current : fileList) {
                if (current.getType().equalsIgnoreCase(purchaseOrderFulfillmentSupportFileUpdate.getType())) {
                    purchaseOrderFulfillmentSupportFileUpdate.setId(current.getId());
                    break;
                }
            }

            PurchaseOrderFulfillmentSupportFile result = purchaseOrderFulfillmentSupportFileService.create(purchaseOrderFulfillmentSupportFileUpdate);

            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/transactional/purchaseOrderFulfillment/{id}")
    public ResponseEntity<HttpStatus> delete(@PathVariable long id
    ) {
        try {
            //buscar en la lista
            PurchaseOrderFulfillment current = purchaseOrderFulfillmentService.findById(id).get();
            current.setDeleted(false);
            PurchaseOrderFulfillmentDto result = PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(purchaseOrderFulfillmentService.create(current), companyMap,
                    productMap,
                    taskMap,
                    clasificationMap,
                    userMap,
                    cityMap,
                    purchaseOrderStatusMap,
                    arlMap,
                    purchaseOrderMap,
                    purchaseOrderFulfillmentStatusMap,
                    serviceTypeMap,
                    purchaseOrderRejectionReasonMap,
                    discountReasonMap,
                    cicleMap
            );

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(null, HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/transactional/purchaseOrderFulfillment")
    public ResponseEntity<HttpStatus> deleteAll() {
        try {
            for (PurchaseOrderFulfillment current : purchaseOrderFulfillmentService.getAllActive()) {
                current.setDeleted(true);
                purchaseOrderFulfillmentService.add(PurchaseOrderFulfillmentDto.PurchaseOrderFulfillmentToPurchaseOrderFulfillmentDto(current, companyMap,
                        productMap,
                        taskMap,
                        clasificationMap,
                        userMap,
                        cityMap,
                        purchaseOrderStatusMap,
                        arlMap,
                        purchaseOrderMap,
                        purchaseOrderFulfillmentStatusMap,
                        serviceTypeMap,
                        purchaseOrderRejectionReasonMap,
                        discountReasonMap,
                        cicleMap
                ));
            }
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @DeleteMapping("transactional/deletePurchaseOrderFulfillmentSupportFile")
    public ResponseEntity<HttpStatus> deleteSupportFile(@RequestBody PurchaseOrderFulfillmentSupportFile purchaseOrderFulfillmentSupportFile) {
        try {
            //buscar en la lista
            List<PurchaseOrderFulfillmentSupportFile> currentList = purchaseOrderFulfillmentSupportFileService.findByPurchaseOrderFulfillment(purchaseOrderFulfillmentSupportFile.getPurchaseOrderFulfillment());
            for (PurchaseOrderFulfillmentSupportFile current : currentList) {
                if (purchaseOrderFulfillmentSupportFile.getType().equalsIgnoreCase(current.getType())) {
                    purchaseOrderFulfillmentSupportFileService.delete(current);
                    break;
                }
            }

            return new ResponseEntity<>(null, HttpStatus.CREATED);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/transactional/purchaseOrderFulfillment/load")
    public ResponseEntity<GenericResponse> post(@RequestBody List<PurchaseOrderFulfillmentDto> purchaseOrderFulfillments
    ) {
        System.out.println("Inicia carga masiva de oc" + LocalDateTime.now().toString());
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userrname = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(userrname);

        // Pasar el usuario autenticado al servicio
        return ResponseEntity.ok(purchaseOrderFulfillmentService.saveAllPurchaseOrderFulfillments(purchaseOrderFulfillments, authenticatedUser));
    }

    private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Company> lcompanies = companyService.getAllActive();
        List<CompanyDto> lcompaniesDto = new ArrayList<>();
        for (Company c : lcompanies) {
            lcompaniesDto.add(CompanyDto.CompanyToCompanyDto(c));
        }
        companyMap = lcompaniesDto.stream()
                .collect(Collectors.toMap(CompanyDto::getId, Function.identity()));

        List<Product> lproducts = productService.getAllActive();
        List<ProductDto> lproductsDto = new ArrayList<>();
        for (Product p : lproducts) {
            lproductsDto.add(ProductDto.ProductToProductDto(p));
        }
        productMap = lproductsDto.stream()
                .collect(Collectors.toMap(ProductDto::getId, Function.identity()));

        List<Task> ltasks = taskService.getAllActive();
        List<TaskDto> ltasksDto = new ArrayList<>();
        for (Task t : ltasks) {
            ltasksDto.add(TaskDto.TaskToTaskDto(t));
        }
        taskMap = ltasksDto.stream()
                .collect(Collectors.toMap(TaskDto::getId, Function.identity()));

        List<Clasification> lclasification = clasificationService.getAllActive();
        List<ClasificationDto> lclasificationDto = new ArrayList<>();
        for (Clasification c : lclasification) {
            lclasificationDto.add(ClasificationDto.ClasificationToClasificationDto(c));
        }
        clasificationMap = lclasificationDto.stream()
                .collect(Collectors.toMap(ClasificationDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

        List<City> lcities = cityService.getAllActive();
        List<CityDto> lcitiesDto = new ArrayList<>();
        for (City c : lcities) {
            lcitiesDto.add(CityDto.CityToCityDto(c));
        }
        cityMap = lcitiesDto.stream()
                .collect(Collectors.toMap(CityDto::getId, Function.identity()));

        List<PurchaseOrderStatus> lpurchaseOrderStatus = purchaseOrderStatusService.getAllActive();
        List<PurchaseOrderStatusDto> lpurchaseOrderStatusDto = new ArrayList<>();
        for (PurchaseOrderStatus p : lpurchaseOrderStatus) {
            lpurchaseOrderStatusDto.add(PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(p));
        }
        purchaseOrderStatusMap = lpurchaseOrderStatusDto.stream()
                .collect(Collectors.toMap(PurchaseOrderStatusDto::getId, Function.identity()));

        List<ARL> larl = arlService.getAllActive();
        List<ARLDto> larlDto = new ArrayList<>();
        for (ARL a : larl) {
            larlDto.add(ARLDto.ARLToARLDto(a));
        }
        arlMap = larlDto.stream()
                .collect(Collectors.toMap(ARLDto::getId, Function.identity()));

        List<PurchaseOrder> lPurchaseOrder = purchaseOrderService.getAllActive();
        List<PurchaseOrderDto> lPurchaseOrderDto = new ArrayList<>();
        for (PurchaseOrder a : lPurchaseOrder) {
            lPurchaseOrderDto.add(PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(a, companyMap, productMap, taskMap, clasificationMap, userMap, cityMap, purchaseOrderStatusMap, arlMap));
        }
        purchaseOrderMap = lPurchaseOrderDto.stream()
                .collect(Collectors.toMap(PurchaseOrderDto::getId, Function.identity()));

        List<PurchaseOrderFulfillmentStatus> lPurchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatusService.getAllActive();
        List<PurchaseOrderFulfillmentStatusDto> lPurchaseOrderFulfillmentStatusDto = new ArrayList<>();
        for (PurchaseOrderFulfillmentStatus a : lPurchaseOrderFulfillmentStatus) {
            lPurchaseOrderFulfillmentStatusDto.add(PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(a));
        }
        purchaseOrderFulfillmentStatusMap = lPurchaseOrderFulfillmentStatusDto.stream()
                .collect(Collectors.toMap(PurchaseOrderFulfillmentStatusDto::getId, Function.identity()));

        List<ServiceType> lServiceType = serviceTypeService.getAllActive();
        List<ServiceTypeDto> lServiceTypeDto = new ArrayList<>();
        for (ServiceType a : lServiceType) {
            lServiceTypeDto.add(ServiceTypeDto.ServiceTypeToServiceTypeDto(a));
        }
        serviceTypeMap = lServiceTypeDto.stream()
                .collect(Collectors.toMap(ServiceTypeDto::getId, Function.identity()));

        List<PurchaseOrderRejectionReason> lPurchaseOrderRejectionReason = purchaseOrderRejectionReasonService.getAllActive();
        List<PurchaseOrderRejectionReasonDto> lPurchaseOrderRejectionReasonDto = new ArrayList<>();
        for (PurchaseOrderRejectionReason a : lPurchaseOrderRejectionReason) {
            lPurchaseOrderRejectionReasonDto.add(PurchaseOrderRejectionReasonDto.PurchaseOrderRejectionReasonToPurchaseOrderRejectionReasonDto(a));
        }
        purchaseOrderRejectionReasonMap = lPurchaseOrderRejectionReasonDto.stream()
                .collect(Collectors.toMap(PurchaseOrderRejectionReasonDto::getId, Function.identity()));

        List<DiscountReason> lDiscountReason = discountReasonService.getAllActive();
        List<DiscountReasonDto> lDiscountReasonDto = new ArrayList<>();
        for (DiscountReason a : lDiscountReason) {
            lDiscountReasonDto.add(DiscountReasonDto.DiscountReasonToDiscountReasonDto(a));
        }
        discountReasonMap = lDiscountReasonDto.stream()
                .collect(Collectors.toMap(DiscountReasonDto::getId, Function.identity()));

        List<Cicle> lCicles = cicleService.getAllActive();
        List<CicleDto> lCiclesDto = new ArrayList<>();
        for (Cicle a : lCicles) {
            lCiclesDto.add(CicleDto.CicleToCicleDto(a));
        }
        cicleMap = lCiclesDto.stream()
                .collect(Collectors.toMap(CicleDto::getId, Function.identity()));

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.DiscountReasonDto;
import com.aza.api.model.masterData.DiscountReason;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.DiscountReasonService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class DiscountReasonController {

    @Autowired
    private DiscountReasonService discountReasonService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/discountReason")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de DiscountReason:" + LocalDateTime.now());
            // Obtén solo las DiscountReason activas (no eliminadas)
            List<DiscountReason> lDiscountReason = discountReasonService.getAllActive();
            // Usa Streams para transformar las entidades DiscountReason en DTOs
            List<DiscountReasonDto> lDiscountReasonDto = lDiscountReason.stream()
                    .map(DiscountReasonDto::DiscountReasonToDiscountReasonDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de DiscountReason:" + LocalDateTime.now() + " con: " + lDiscountReasonDto.size() + " registros");
            return serviceResponse(lDiscountReasonDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/discountReason/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de DiscountReason:" + LocalDateTime.now());
            // Obtén solo las DiscountReason activas (no eliminadas)
            List<DiscountReason> lDiscountReason = discountReasonService.getAllActive();
            // Usa Streams para transformar las entidades DiscountReason en DTOs
            DiscountReasonDto lDiscountReasonDto = DiscountReasonDto.DiscountReasonToDiscountReasonDto(lDiscountReason.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de DiscountReason:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lDiscountReasonDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/discountReason")
    public ResponseEntity<GenericResponse> post(@RequestBody DiscountReasonDto discountReasondto) {
        try {
            if (discountReasondto.getId() == null) {
                List<DiscountReason> discountReasonList = discountReasonService.getAll();
                for (DiscountReason current : discountReasonList) {
                    if (current.getCode().equalsIgnoreCase(discountReasondto.getCode())) {
                        discountReasondto.setId(current.getId());
                        discountReasondto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir DiscountReasonDto a DiscountReason y crear el registro
            DiscountReason tmp = DiscountReasonDto.DiscountReasonDtoToDiscountReason(discountReasondto);
            DiscountReasonDto result = DiscountReasonDto.DiscountReasonToDiscountReasonDto(discountReasonService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/discountReason/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            DiscountReason current = discountReasonService.findById(id);
            current.setDeleted(false);
            DiscountReasonDto result = DiscountReasonDto.DiscountReasonToDiscountReasonDto(discountReasonService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/discountReason")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<DiscountReason> allDiscountReason = discountReasonService.getAll();
            for (DiscountReason current : allDiscountReason) {
                current.setDeleted(false);
                discountReasonService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

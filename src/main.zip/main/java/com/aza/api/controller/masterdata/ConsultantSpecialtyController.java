/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ConsultantSpecialtyDto;
import com.aza.api.model.masterData.ConsultantSpecialty;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ConsultantSpecialtyService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ConsultantSpecialtyController {

    @Autowired
    private ConsultantSpecialtyService consultantSpecialtyService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/consultantSpecialty")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de ConsultantSpecialty:" + LocalDateTime.now());
            // Obtén solo las ConsultantSpecialty activas (no eliminadas)
            List<ConsultantSpecialty> lConsultantSpecialty = consultantSpecialtyService.getAllActive();
            // Usa Streams para transformar las entidades ConsultantSpecialty en DTOs
            List<ConsultantSpecialtyDto> lConsultantSpecialtyDto = lConsultantSpecialty.stream()
                    .map(ConsultantSpecialtyDto::ConsultantSpecialtyToConsultantSpecialtyDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de ConsultantSpecialty:" + LocalDateTime.now() + " con: " + lConsultantSpecialtyDto.size() + " registros");
            return serviceResponse(lConsultantSpecialtyDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/consultantSpecialty/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de ConsultantSpecialty:" + LocalDateTime.now());
            // Obtén solo las ConsultantSpecialty activas (no eliminadas)
            List<ConsultantSpecialty> lConsultantSpecialty = consultantSpecialtyService.getAllActive();
            // Usa Streams para transformar las entidades ConsultantSpecialty en DTOs
            ConsultantSpecialtyDto lConsultantSpecialtyDto = ConsultantSpecialtyDto.ConsultantSpecialtyToConsultantSpecialtyDto(lConsultantSpecialty.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de ConsultantSpecialty:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lConsultantSpecialtyDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/consultantSpecialty")
    public ResponseEntity<GenericResponse> post(@RequestBody ConsultantSpecialtyDto consultantSpecialtydto) {
        try {
            if (consultantSpecialtydto.getId() == null) {
                List<ConsultantSpecialty> consultantSpecialtyList = consultantSpecialtyService.getAll();
                for (ConsultantSpecialty current : consultantSpecialtyList) {
                    if (current.getCode().equalsIgnoreCase(consultantSpecialtydto.getCode())) {
                        consultantSpecialtydto.setId(current.getId());
                        consultantSpecialtydto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ConsultantSpecialtyDto a ConsultantSpecialty y crear el registro
            ConsultantSpecialty tmp = ConsultantSpecialtyDto.ConsultantSpecialtyDtoToConsultantSpecialty(consultantSpecialtydto);
            ConsultantSpecialtyDto result = ConsultantSpecialtyDto.ConsultantSpecialtyToConsultantSpecialtyDto(consultantSpecialtyService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/consultantSpecialty/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            ConsultantSpecialty current = consultantSpecialtyService.findById(id);
            current.setDeleted(false);
            ConsultantSpecialtyDto result = ConsultantSpecialtyDto.ConsultantSpecialtyToConsultantSpecialtyDto(consultantSpecialtyService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/consultantSpecialty")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<ConsultantSpecialty> allConsultantSpecialty = consultantSpecialtyService.getAll();
            for (ConsultantSpecialty current : allConsultantSpecialty) {
                current.setDeleted(false);
                consultantSpecialtyService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

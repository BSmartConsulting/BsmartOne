/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.CicleDto;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class CicleController {

    @Autowired
    private CicleService cicleService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/cicle")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de Cicle:" + LocalDateTime.now());
            // Obtén solo las Cicle activas (no eliminadas)
            List<Cicle> lCicle = cicleService.getAllActive();
            // Usa Streams para transformar las entidades Cicle en DTOs
            List<CicleDto> lCicleDto = lCicle.stream()
                    .map(CicleDto::CicleToCicleDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de Cicle:" + LocalDateTime.now() + " con: " + lCicleDto.size() + " registros");
            return serviceResponse(lCicleDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/cicle/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de Cicle:" + LocalDateTime.now());
            // Obtén solo las Cicle activas (no eliminadas)
            List<Cicle> lCicle = cicleService.getAllActive();
            // Usa Streams para transformar las entidades Cicle en DTOs
            CicleDto lCicleDto = CicleDto.CicleToCicleDto(lCicle.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de Cicle:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lCicleDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/cicle")
    public ResponseEntity<GenericResponse> post(@RequestBody CicleDto cicledto) {
        try {
            if (cicledto.getId() == null) {
                List<Cicle> cicleList = cicleService.getAll();
                for (Cicle current : cicleList) {
                    if (current.getName().equalsIgnoreCase(cicledto.getName())
                            && current.getCicletype() == cicledto.getCicletype().getId()
                            && current.getStartdate() == cicledto.getStartdate()) {
                        cicledto.setId(current.getId());
                        cicledto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir CicleDto a Cicle y crear el registro
            Cicle tmp = CicleDto.CicleDtoToCicle(cicledto);
            CicleDto result = CicleDto.CicleToCicleDto(cicleService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/cicle/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            Cicle current = cicleService.findById(id);
            current.setDeleted(false);
            CicleDto result = CicleDto.CicleToCicleDto(cicleService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/cicle")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<Cicle> allCicle = cicleService.getAll();
            for (Cicle current : allCicle) {
                current.setDeleted(false);
                cicleService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.UserRateDto;
import com.aza.api.model.masterData.User;
import com.aza.api.model.masterData.UserRate;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.ProfileService;
import com.aza.api.service.masterData.UserRateService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class UserRateController {

    @Autowired
    private UserRateService userRateService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private ProfileService profileService;

    @Autowired
    private ARLService arlService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/userRate")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de UserRate:" + LocalDateTime.now());
            // Obtén solo las UserRate activas (no eliminadas)
            List<UserRate> lUserRate = userRateService.getAllActive();
            // Usa Streams para transformar las entidades UserRate en DTOs
            List<UserRateDto> lUserRateDto = lUserRate.stream()
                    .map(UserRateDto::UserRateToUserRateDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de UserRate:" + LocalDateTime.now() + " con: " + lUserRateDto.size() + " registros");

            return serviceResponse(lUserRateDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/userRate/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de UserRate:" + LocalDateTime.now());
            // Obtén solo las UserRate activas (no eliminadas)
            List<UserRate> lUserRate = userRateService.getAllActive();
            // Usa Streams para transformar las entidades UserRate en DTOs
            UserRateDto lUserRateDto = UserRateDto.UserRateToUserRateDto(lUserRate.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de UserRate:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lUserRateDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/userRate")
    public ResponseEntity<GenericResponse> post(@RequestBody UserRateDto userRatedto) {
        try {
            if (userRatedto.getId() == null) {
                List<UserRate> userRateList = userRateService.getAll();
                for (UserRate current : userRateList) {
                    if (current.getUserid().equals(userRatedto.getUser().getId())
                            && current.getArlid().equals(userRatedto.getArl().getId())
                            && current.getRatetype().equalsIgnoreCase(userRatedto.getRateType())
                            && current.getStartdate().equals(userRatedto.getStartdate())) {
                        userRatedto.setId(current.getId());
                        userRatedto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir UserRateDto a UserRate y crear el registro
            UserRate tmp = UserRateDto.UserRateDtoToUserRate(userRatedto);
            UserRateDto result = UserRateDto.UserRateToUserRateDto(userRateService.create(tmp));
            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/userRate/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            UserRate current = userRateService.findById(id);
            current.setDeleted(false);
            UserRateDto result = UserRateDto.UserRateToUserRateDto(userRateService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/userRate")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<UserRate> allUserRate = userRateService.getAll();
            for (UserRate current : allUserRate) {
                current.setDeleted(false);
                userRateService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

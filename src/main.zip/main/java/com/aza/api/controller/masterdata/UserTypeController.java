/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.UserTypeDto;
import com.aza.api.model.masterData.User;
import com.aza.api.model.masterData.UserType;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.UserService;
import com.aza.api.service.masterData.UserTypeService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class UserTypeController {

    @Autowired
    private UserTypeService userTypeService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/userType")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de UserType:" + LocalDateTime.now());
            // Obtén solo las UserType activas (no eliminadas)
            List<UserType> lUserType = userTypeService.getAllActive();
            // Usa Streams para transformar las entidades UserType en DTOs
            List<UserTypeDto> lUserTypeDto = lUserType.stream()
                    .map(UserTypeDto::UserTypeToUserTypeDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de UserType:" + LocalDateTime.now() + " con: " + lUserTypeDto.size() + " registros");
            return serviceResponse(lUserTypeDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/userType/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de UserType:" + LocalDateTime.now());
            // Obtén solo las UserType activas (no eliminadas)
            List<UserType> lUserType = userTypeService.getAllActive();
            // Usa Streams para transformar las entidades UserType en DTOs
            UserTypeDto lUserTypeDto = UserTypeDto.UserTypeToUserTypeDto(lUserType.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de UserType:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lUserTypeDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/userType")
    public ResponseEntity<GenericResponse> post(@RequestBody UserTypeDto userTypedto) {
        try {
            if (userTypedto.getId() == null) {
                List<UserType> userTypeList = userTypeService.getAll();
                for (UserType current : userTypeList) {
                    if (current.getCode().equalsIgnoreCase(userTypedto.getCode())) {
                        userTypedto.setId(current.getId());
                        userTypedto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir UserTypeDto a UserType y crear el registro
            UserType tmp = UserTypeDto.UserTypeDtoToUserType(userTypedto);
            UserTypeDto result = UserTypeDto.UserTypeToUserTypeDto(userTypeService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/userType/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            UserType current = userTypeService.findById(id).get();
            current.setDeleted(false);
            UserTypeDto result = UserTypeDto.UserTypeToUserTypeDto(userTypeService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/userType")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<UserType> allUserType = userTypeService.getAll();
            for (UserType current : allUserType) {
                current.setDeleted(false);
                userTypeService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

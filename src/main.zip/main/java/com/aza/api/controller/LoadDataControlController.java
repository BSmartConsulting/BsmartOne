/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller;

import com.aza.api.dto.GenericResponse;
import com.aza.api.model.LoadDataControl;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.LoadDataControlService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class LoadDataControlController {

    @Autowired
    private LoadDataControlService loadDataControlService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/loadDataControl")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de LoadDataControl:" + LocalDateTime.now());
            // Obtén solo las LoadDataControl activas (no eliminadas)
            List<LoadDataControl> lLoadDataControl = loadDataControlService.getAll();
            // Usa Streams para transformar las entidades LoadDataControl en DTOs
            System.out.println("Finaliza carga de LoadDataControl:" + LocalDateTime.now() + " con: " + lLoadDataControl.size() + " registros");
            return serviceResponse(lLoadDataControl, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/loadDataControl/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de LoadDataControl:" + LocalDateTime.now());
            // Obtén solo las LoadDataControl activas (no eliminadas)
            List<LoadDataControl> lLoadDataControl = loadDataControlService.getAll();
            // Usa Streams para transformar las entidades LoadDataControl en DTOs
            LoadDataControl lLoadDataControlRecord = lLoadDataControl.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null);
            System.out.println("Finaliza busqueda  de LoadDataControl:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lLoadDataControlRecord, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/loadDataControl")
    public ResponseEntity<GenericResponse> post(@RequestBody LoadDataControl loadDataControldto) {
        try {
            if (loadDataControldto.getId() == null) {
                List<LoadDataControl> loadDataControlList = loadDataControlService.getAll();
                for (LoadDataControl current : loadDataControlList) {
                    if (current.getFileName().equalsIgnoreCase(loadDataControldto.getFileName())
                            && current.getStartDate().truncatedTo(ChronoUnit.SECONDS)
                                    .equals(loadDataControldto.getStartDate().truncatedTo(ChronoUnit.SECONDS))) {
                        loadDataControldto.setId(current.getId());
                        loadDataControldto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir LoadDataControlDto a LoadDataControl y crear el registro
            LoadDataControl result = loadDataControlService.create(loadDataControldto);
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/loadDataControl/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            LoadDataControl current = loadDataControlService.findById(id).get();
            current.setDeleted(false);
            LoadDataControl result = loadDataControlService.create(current);

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/loadDataControl")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<LoadDataControl> allLoadDataControl = loadDataControlService.getAll();
            for (LoadDataControl current : allLoadDataControl) {
                current.setDeleted(false);
                loadDataControlService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

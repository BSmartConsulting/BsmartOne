/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.TaskDto;
import com.aza.api.model.masterData.Task;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/task")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de Task:" + LocalDateTime.now());
            // Obtén solo las Task activas (no eliminadas)
            List<Task> lTask = taskService.getAllActive();
            // Usa Streams para transformar las entidades Task en DTOs
            List<TaskDto> lTaskDto = lTask.stream()
                    .map(TaskDto::TaskToTaskDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de Task:" + LocalDateTime.now() + " con: " + lTaskDto.size() + " registros");
            return serviceResponse(lTaskDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/task/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de Task:" + LocalDateTime.now());
            // Obtén solo las Task activas (no eliminadas)
            List<Task> lTask = taskService.getAllActive();
            // Usa Streams para transformar las entidades Task en DTOs
            TaskDto lTaskDto = TaskDto.TaskToTaskDto(lTask.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de Task:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lTaskDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/task")
    public ResponseEntity<GenericResponse> post(@RequestBody TaskDto taskdto) {
        try {
            if (taskdto.getId() == null) {
                List<Task> taskList = taskService.getAll();
                for (Task current : taskList) {
                    if (current.getCode().equalsIgnoreCase(taskdto.getCode())) {
                        taskdto.setId(current.getId());
                        taskdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir TaskDto a Task y crear el registro
            Task tmp = TaskDto.TaskDtoToTask(taskdto);
            TaskDto result = TaskDto.TaskToTaskDto(taskService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/task/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            Task current = taskService.findById(id);
            current.setDeleted(false);
            TaskDto result = TaskDto.TaskToTaskDto(taskService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/task")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<Task> allTask = taskService.getAll();
            for (Task current : allTask) {
                current.setDeleted(false);
                taskService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

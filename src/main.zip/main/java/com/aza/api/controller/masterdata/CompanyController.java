/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.CompanyDto;
import com.aza.api.model.masterData.Company;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/company")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de Company:" + LocalDateTime.now());
            // Obtén solo las Company activas (no eliminadas)
            List<Company> lCompany = companyService.getAllActive();
            // Usa Streams para transformar las entidades Company en DTOs
            List<CompanyDto> lCompanyDto = lCompany.stream()
                    .map(CompanyDto::CompanyToCompanyDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de Company:" + LocalDateTime.now() + " con: " + lCompanyDto.size() + " registros");
            return serviceResponse(lCompanyDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/company/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de Company:" + LocalDateTime.now());
            // Obtén solo las Company activas (no eliminadas)
            List<Company> lCompany = companyService.getAllActive();
            // Usa Streams para transformar las entidades Company en DTOs
            CompanyDto lCompanyDto = CompanyDto.CompanyToCompanyDto(lCompany.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de Company:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lCompanyDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/company")
    public ResponseEntity<GenericResponse> post(@RequestBody CompanyDto companydto) {
        try {
            if (companydto.getId() == null) {
                List<Company> companyList = companyService.getAll();
                for (Company current : companyList) {
                    if (current.getCompanyname().equalsIgnoreCase(companydto.getCompanyname())) {
                        companydto.setId(current.getId());
                        companydto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir CompanyDto a Company y crear el registro
            Company tmp = CompanyDto.CompanyDtoToCompany(companydto);
            CompanyDto result = CompanyDto.CompanyToCompanyDto(companyService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/company/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            Company current = companyService.findById(id);
            current.setDeleted(false);
            CompanyDto result = CompanyDto.CompanyToCompanyDto(companyService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/company")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<Company> allCompany = companyService.getAll();
            for (Company current : allCompany) {
                current.setDeleted(false);
                companyService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

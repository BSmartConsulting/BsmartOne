/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.FrontEndMessageDto;
import com.aza.api.model.masterData.FrontEndMessage;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.FrontEndMessageService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class FrontEndMessageController {

    @Autowired
    private FrontEndMessageService frontEndMessageService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/frontEndMessage")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de FrontEndMessage:" + LocalDateTime.now());
            // Obtén solo las FrontEndMessage activas (no eliminadas)
            List<FrontEndMessage> lFrontEndMessage = frontEndMessageService.getAllActive();
            // Usa Streams para transformar las entidades FrontEndMessage en DTOs
            List<FrontEndMessageDto> lFrontEndMessageDto = lFrontEndMessage.stream()
                    .map(FrontEndMessageDto::FrontEndMessageToFrontEndMessageDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de FrontEndMessage:" + LocalDateTime.now() + " con: " + lFrontEndMessageDto.size() + " registros");
            return serviceResponse(lFrontEndMessageDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/frontEndMessage/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de FrontEndMessage:" + LocalDateTime.now());
            // Obtén solo las FrontEndMessage activas (no eliminadas)
            List<FrontEndMessage> lFrontEndMessage = frontEndMessageService.getAllActive();
            // Usa Streams para transformar las entidades FrontEndMessage en DTOs
            FrontEndMessageDto lFrontEndMessageDto = FrontEndMessageDto.FrontEndMessageToFrontEndMessageDto(lFrontEndMessage.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de FrontEndMessage:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lFrontEndMessageDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/frontEndMessage")
    public ResponseEntity<GenericResponse> post(@RequestBody FrontEndMessageDto frontEndMessagedto) {
        try {
            if (frontEndMessagedto.getId() == null) {
                List<FrontEndMessage> frontEndMessageList = frontEndMessageService.getAll();
                for (FrontEndMessage current : frontEndMessageList) {
                    if (current.getMessagekey().equalsIgnoreCase(frontEndMessagedto.getMessagekey())) {
                        frontEndMessagedto.setId(current.getId());
                        frontEndMessagedto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir FrontEndMessageDto a FrontEndMessage y crear el registro
            FrontEndMessage tmp = FrontEndMessageDto.FrontEndMessageDtoToFrontEndMessage(frontEndMessagedto);
            FrontEndMessageDto result = FrontEndMessageDto.FrontEndMessageToFrontEndMessageDto(frontEndMessageService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/frontEndMessage/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            FrontEndMessage current = frontEndMessageService.findById(id);
            current.setDeleted(false);
            FrontEndMessageDto result = FrontEndMessageDto.FrontEndMessageToFrontEndMessageDto(frontEndMessageService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/frontEndMessage")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<FrontEndMessage> allFrontEndMessage = frontEndMessageService.getAll();
            for (FrontEndMessage current : allFrontEndMessage) {
                current.setDeleted(false);
                frontEndMessageService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

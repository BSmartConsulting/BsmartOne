/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.PurchaseOrderStatusDto;
import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PurchaseOrderStatusController {

    @Autowired
    private PurchaseOrderStatusService purchaseOrderStatusService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/purchaseOrderStatus")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de PurchaseOrderStatus:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrderStatus activas (no eliminadas)
            List<PurchaseOrderStatus> lPurchaseOrderStatus = purchaseOrderStatusService.getAllActive();
            // Usa Streams para transformar las entidades PurchaseOrderStatus en DTOs
            List<PurchaseOrderStatusDto> lPurchaseOrderStatusDto = lPurchaseOrderStatus.stream()
                    .map(PurchaseOrderStatusDto::PurchaseOrderStatusToPurchaseOrderStatusDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de PurchaseOrderStatus:" + LocalDateTime.now() + " con: " + lPurchaseOrderStatusDto.size() + " registros");
            return serviceResponse(lPurchaseOrderStatusDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/purchaseOrderStatus/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de PurchaseOrderStatus:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrderStatus activas (no eliminadas)
            List<PurchaseOrderStatus> lPurchaseOrderStatus = purchaseOrderStatusService.getAllActive();
            // Usa Streams para transformar las entidades PurchaseOrderStatus en DTOs
            PurchaseOrderStatusDto lPurchaseOrderStatusDto = PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(lPurchaseOrderStatus.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de PurchaseOrderStatus:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lPurchaseOrderStatusDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/purchaseOrderStatus")
    public ResponseEntity<GenericResponse> post(@RequestBody PurchaseOrderStatusDto purchaseOrderStatusdto) {
        try {
            if (purchaseOrderStatusdto.getId() == null) {
                List<PurchaseOrderStatus> purchaseOrderStatusList = purchaseOrderStatusService.getAll();
                for (PurchaseOrderStatus current : purchaseOrderStatusList) {
                    if (current.getCode().equalsIgnoreCase(purchaseOrderStatusdto.getCode())) {
                        purchaseOrderStatusdto.setId(current.getId());
                        purchaseOrderStatusdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir PurchaseOrderStatusDto a PurchaseOrderStatus y crear el registro
            PurchaseOrderStatus tmp = PurchaseOrderStatusDto.PurchaseOrderStatusDtoToPurchaseOrderStatus(purchaseOrderStatusdto);
            PurchaseOrderStatusDto result = PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(purchaseOrderStatusService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/purchaseOrderStatus/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            PurchaseOrderStatus current = purchaseOrderStatusService.findById(id);
            current.setDeleted(false);
            PurchaseOrderStatusDto result = PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(purchaseOrderStatusService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/purchaseOrderStatus")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<PurchaseOrderStatus> allPurchaseOrderStatus = purchaseOrderStatusService.getAll();
            for (PurchaseOrderStatus current : allPurchaseOrderStatus) {
                current.setDeleted(false);
                purchaseOrderStatusService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

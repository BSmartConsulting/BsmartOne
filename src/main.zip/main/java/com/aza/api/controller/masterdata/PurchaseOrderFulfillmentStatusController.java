/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.PurchaseOrderFulfillmentStatusDto;
import com.aza.api.model.masterData.PurchaseOrderFulfillmentStatus;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.PurchaseOrderFulfillmentStatusService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PurchaseOrderFulfillmentStatusController {

    @Autowired
    private PurchaseOrderFulfillmentStatusService purchaseOrderFulfillmentStatusService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/purchaseOrderFulfillmentStatus")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de PurchaseOrderFulfillmentStatus:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrderFulfillmentStatus activas (no eliminadas)
            List<PurchaseOrderFulfillmentStatus> lPurchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatusService.getAllActive();
            // Usa Streams para transformar las entidades PurchaseOrderFulfillmentStatus en DTOs
            List<PurchaseOrderFulfillmentStatusDto> lPurchaseOrderFulfillmentStatusDto = lPurchaseOrderFulfillmentStatus.stream()
                    .map(PurchaseOrderFulfillmentStatusDto::PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de PurchaseOrderFulfillmentStatus:" + LocalDateTime.now() + " con: " + lPurchaseOrderFulfillmentStatusDto.size() + " registros");
            return serviceResponse(lPurchaseOrderFulfillmentStatusDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/purchaseOrderFulfillmentStatus/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de PurchaseOrderFulfillmentStatus:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrderFulfillmentStatus activas (no eliminadas)
            List<PurchaseOrderFulfillmentStatus> lPurchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatusService.getAllActive();
            // Usa Streams para transformar las entidades PurchaseOrderFulfillmentStatus en DTOs
            PurchaseOrderFulfillmentStatusDto lPurchaseOrderFulfillmentStatusDto = PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(lPurchaseOrderFulfillmentStatus.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de PurchaseOrderFulfillmentStatus:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lPurchaseOrderFulfillmentStatusDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/purchaseOrderFulfillmentStatus")
    public ResponseEntity<GenericResponse> post(@RequestBody PurchaseOrderFulfillmentStatusDto purchaseOrderFulfillmentStatusdto) {
        try {
            if (purchaseOrderFulfillmentStatusdto.getId() == null) {
                List<PurchaseOrderFulfillmentStatus> purchaseOrderFulfillmentStatusList = purchaseOrderFulfillmentStatusService.getAll();
                for (PurchaseOrderFulfillmentStatus current : purchaseOrderFulfillmentStatusList) {
                    if (current.getCode().equalsIgnoreCase(purchaseOrderFulfillmentStatusdto.getCode())) {
                        purchaseOrderFulfillmentStatusdto.setId(current.getId());
                        purchaseOrderFulfillmentStatusdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir PurchaseOrderFulfillmentStatusDto a PurchaseOrderFulfillmentStatus y crear el registro
            PurchaseOrderFulfillmentStatus tmp = PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusDtoToPurchaseOrderFulfillmentStatus(purchaseOrderFulfillmentStatusdto);
            PurchaseOrderFulfillmentStatusDto result = PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(purchaseOrderFulfillmentStatusService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/purchaseOrderFulfillmentStatus/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            PurchaseOrderFulfillmentStatus current = purchaseOrderFulfillmentStatusService.findById(id);
            current.setDeleted(false);
            PurchaseOrderFulfillmentStatusDto result = PurchaseOrderFulfillmentStatusDto.PurchaseOrderFulfillmentStatusToPurchaseOrderFulfillmentStatusDto(purchaseOrderFulfillmentStatusService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/purchaseOrderFulfillmentStatus")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<PurchaseOrderFulfillmentStatus> allPurchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatusService.getAll();
            for (PurchaseOrderFulfillmentStatus current : allPurchaseOrderFulfillmentStatus) {
                current.setDeleted(false);
                purchaseOrderFulfillmentStatusService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

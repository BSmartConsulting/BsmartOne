/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.PurchaseOrderDto;
import com.aza.api.dto.masterData.ARLDto;
import com.aza.api.dto.masterData.CityDto;
import com.aza.api.dto.masterData.ClasificationDto;
import com.aza.api.dto.masterData.CompanyDto;
import com.aza.api.dto.masterData.ProductDto;
import com.aza.api.dto.masterData.PurchaseOrderStatusDto;
import com.aza.api.dto.masterData.TaskDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.PurchaseOrder;
import com.aza.api.model.masterData.ARL;
import com.aza.api.model.masterData.City;
import com.aza.api.model.masterData.Clasification;
import com.aza.api.model.masterData.Company;
import com.aza.api.model.masterData.Product;
import com.aza.api.model.masterData.PurchaseOrderStatus;
import com.aza.api.model.masterData.Task;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.PurchaseOrderService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.CityService;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.CompanyService;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.PurchaseOrderStatusService;
import com.aza.api.service.masterData.TaskService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author jaime
 */
@RestController
@RequestMapping("/api/v1")
public class PurchaseOrderController {

    @Autowired
    private PurchaseOrderService purchaseOrderService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    private final CompanyService companyService;
    private final ProductService productService;
    private final ClasificationService clasificationService;
    private final TaskService taskService;
    private final UserService userService;
    private final CityService cityService;
    private final PurchaseOrderStatusService purchaseOrderStatusService;
    private final ARLService arlService;
    private Map<Long, CompanyDto> companyMap;
    private Map<Long, ProductDto> productMap;
    private Map<Long, TaskDto> taskMap;
    private Map<Long, ClasificationDto> clasificationMap;
    private Map<Long, UserDto> userMap;
    private Map<Long, CityDto> cityMap;
    private Map<Long, PurchaseOrderStatusDto> purchaseOrderStatusMap;
    private Map<Long, ARLDto> arlMap;

    @Autowired
    public PurchaseOrderController(CompanyService companyService,
            ProductService productService,
            ClasificationService clasificationService,
            TaskService taskService,
            UserService userService,
            CityService cityService,
            PurchaseOrderStatusService purchaseOrderStatusService,
            ARLService arlService) {
        this.companyService = companyService;
        this.productService = productService;
        this.clasificationService = clasificationService;
        this.taskService = taskService;
        this.userService = userService;
        this.cityService = cityService;
        this.purchaseOrderStatusService = purchaseOrderStatusService;
        this.arlService = arlService;
    }

    @GetMapping("/transactional/purchaseOrder")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de OC:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrder activas (no eliminadas)
            List<PurchaseOrder> lPurchaseOrder = purchaseOrderService.getAllActive();
            createMasterDataMap();
            // Usa Streams para transformar las entidades PurchaseOrder en DTOs
            List<PurchaseOrderDto> lPurchaseOrderDto = lPurchaseOrder.stream()
                    .map(purchaseOrder -> PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(
                    purchaseOrder,
                    companyMap,
                    productMap,
                    taskMap,
                    clasificationMap,
                    userMap,
                    cityMap,
                    purchaseOrderStatusMap,
                    arlMap))
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de OC:" + LocalDateTime.now() + " con: " + lPurchaseOrderDto.size() + " registros");
            return serviceResponse(lPurchaseOrderDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/transactional/purchaseOrder/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de PurchaseOrder:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrder activas (no eliminadas)
            List<PurchaseOrder> lPurchaseOrder = purchaseOrderService.getAllActive();
            // Usa Streams para transformar las entidades PurchaseOrder en DTOs
            createMasterDataMap();
            PurchaseOrderDto lPurchaseOrderDto = PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(
                    lPurchaseOrder.stream()
                            .filter(current -> current.getId() == id)
                            .findFirst()
                            .orElse(null),
                    companyMap,
                    productMap,
                    taskMap,
                    clasificationMap,
                    userMap,
                    cityMap,
                    purchaseOrderStatusMap,
                    arlMap
            );
            System.out.println("Finaliza busqueda  de PurchaseOrder:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lPurchaseOrderDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/transactional/purchaseOrder/getPurchaseOrderByArl/{arl}")
    public GenericResponse getPurchaseOrderByArl(@PathVariable String arl) {
        try {
            System.out.println("Inicia carga de PurchaseOrder:" + LocalDateTime.now());
            // Obtén solo las PurchaseOrder activas (no eliminadas)
            List<PurchaseOrder> lPurchaseOrder = purchaseOrderService.getAllActivePurchaseOrderByArl(arl);
            // Usa Streams para transformar las entidades PurchaseOrder en DTOs
            createMasterDataMap();
            List<PurchaseOrderDto> lPurchaseOrderDto = lPurchaseOrder.stream()
                    .map(purchaseOrder -> PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(
                    purchaseOrder,
                    companyMap,
                    productMap,
                    taskMap,
                    clasificationMap,
                    userMap,
                    cityMap,
                    purchaseOrderStatusMap,
                    arlMap))
                    .collect(Collectors.toList());
            System.out.println("Finaliza busqueda  de PurchaseOrder:" + LocalDateTime.now() + " con: arl: " + arl);
            return serviceResponse(lPurchaseOrderDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/transactional/purchaseOrder")
    public ResponseEntity<GenericResponse> post(@RequestBody PurchaseOrderDto purchaseOrderdto) {
        try {
            if (purchaseOrderdto.getId() == null) {
                List<PurchaseOrder> purchaseOrderList = purchaseOrderService.getAll();
                for (PurchaseOrder current : purchaseOrderList) {
                    if (current.getPurchaseOrderNumber().equalsIgnoreCase(purchaseOrderdto.getPurchaseOrderNumber())
                            && current.getArl() == purchaseOrderdto.getArl().getId()) {
                        purchaseOrderdto.setId(current.getId());
                        purchaseOrderdto.setDeleted(false);
                        break;
                    }
                }
            }

            PurchaseOrderDto result = (PurchaseOrderDto) purchaseOrderService.add(purchaseOrderdto, "NEW").getData();
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/transactional/purchaseOrder/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            PurchaseOrder current = purchaseOrderService.findById(id).get();
            current.setDeleted(false);
            createMasterDataMap();
            PurchaseOrderDto result = PurchaseOrderDto.PurchaseOrderToPurchaseOrderDto(purchaseOrderService.create(current),
                    companyMap, productMap, taskMap, clasificationMap, userMap, cityMap, purchaseOrderStatusMap, arlMap);

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/transactional/purchaseOrder")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<PurchaseOrder> allPurchaseOrder = purchaseOrderService.getAll();
            for (PurchaseOrder current : allPurchaseOrder) {
                current.setDeleted(false);
                purchaseOrderService.create(current);

            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping("/transactional/purchaseOrder/load")
    public ResponseEntity<GenericResponse> post(@RequestBody List<PurchaseOrderDto> purchaseOrders) {
        try {
            System.out.println("Inicia carga masiva de usuario" + LocalDateTime.now().toString());
            UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String userrname = userDetails.getUsername();

            // Cargar el usuario desde la base de datos
            User authenticatedUser = userService.loadUserByUsername(userrname);

            // Pasar el usuario autenticado al servicio
            List<PurchaseOrderDto> result = (List<PurchaseOrderDto>) purchaseOrderService.saveAllPurchaseOrders(purchaseOrders, authenticatedUser).getData();
            return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);

        } catch (RuntimeException e) {
            // Enviar el mensaje de error específico en caso de una excepción
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/transactional/purchaseOrder/updateInformation")
    public ResponseEntity<GenericResponse> postUpdatePurchaseOrderData(@RequestBody List<PurchaseOrderDto> purchaseOrders) {
        try {

            System.out.println("Inicia carga masiva de usuario" + LocalDateTime.now().toString());
            UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String userrname = userDetails.getUsername();

            // Cargar el usuario desde la base de datos
            User authenticatedUser = userService.loadUserByUsername(userrname);

            // Pasar el usuario autenticado al servicio
            List<PurchaseOrderDto> result = (List<PurchaseOrderDto>) purchaseOrderService.saveAllPurchaseOrders(purchaseOrders, authenticatedUser).getData();
            return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);

        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Company> lcompanies = companyService.getAllActive();
        List<CompanyDto> lcompaniesDto = new ArrayList<>();
        for (Company c : lcompanies) {
            lcompaniesDto.add(CompanyDto.CompanyToCompanyDto(c));
        }
        companyMap = lcompaniesDto.stream()
                .collect(Collectors.toMap(CompanyDto::getId, Function.identity()));

        List<Product> lproducts = productService.getAllActive();
        List<ProductDto> lproductsDto = new ArrayList<>();
        for (Product p : lproducts) {
            lproductsDto.add(ProductDto.ProductToProductDto(p));
        }
        productMap = lproductsDto.stream()
                .collect(Collectors.toMap(ProductDto::getId, Function.identity()));

        List<Task> ltasks = taskService.getAllActive();
        List<TaskDto> ltasksDto = new ArrayList<>();
        for (Task t : ltasks) {
            ltasksDto.add(TaskDto.TaskToTaskDto(t));
        }
        taskMap = ltasksDto.stream()
                .collect(Collectors.toMap(TaskDto::getId, Function.identity()));

        List<Clasification> lclasification = clasificationService.getAllActive();
        List<ClasificationDto> lclasificationDto = new ArrayList<>();
        for (Clasification c : lclasification) {
            lclasificationDto.add(ClasificationDto.ClasificationToClasificationDto(c));
        }
        clasificationMap = lclasificationDto.stream()
                .collect(Collectors.toMap(ClasificationDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

        List<City> lcities = cityService.getAllActive();
        List<CityDto> lcitiesDto = new ArrayList<>();
        for (City c : lcities) {
            lcitiesDto.add(CityDto.CityToCityDto(c));
        }
        cityMap = lcitiesDto.stream()
                .collect(Collectors.toMap(CityDto::getId, Function.identity()));

        List<PurchaseOrderStatus> lpurchaseOrderStatus = purchaseOrderStatusService.getAllActive();
        List<PurchaseOrderStatusDto> lpurchaseOrderStatusDto = new ArrayList<>();
        for (PurchaseOrderStatus p : lpurchaseOrderStatus) {
            lpurchaseOrderStatusDto.add(PurchaseOrderStatusDto.PurchaseOrderStatusToPurchaseOrderStatusDto(p));
        }
        purchaseOrderStatusMap = lpurchaseOrderStatusDto.stream()
                .collect(Collectors.toMap(PurchaseOrderStatusDto::getId, Function.identity()));

        List<ARL> larl = arlService.getAllActive();
        List<ARLDto> larlDto = new ArrayList<>();
        for (ARL a : larl) {
            larlDto.add(ARLDto.ARLToARLDto(a));
        }
        arlMap = larlDto.stream()
                .collect(Collectors.toMap(ARLDto::getId, Function.identity()));

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }

}

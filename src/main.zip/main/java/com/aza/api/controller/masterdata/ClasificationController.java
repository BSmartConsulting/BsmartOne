/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ClasificationDto;
import com.aza.api.model.masterData.Clasification;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ClasificationService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ClasificationController {

    @Autowired
    private ClasificationService clasificationService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/clasification")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de Clasification:" + LocalDateTime.now());
            // Obtén solo las Clasification activas (no eliminadas)
            List<Clasification> lClasification = clasificationService.getAllActive();
            // Usa Streams para transformar las entidades Clasification en DTOs
            List<ClasificationDto> lClasificationDto = lClasification.stream()
                    .map(ClasificationDto::ClasificationToClasificationDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de Clasification:" + LocalDateTime.now() + " con: " + lClasificationDto.size() + " registros");
            return serviceResponse(lClasificationDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/clasification/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de Clasification:" + LocalDateTime.now());
            // Obtén solo las Clasification activas (no eliminadas)
            List<Clasification> lClasification = clasificationService.getAllActive();
            // Usa Streams para transformar las entidades Clasification en DTOs
            ClasificationDto lClasificationDto = ClasificationDto.ClasificationToClasificationDto(lClasification.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de Clasification:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lClasificationDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/clasification")
    public ResponseEntity<GenericResponse> post(@RequestBody ClasificationDto clasificationdto) {
        try {
            if (clasificationdto.getId() == null) {
                List<Clasification> clasificationList = clasificationService.getAll();
                for (Clasification current : clasificationList) {
                    if (current.getCode().equalsIgnoreCase(clasificationdto.getCode())) {
                        clasificationdto.setId(current.getId());
                        clasificationdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ClasificationDto a Clasification y crear el registro
            Clasification tmp = ClasificationDto.ClasificationDtoToClasification(clasificationdto);
            ClasificationDto result = ClasificationDto.ClasificationToClasificationDto(clasificationService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/clasification/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            Clasification current = clasificationService.findById(id);
            current.setDeleted(false);
            ClasificationDto result = ClasificationDto.ClasificationToClasificationDto(clasificationService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/clasification")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<Clasification> allClasification = clasificationService.getAll();
            for (Clasification current : allClasification) {
                current.setDeleted(false);
                clasificationService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

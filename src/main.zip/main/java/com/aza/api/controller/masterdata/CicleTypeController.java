/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.CicleTypeDto;
import com.aza.api.model.masterData.CicleType;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.CicleTypeService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class CicleTypeController {

    @Autowired
    private CicleTypeService cicleTypeService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/cicleType")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de CicleType:" + LocalDateTime.now());
            // Obtén solo las CicleType activas (no eliminadas)
            List<CicleType> lCicleType = cicleTypeService.getAllActive();
            // Usa Streams para transformar las entidades CicleType en DTOs
            List<CicleTypeDto> lCicleTypeDto = lCicleType.stream()
                    .map(CicleTypeDto::CicleTypeToCicleTypeDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de CicleType:" + LocalDateTime.now() + " con: " + lCicleTypeDto.size() + " registros");
            return serviceResponse(lCicleTypeDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/cicleType/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de CicleType:" + LocalDateTime.now());
            // Obtén solo las CicleType activas (no eliminadas)
            List<CicleType> lCicleType = cicleTypeService.getAllActive();
            // Usa Streams para transformar las entidades CicleType en DTOs
            CicleTypeDto lCicleTypeDto = CicleTypeDto.CicleTypeToCicleTypeDto(lCicleType.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de CicleType:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lCicleTypeDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/cicleType")
    public ResponseEntity<GenericResponse> post(@RequestBody CicleTypeDto cicleTypedto) {
        try {
            if (cicleTypedto.getId() == null) {
                List<CicleType> cicleTypeList = cicleTypeService.getAll();
                for (CicleType current : cicleTypeList) {
                    if (current.getCode().equalsIgnoreCase(cicleTypedto.getCode())) {
                        cicleTypedto.setId(current.getId());
                        cicleTypedto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir CicleTypeDto a CicleType y crear el registro
            CicleType tmp = CicleTypeDto.CicleTypeDtoToCicleType(cicleTypedto);
            CicleTypeDto result = CicleTypeDto.CicleTypeToCicleTypeDto(cicleTypeService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/cicleType/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            CicleType current = cicleTypeService.findById(id);
            current.setDeleted(false);
            CicleTypeDto result = CicleTypeDto.CicleTypeToCicleTypeDto(cicleTypeService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/cicleType")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<CicleType> allCicleType = cicleTypeService.getAll();
            for (CicleType current : allCicleType) {
                current.setDeleted(false);
                cicleTypeService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

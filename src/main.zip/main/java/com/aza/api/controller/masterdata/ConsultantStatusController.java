/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ConsultantStatusDto;
import com.aza.api.model.masterData.ConsultantStatus;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ConsultantStatusService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ConsultantStatusController {

    @Autowired
    private ConsultantStatusService consultantStatusService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/consultantStatus")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de ConsultantStatus:" + LocalDateTime.now());
            // Obtén solo las ConsultantStatus activas (no eliminadas)
            List<ConsultantStatus> lConsultantStatus = consultantStatusService.getAllActive();
            // Usa Streams para transformar las entidades ConsultantStatus en DTOs
            List<ConsultantStatusDto> lConsultantStatusDto = lConsultantStatus.stream()
                    .map(ConsultantStatusDto::ConsultantStatusToConsultantStatusDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de ConsultantStatus:" + LocalDateTime.now() + " con: " + lConsultantStatusDto.size() + " registros");
            return serviceResponse(lConsultantStatusDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/consultantStatus/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de ConsultantStatus:" + LocalDateTime.now());
            // Obtén solo las ConsultantStatus activas (no eliminadas)
            List<ConsultantStatus> lConsultantStatus = consultantStatusService.getAllActive();
            // Usa Streams para transformar las entidades ConsultantStatus en DTOs
            ConsultantStatusDto lConsultantStatusDto = ConsultantStatusDto.ConsultantStatusToConsultantStatusDto(lConsultantStatus.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de ConsultantStatus:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lConsultantStatusDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/consultantStatus")
    public ResponseEntity<GenericResponse> post(@RequestBody ConsultantStatusDto consultantStatusdto) {
        try {
            if (consultantStatusdto.getId() == null) {
                List<ConsultantStatus> consultantStatusList = consultantStatusService.getAll();
                for (ConsultantStatus current : consultantStatusList) {
                    if (current.getCode().equalsIgnoreCase(consultantStatusdto.getCode())) {
                        consultantStatusdto.setId(current.getId());
                        consultantStatusdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ConsultantStatusDto a ConsultantStatus y crear el registro
            ConsultantStatus tmp = ConsultantStatusDto.ConsultantStatusDtoToConsultantStatus(consultantStatusdto);
            ConsultantStatusDto result = ConsultantStatusDto.ConsultantStatusToConsultantStatusDto(consultantStatusService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/consultantStatus/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            ConsultantStatus current = consultantStatusService.findById(id);
            current.setDeleted(false);
            ConsultantStatusDto result = ConsultantStatusDto.ConsultantStatusToConsultantStatusDto(consultantStatusService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/consultantStatus")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<ConsultantStatus> allConsultantStatus = consultantStatusService.getAll();
            for (ConsultantStatus current : allConsultantStatus) {
                current.setDeleted(false);
                consultantStatusService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

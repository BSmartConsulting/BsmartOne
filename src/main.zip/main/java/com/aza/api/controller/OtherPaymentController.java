/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.OtherPaymentDto;
import com.aza.api.dto.masterData.CicleDto;
import com.aza.api.dto.masterData.OtherPaymentTypeDto;
import com.aza.api.dto.masterData.UserDto;
import com.aza.api.model.OtherPayment;
import com.aza.api.model.masterData.Cicle;
import com.aza.api.model.masterData.OtherPaymentType;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.OtherPaymentService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.CicleService;
import com.aza.api.service.masterData.OtherPaymentTypeService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author jaime
 */
@RestController
@RequestMapping("/api/v1")
public class OtherPaymentController {

    @Autowired
    private OtherPaymentService otherPaymentService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    private final OtherPaymentTypeService otherPaymentReasonService;
    private final CicleService cicleService;
    private final UserService userService;
    private Map<Long, CicleDto> cicleMap;
    private Map<Long, OtherPaymentTypeDto> otherPaymentReasonMap;
    private Map<Long, UserDto> userMap;

    @Autowired
    public OtherPaymentController(CicleService cicleService,
            OtherPaymentTypeService otherPaymentReasonService,
            UserService userService) {
        this.cicleService = cicleService;
        this.otherPaymentReasonService = otherPaymentReasonService;
        this.userService = userService;
    }

    @GetMapping("/transactional/otherPayment")
    public GenericResponse list() {
        try {
            System.out.println("Inicia consulta de descuentos:" + LocalDateTime.now());
            List<OtherPayment> lOtherPayment = otherPaymentService.getAllActive();
            createMasterDataMap();
            List<OtherPaymentDto> lOtherPaymentDto = lOtherPayment.stream()
                    .map(otherPayment -> OtherPaymentDto.OtherPaymentToOtherPaymentDto(otherPayment, userMap, cicleMap, otherPaymentReasonMap))
                    .collect(Collectors.toList());
            System.out.println("Finaliza consulta de descuentos:" + LocalDateTime.now() + " con: " + lOtherPaymentDto.size() + " registros");
            return serviceResponse(lOtherPaymentDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/transactional/otherPayment/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia consulta de descuentos:" + LocalDateTime.now());
            List<OtherPayment> lOtherPayment = otherPaymentService.getAllActive();
            createMasterDataMap();
            OtherPaymentDto lOtherPaymentDto = OtherPaymentDto.OtherPaymentToOtherPaymentDto(
                    lOtherPayment.stream()
                            .filter(current -> current.getId() == id)
                            .findFirst()
                            .orElse(null),
                    userMap,
                    cicleMap,
                    otherPaymentReasonMap
            );
            System.out.println("Finaliza consulta de descuentos:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lOtherPaymentDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/transactional/otherPayment")
    public ResponseEntity<GenericResponse> post(@RequestBody OtherPaymentDto otherPaymentdto) {
        try {
            if (otherPaymentdto.getId() == null) {
                List<OtherPayment> otherPaymentList = otherPaymentService.getAll();
                for (OtherPayment current : otherPaymentList) {
                    if (Objects.equals(current.getOtherpaymenttype(), otherPaymentdto.getOtherPaymentType().getId())
                            && Objects.equals(current.getSettlementCicle(), otherPaymentdto.getSettlementCicle().getId())
                            && Objects.equals(current.getUser(), otherPaymentdto.getUser().getId())) {
                        otherPaymentdto.setId(current.getId());
                        otherPaymentdto.setDeleted(false);
                        break;
                    }
                }
            }

            OtherPaymentDto result = (OtherPaymentDto) otherPaymentService.add(otherPaymentdto).getData();
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/transactional/otherPayment/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            OtherPayment current = otherPaymentService.findById(id).get();
            current.setDeleted(false);
            createMasterDataMap();
            OtherPaymentDto result = OtherPaymentDto.OtherPaymentToOtherPaymentDto(otherPaymentService.create(current),
                    userMap, cicleMap, otherPaymentReasonMap);

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/transactional/otherPayment")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<OtherPayment> allOtherPayment = otherPaymentService.getAll();
            for (OtherPayment current : allOtherPayment) {
                current.setDeleted(false);
                otherPaymentService.create(current);

            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping("/transactional/otherPayment/load")
    public ResponseEntity<GenericResponse> post(@RequestBody List<OtherPaymentDto> otherPayments) {
        try {

            System.out.println("Inicia carga masiva de usuario" + LocalDateTime.now().toString());
            UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            String userrname = userDetails.getUsername();

            // Cargar el usuario desde la base de datos
            User authenticatedUser = userService.loadUserByUsername(userrname);

            // Pasar el usuario autenticado al servicio
            List<OtherPaymentDto> result = (List<OtherPaymentDto>) otherPaymentService.saveAllOtherPayments(otherPayments, authenticatedUser).getData();
            return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);

        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

   private void createMasterDataMap() {
        // Crear mapas para búsqueda rápida de DTOs
        List<Cicle> lCicles = cicleService.getAllActive();
        List<CicleDto> lCiclesDto = new ArrayList<>();
        for (Cicle c : lCicles) {
            lCiclesDto.add(CicleDto.CicleToCicleDto(c));
        }
        cicleMap = lCiclesDto.stream()
                .collect(Collectors.toMap(CicleDto::getId, Function.identity()));

        List<OtherPaymentType> lOtherPaymentTypes = otherPaymentReasonService.getAllActive();
        List<OtherPaymentTypeDto> lOtherPaymentTypesDto = new ArrayList<>();
        for (OtherPaymentType d : lOtherPaymentTypes) {
            lOtherPaymentTypesDto.add(OtherPaymentTypeDto.OtherPaymentTypeToOtherPaymentTypeDto(d));
        }
        otherPaymentReasonMap = lOtherPaymentTypesDto.stream()
                .collect(Collectors.toMap(OtherPaymentTypeDto::getId, Function.identity()));

        List<User> luser = userService.getAllActive();
        List<UserDto> luserDto = new ArrayList<>();
        for (User u : luser) {
            luserDto.add(UserDto.UserToUserDto(u));
        }
        userMap = luserDto.stream()
                .collect(Collectors.toMap(UserDto::getId, Function.identity()));

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }

}

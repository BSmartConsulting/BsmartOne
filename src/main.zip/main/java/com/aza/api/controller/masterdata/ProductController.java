/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ProductDto;
import com.aza.api.model.masterData.Product;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ProductService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/product")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de Product:" + LocalDateTime.now());
            // Obtén solo las Product activas (no eliminadas)
            List<Product> lProduct = productService.getAllActive();
            // Usa Streams para transformar las entidades Product en DTOs
            List<ProductDto> lProductDto = lProduct.stream()
                    .map(ProductDto::ProductToProductDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de Product:" + LocalDateTime.now() + " con: " + lProductDto.size() + " registros");
            return serviceResponse(lProductDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/product/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de Product:" + LocalDateTime.now());
            // Obtén solo las Product activas (no eliminadas)
            List<Product> lProduct = productService.getAllActive();
            // Usa Streams para transformar las entidades Product en DTOs
            ProductDto lProductDto = ProductDto.ProductToProductDto(lProduct.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de Product:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lProductDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/product")
    public ResponseEntity<GenericResponse> post(@RequestBody ProductDto productdto) {
        try {
            if (productdto.getId() == null) {
                List<Product> productList = productService.getAll();
                for (Product current : productList) {
                    if (current.getCode().equalsIgnoreCase(productdto.getCode())) {
                        productdto.setId(current.getId());
                        productdto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ProductDto a Product y crear el registro
            Product tmp = ProductDto.ProductDtoToProduct(productdto);
            ProductDto result = ProductDto.ProductToProductDto(productService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/product/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            Product current = productService.findById(id);
            current.setDeleted(false);
            ProductDto result = ProductDto.ProductToProductDto(productService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/product")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<Product> allProduct = productService.getAll();
            for (Product current : allProduct) {
                current.setDeleted(false);
                productService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

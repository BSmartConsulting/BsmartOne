/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ProfileDto;
import com.aza.api.model.masterData.Profile;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ProfileService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/profile")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de Profile:" + LocalDateTime.now());
            // Obtén solo las Profile activas (no eliminadas)
            List<Profile> lProfile = profileService.getAllActive();
            // Usa Streams para transformar las entidades Profile en DTOs
            List<ProfileDto> lProfileDto = lProfile.stream()
                    .map(ProfileDto::ProfileToProfileDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de Profile:" + LocalDateTime.now() + " con: " + lProfileDto.size() + " registros");
            return serviceResponse(lProfileDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/profile/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de Profile:" + LocalDateTime.now());
            // Obtén solo las Profile activas (no eliminadas)
            List<Profile> lProfile = profileService.getAllActive();
            // Usa Streams para transformar las entidades Profile en DTOs
            ProfileDto lProfileDto = ProfileDto.ProfileToProfileDto(lProfile.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de Profile:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lProfileDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/profile")
    public ResponseEntity<GenericResponse> post(@RequestBody ProfileDto profiledto) {
        try {
            if (profiledto.getId() == null) {
                List<Profile> profileList = profileService.getAll();
                for (Profile current : profileList) {
                    if (current.getCode().equalsIgnoreCase(profiledto.getCode())) {
                        profiledto.setId(current.getId());
                        profiledto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ProfileDto a Profile y crear el registro
            Profile tmp = ProfileDto.ProfileDtoToProfile(profiledto);
            ProfileDto result = ProfileDto.ProfileToProfileDto(profileService.create(tmp));
            // Devolver la respuesta
            if (result != null) {

                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/profile/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            Profile current = profileService.findById(id);
            current.setDeleted(false);
            ProfileDto result = ProfileDto.ProfileToProfileDto(profileService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/profile")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<Profile> allProfile = profileService.getAll();
            for (Profile current : allProfile) {
                current.setDeleted(false);
                profileService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

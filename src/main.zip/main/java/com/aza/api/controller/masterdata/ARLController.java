/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.controller.masterdata;

import com.aza.api.dto.GenericResponse;
import com.aza.api.dto.masterData.ARLDto;
import com.aza.api.model.masterData.ARL;
import com.aza.api.model.masterData.User;
import com.aza.api.service.JwtService;
import com.aza.api.service.UserDetailsServiceImpl;
import com.aza.api.service.masterData.ARLService;
import com.aza.api.service.masterData.UserService;
import com.aza.api.util.GlobalExceptionHandler;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author jaime
 */
@RestController
@RequestMapping("/api/v1")
public class ARLController {

    @Autowired
    private ARLService arlService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/masterData/arl")
    public GenericResponse list() {
        try {
            System.out.println("Inicia carga de ARL:" + LocalDateTime.now());
            // Obtén solo las ARL activas (no eliminadas)
            List<ARL> lARL = arlService.getAllActive();
            // Usa Streams para transformar las entidades ARL en DTOs
            List<ARLDto> lARLDto = lARL.stream()
                    .map(ARLDto::ARLToARLDto)
                    .collect(Collectors.toList());
            System.out.println("Finaliza carga de ARL:" + LocalDateTime.now() + " con: " + lARLDto.size() + " registros");
            return serviceResponse(lARLDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @GetMapping("/masterData/arl/{id}")
    public GenericResponse get(@PathVariable long id) {
        try {
            System.out.println("Inicia carga de ARL:" + LocalDateTime.now());
            // Obtén solo las ARL activas (no eliminadas)
            List<ARL> lARL = arlService.getAllActive();
            // Usa Streams para transformar las entidades ARL en DTOs
            ARLDto lARLDto = ARLDto.ARLToARLDto(lARL.stream()
                    .filter(current -> current.getId() == id)
                    .findFirst()
                    .orElse(null));
            System.out.println("Finaliza busqueda  de ARL:" + LocalDateTime.now() + " con: id: " + id);
            return serviceResponse(lARLDto, "OK");
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return serviceResponse(null, e.getMessage());
        }
    }

    @PostMapping("/masterData/arl")
    public ResponseEntity<GenericResponse> post(@RequestBody ARLDto arldto) {
        try {
            if (arldto.getId() == null) {
                List<ARL> arlList = arlService.getAll();
                for (ARL current : arlList) {
                    if (current.getCode().equalsIgnoreCase(arldto.getCode())) {
                        arldto.setId(current.getId());
                        arldto.setDeleted(false);
                        break;
                    }
                }
            }

            // Convertir ARLDto a ARL y crear el registro
            ARL tmp = ARLDto.ARLDtoToARL(arldto);
            ARLDto result = ARLDto.ARLToARLDto(arlService.create(tmp));
            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/arl/{id}")
    public ResponseEntity<GenericResponse> delete(@PathVariable long id) {
        try {

            ARL current = arlService.findById(id);
            current.setDeleted(false);
            ARLDto result = ARLDto.ARLToARLDto(arlService.create(current));

            // Devolver la respuesta
            if (result != null) {
                return new ResponseEntity<>(serviceResponse(result, "OK"), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(serviceResponse(null, "ERROR"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/masterData/arl")
    public ResponseEntity<GenericResponse> deleteAll() {
        try {
            List<ARL> allARL = arlService.getAll();
            for (ARL current : allARL) {
                current.setDeleted(false);
                arlService.create(current);
            }
            return new ResponseEntity<>(serviceResponse(null, "OK"), HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            GlobalExceptionHandler.responseErrorMessage(e);
            return new ResponseEntity<>(serviceResponse(null, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private <T> GenericResponse<T> serviceResponse(T data, String response) {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Cargar el usuario desde la base de datos
        User authenticatedUser = userService.loadUserByUsername(username);
        String token = jwtService.getToken(userDetailsServiceImpl.loadUserByUsername(authenticatedUser.getUsername()), authenticatedUser);
        return GenericResponse.<T>builder()
                .token(token)
                .data(data)
                .response(response)
                .build();
    }
}

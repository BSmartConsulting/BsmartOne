/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model.masterData;

import com.aza.api.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "clasificationsupport")
public class ClasificationSupport extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long clasification;

    @Column(nullable = false)
    private Long arl;

    @Column(nullable = false, name = "requiresvisitsupport")
    private boolean requiresVisitSupport;

    @Column(nullable = false, name = "requiresdeliverysupport")
    private boolean requiresDeliverySupport;

    @Column(nullable = false, name = "requirestrainingsupport")
    private boolean requiresTrainingSupport;

    @Column(nullable = false, name = "requiresevaluationsupport")
    private boolean requiresEvaluationSupport;

    public ClasificationSupport() {
    }

    @Builder
    public ClasificationSupport(Long id, Long clasification, Long arl, boolean requiresVisitSupport, boolean requiresDeliverySupport, boolean requiresTrainingSupport, boolean requiresEvaluationSupport, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.clasification = clasification;
        this.arl = arl;
        this.requiresVisitSupport = requiresVisitSupport;
        this.requiresDeliverySupport = requiresDeliverySupport;
        this.requiresTrainingSupport = requiresTrainingSupport;
        this.requiresEvaluationSupport = requiresEvaluationSupport;
    }

}

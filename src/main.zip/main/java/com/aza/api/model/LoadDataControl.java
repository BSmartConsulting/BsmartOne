/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "loaddatacontrol")
public class LoadDataControl extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "filename", nullable = false)
    private String fileName;

    @Column(name = "payloadtype", nullable = false)
    private String payLoadType;

    @Column(name = "startdate", nullable = false)
    private LocalDateTime startDate;

    @Column(name = "enddate")
    private LocalDateTime endDate;

    @Column(name = "loadstatus", nullable = false)
    private String loadStatus;

    @Column(name = "stage", nullable = false)
    private String stage;

    @Column(name = "numberofrecords")
    private Integer numberOfRecords;

    @Column(name = "executionlog")
    private String executionLog;

    public LoadDataControl() {

    }

    @Builder
    public LoadDataControl(Long id, String fileName, String payLoadType, LocalDateTime startDate, LocalDateTime endDate, String loadStatus, String stage, Integer numberOfRecords, String executionLog, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.fileName = fileName;
        this.payLoadType = payLoadType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.loadStatus = loadStatus;
        this.stage = stage;
        this.numberOfRecords = numberOfRecords;
        this.executionLog = executionLog;
    }

}

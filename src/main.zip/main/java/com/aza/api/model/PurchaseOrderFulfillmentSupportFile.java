/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "purchaseorderfulfillmentsupportfile")
public class PurchaseOrderFulfillmentSupportFile extends BaseEntity {

    @Id
    @Column(name = "ID", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "purchaseorderfulfillment")
    private Long purchaseOrderFulfillment;

    @Column(name = "description")
    private String description;

    @Column(name = "type")
    private String type;

    @Column(name = "payload", columnDefinition = "LONGBLOB")
    private byte[] payLoad; // Para almacenar el archivo PDF como un array de bytes

    @Column(name = "filefullname")
    private String fileFullName;

    @Column(name = "filename")
    private String fileName;

    @Column(name = "fileextention")
    private String fileExtention;

    public PurchaseOrderFulfillmentSupportFile() {
    }

    @Builder
    public PurchaseOrderFulfillmentSupportFile(Long id, Long purchaseOrderFulfillment, String description, String type, byte[] payLoad, String fileFullName, String fileName, String fileExtention, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.purchaseOrderFulfillment = purchaseOrderFulfillment;
        this.description = description;
        this.type = type;
        this.payLoad = payLoad;
        this.fileFullName = fileFullName;
        this.fileName = fileName;
        this.fileExtention = fileExtention;
    }

}

package com.aza.api.model.masterData;

import com.aza.api.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Set;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "users", indexes = {
    @Index(name = "idx_user_username", columnList = "username"),
    @Index(name = "idx_user_taxid", columnList = "taxid"),
    @Index(name = "idx_user_email", columnList = "email")
})
public class User extends BaseEntity implements Serializable {

    @Id
    @Column(name = "ID", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @JsonIgnore
    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String taxid;

    @Column(nullable = false)
    private String fullname;

    @Column(nullable = false)
    private Long status;

    @Column
    private Long azaprofile;

    @Column(nullable = false)
    private String capacity;

    @Column(nullable = false)
    private Long usertype;

    @Column
    private boolean requirespasswordchange;

    @Column
    private String specialty;

    @Column
    private String corporateemail;

    @Column
    private String licensenumber;

    @Column
    private String technicalexperience;

    @Column
    private String specialization;

    @Column
    private String coreprofession;

    @Column
    private String otherformation;

    @Column
    private String cityofresidence;

    @Column
    private String address;

    @Column
    private Integer failedattempts;

    @Column
    private String coodinator;

    @Column
    private String supportconsultant;

    @Column
    private LocalDateTime startdate;

    @Column
    private LocalDateTime enddate;

    @Column
    private String cellphone;

    @Transient
    private Set<Long> roles;

    public User() {
    }

    @Builder
    public User(Long id, String username, String password, String email, String taxid, String fullname, Long status, Long azaprofile, String capacity, Long usertype, boolean requirespasswordchange, String specialty, String corporateemail, String licensenumber, String technicalexperience, String specialization, String coreprofession, String otherformation, String cityofresidence, String address, Integer failedattempts, String coodinator, String supportconsultant, LocalDateTime startdate, LocalDateTime enddate, String cellphone, Set<Long> roles, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.taxid = taxid;
        this.fullname = fullname;
        this.status = status;
        this.azaprofile = azaprofile;
        this.capacity = capacity;
        this.usertype = usertype;
        this.requirespasswordchange = requirespasswordchange;
        this.specialty = specialty;
        this.corporateemail = corporateemail;
        this.licensenumber = licensenumber;
        this.technicalexperience = technicalexperience;
        this.specialization = specialization;
        this.coreprofession = coreprofession;
        this.otherformation = otherformation;
        this.cityofresidence = cityofresidence;
        this.address = address;
        this.failedattempts = failedattempts;
        this.coodinator = coodinator;
        this.supportconsultant = supportconsultant;
        this.startdate = startdate;
        this.enddate = enddate;
        this.cellphone = cellphone;
        this.roles = roles;
    }

}

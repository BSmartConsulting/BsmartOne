/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model.masterData;

import com.aza.api.model.BaseEntity;
import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "cicle")
public class Cicle extends BaseEntity implements Serializable {

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long cicletype;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String ciclenumber;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private LocalDateTime startdate;

    @Column(nullable = false)
    private LocalDateTime enddate;

    public Cicle() {
    }

    @Builder
    public Cicle(Long id, Long cicletype, String name, String ciclenumber, String description, LocalDateTime startdate, LocalDateTime enddate, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.cicletype = cicletype;
        this.name = name;
        this.ciclenumber = ciclenumber;
        this.description = description;
        this.startdate = startdate;
        this.enddate = enddate;
    }

}

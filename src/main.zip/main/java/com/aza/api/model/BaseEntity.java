/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 *
 * @author jaime
 */
@Getter
@Setter
@Accessors(chain = true)
@MappedSuperclass
public abstract class BaseEntity {

    @Column(name = "creationdate")
    private LocalDateTime creationDate;

    @Column(name = "lastupdateddate")
    private LocalDateTime lastUpdatedDate;

    @Column(name = "createdby")
    private String createdBy;

    @Column(name = "lastupdatedby")
    private String lastUpdatedBy;

    @Column(name = "deleted")
    private Boolean deleted;

    public BaseEntity(LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        this.creationDate = creationDate;
        this.lastUpdatedDate = lastUpdatedDate;
        this.createdBy = createdBy;
        this.lastUpdatedBy = lastUpdatedBy;
        this.deleted = deleted;
    }

    public BaseEntity() {
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "otherpayment")
public class OtherPayment extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "userid", nullable = false)
    private Long user;

    @Column(name = "otherpaymenttype", nullable = false)
    private Long otherpaymenttype;

    @Column(name = "settlementcicle", nullable = false)
    private Long settlementCicle;

    @Column(name = "amount")
    private Long amount;

    public OtherPayment() {
    }

    @Builder
    public OtherPayment(Long id, Long user, Long otherpaymenttype, Long settlementCicle, Long amount, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.user = user;
        this.otherpaymenttype = otherpaymenttype;
        this.settlementCicle = settlementCicle;
        this.amount = amount;
    }


}

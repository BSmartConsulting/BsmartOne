/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "purchaseorder")
public class PurchaseOrder extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "orderpurchasenumber", nullable = false, unique = true)
    private String purchaseOrderNumber;

    @Column(name = "company", nullable = false)
    private Long company;

    @Column(name = "product", nullable = false)
    private Long product;

    @Column(name = "task")
    private Long task;

    @Column(name = "clasification")
    private Long clasification;

    @Column(name = "userid")
    private Long user;

    @Column(name = "approvaldate")
    private LocalDateTime approvalDate;

    @Column(name = "cityoforigin")
    private Long cityOfOrigin;

    @Column(name = "destinationcity")
    private Long destinationCity;

    @Column(name = "purchaseorderstatus")
    private Long purchaseOrderStatus;

    @Column(name = "requestedhours")
    private Double requestedHours;

    @Column(name = "executedhours")
    private Double executedhours;

    @Column(name = "availablehours")
    private Double availablehours;

    @Column(name = "arl")
    private Long arl;

    @Column(name = "observation")
    private String observation;

    @Column(name = "requiresreport")
    private boolean requiresReport;

    @Column(name = "requirestransportation")
    private boolean requiresTransportation;

    @Column(name = "custompurchaseorderrate")
    private boolean customPurchaseOrderRate;

    @Column(name = "custompurchaseorderratevalue")
    private Double customPurchaseOrderRateValue;
    

    public PurchaseOrder() {
    }

    @Builder
    public PurchaseOrder(Long id, String purchaseOrderNumber, Long company, Long product, Long task, Long clasification, Long user, LocalDateTime approvalDate, Long cityOfOrigin, Long destinationCity, Long purchaseOrderStatus, Double requestedHours, Double executedhours, Double availablehours, Long arl, String observation, boolean requiresReport, boolean requiresTransportation, boolean customPurchaseOrderRate, Double customPurchaseOrderRateValue, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.purchaseOrderNumber = purchaseOrderNumber;
        this.company = company;
        this.product = product;
        this.task = task;
        this.clasification = clasification;
        this.user = user;
        this.approvalDate = approvalDate;
        this.cityOfOrigin = cityOfOrigin;
        this.destinationCity = destinationCity;
        this.purchaseOrderStatus = purchaseOrderStatus;
        this.requestedHours = requestedHours;
        this.executedhours = executedhours;
        this.availablehours = availablehours;
        this.arl = arl;
        this.observation = observation;
        this.requiresReport = requiresReport;
        this.requiresTransportation = requiresTransportation;
        this.customPurchaseOrderRate = customPurchaseOrderRate;
        this.customPurchaseOrderRateValue = customPurchaseOrderRateValue;
    }

}

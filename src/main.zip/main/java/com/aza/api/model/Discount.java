/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "discount")
public class Discount extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "userid", nullable = false)
    private Long userId;

    @Column(name = "discountreason", nullable = false)
    private Long discountReason;

    @Column(name = "settlementcicle", nullable = false)
    private Long settlementCicle;

    @Column(name = "discountDate")
    private LocalDate discountDate;

    @Column(name = "amount")
    private Long amount;

    public Discount() {
    }

    @Builder
    public Discount(Long id, Long userId, Long discountReason, Long settlementCicle, LocalDate discountDate, Long amount, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.userId = userId;
        this.discountReason = discountReason;
        this.settlementCicle = settlementCicle;
        this.discountDate = discountDate;
        this.amount = amount;
    }

}

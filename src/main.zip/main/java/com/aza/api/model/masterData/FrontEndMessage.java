/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model.masterData;

import com.aza.api.model.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *
 * @author jaime
 */
@Entity
@Table(name = "frontendmessages")
@Data
@EqualsAndHashCode(callSuper = false)
public class FrontEndMessage extends BaseEntity implements Serializable {

    @Id
    @Column(name = "ID", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "entity")
    private String entity;

    @Column(name = "messagekey")
    private String messagekey;

    @Column(name = "value_es")
    private String value_es;

    @Column(name = "value_en")
    private String value_en;

    public FrontEndMessage() {
    }

    @Builder
    public FrontEndMessage(Long id, String entity, String messagekey, String value_es, String value_en, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.entity = entity;
        this.messagekey = messagekey;
        this.value_es = value_es;
        this.value_en = value_en;
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "transactionlog")
public class TransactionLog extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "logtype", nullable = false)
    private String logType;

    @Column(name = "uniquekey", nullable = false)
    private String uniqueKey;

    @Column(name = "payload", nullable = false)
    private String payLoad;

    @Column(name = "updateddate")
    private LocalDateTime updatedDate;

    @Column(name = "userid", nullable = false)
    private String userId;

    public TransactionLog() {

    }

    @Builder
    public TransactionLog(Long id, String logType, String key, String payLoad, LocalDateTime updatedDate, String userId, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.logType = logType;
        this.uniqueKey = key;
        this.payLoad = payLoad;
        this.updatedDate = updatedDate;
        this.userId = userId;
    }

}

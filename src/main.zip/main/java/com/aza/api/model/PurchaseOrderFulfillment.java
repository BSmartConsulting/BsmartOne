/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "purchaseorderfulfillment")
public class PurchaseOrderFulfillment extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "purchaseorder", nullable = false)
    private Long purchaseOrder;

    @Column(name = "appointmentdate", nullable = false)
    private LocalDateTime appointmentDate;

    @Column(name = "purchaseorderfulfillmentstatus", nullable = false)
    private Long purchaseOrderFulfillmentStatus;

    @Column(name = "executedhours")
    private Double executedHours;

    @Column(name = "servicetype")
    private Long serviceType;

    @Column(name = "reportapprovaldate")
    private LocalDateTime reportApprovalDate;

    @Column(name = "invoicenumber")
    private String invoiceNumber;

    @Column(name = "billedhours")
    private Double billedHours;

    @Column(name = "invoicestatus")
    private Long invoiceStatus;

    @Column(name = "purchaseorderrejectionreason")
    private Long purchaseOrderRejectionReason;

    @Column(name = "transportationexpenses")
    private Double transportationExpenses;

    @Column(name = "travelexpenses")
    private Double travelExpenses;

    @Column(name = "requiressupport")
    private boolean requiresSupport;

    @Column(name = "requiresreport")
    private boolean requiresReport;

    @Column(name = "hasbankofhours")
    private boolean hasBankOfHours;

    @Column(name = "ciclename")
    private String cicleName;

    @Column(name = "fulfillmentcityoforigin")
    private Long fulfillmentCityOfOrigin;

    @Column(name = "fulfillmentdestinationcity")
    private Long fulfillmentDestinationCity;

    @Column(name = "requiresTransport")
    private boolean requiresTransport;

    @Column(name = "requireintercitytransport")
    private boolean requireIntercityTransport;

    @Column(name = "requirespaciatransport")
    private boolean requireSpecialTransport;

    @Column(name = "requiretravelexpenses")
    private boolean requireTravelExpenses;

    @Column(name = "requiredeliverysupport")
    private boolean requireDeliverySupport;

    @Column(name = "requirevisitsupport")
    private boolean requireVisitSupport;

    @Column(name = "requireevaluationsupport")
    private boolean requireEvaluationSupport;

    @Column(name = "requiretrainingsupport")
    private boolean requireTrainingSupport;

    @Column(name = "reviewedbyconsultant")
    private boolean reviewedByConsultant;

    @Column(name = "observation")
    private String observation;

    @Column(name = "rejectionmotiveobservation")
    private String rejectionMotiveObservation;

    @Column(name = "userid")
    private Long user;

    @Column(name = "reportcicleid")
    private Long reportCicle;

    @Column(name = "approvecicleid")
    private Long approveCicle;

    @Column(name = "billingcicleid")
    private Long billingCicle;

    @Column(name = "settlementcicleid")
    private Long settlementCicle;

    @Column(name = "azasettlementrate")
    private Double azaSettlementRate;

    @Column(name = "arlbillingrate")
    private Double arlBillingRate;

    @Column(name = "bankofhoursrequestdate")
    private LocalDate bankOfHoursRequestDate;

    @Column(name = "bankofhourspaymentdate")
    private LocalDate bankOfHoursPaymentDate;

    @Column(name = "travelexpensessettlementvalue")
    private Double travelExpensesSsettlementValue;

    @Column(name = "transportexpensessettlementvalue")
    private Double transportexpensessettlementvalue;

    @Column(name = "settlementhours")
    private Double settlementhours;
    
    @Column(name = "customsettlementvalues")
    private Boolean customsettlementvalues;

    @Column(name = "customsettlementvaluesobservation")
    private String customsettlementvaluesobservation;
    
    @Column
    private String coodinator;

    @Column
    private String supportconsultant;

    
    public PurchaseOrderFulfillment() {
    }

    @Builder
    public PurchaseOrderFulfillment(Long id, Long purchaseOrder, LocalDateTime appointmentDate, Long purchaseOrderFulfillmentStatus, Double executedHours, Long serviceType, LocalDateTime reportApprovalDate, String invoiceNumber, Double billedHours, Long invoiceStatus, Long purchaseOrderRejectionReason, Double transportationExpenses, Double travelExpenses, boolean requiresSupport, boolean requiresReport, boolean hasBankOfHours, String cicleName, Long fulfillmentCityOfOrigin, Long fulfillmentDestinationCity, boolean requiresTransport, boolean requireIntercityTransport, boolean requireSpecialTransport, boolean requireTravelExpenses, boolean requireDeliverySupport, boolean requireVisitSupport, boolean requireEvaluationSupport, boolean requireTrainingSupport, boolean reviewedByConsultant, String observation, String rejectionMotiveObservation, Long user, Long reportCicle, Long approveCicle, Long billingCicle, Long settlementCicle, Double azaSettlementRate, Double arlBillingRate, LocalDate bankOfHoursRequestDate, LocalDate bankOfHoursPaymentDate, Double travelExpensesSsettlementValue, Double transportexpensessettlementvalue, Double settlementhours, Boolean customsettlementvalues, String customsettlementvaluesobservation, String coodinator, String supportconsultant, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.purchaseOrder = purchaseOrder;
        this.appointmentDate = appointmentDate;
        this.purchaseOrderFulfillmentStatus = purchaseOrderFulfillmentStatus;
        this.executedHours = executedHours;
        this.serviceType = serviceType;
        this.reportApprovalDate = reportApprovalDate;
        this.invoiceNumber = invoiceNumber;
        this.billedHours = billedHours;
        this.invoiceStatus = invoiceStatus;
        this.purchaseOrderRejectionReason = purchaseOrderRejectionReason;
        this.transportationExpenses = transportationExpenses;
        this.travelExpenses = travelExpenses;
        this.requiresSupport = requiresSupport;
        this.requiresReport = requiresReport;
        this.hasBankOfHours = hasBankOfHours;
        this.cicleName = cicleName;
        this.fulfillmentCityOfOrigin = fulfillmentCityOfOrigin;
        this.fulfillmentDestinationCity = fulfillmentDestinationCity;
        this.requiresTransport = requiresTransport;
        this.requireIntercityTransport = requireIntercityTransport;
        this.requireSpecialTransport = requireSpecialTransport;
        this.requireTravelExpenses = requireTravelExpenses;
        this.requireDeliverySupport = requireDeliverySupport;
        this.requireVisitSupport = requireVisitSupport;
        this.requireEvaluationSupport = requireEvaluationSupport;
        this.requireTrainingSupport = requireTrainingSupport;
        this.reviewedByConsultant = reviewedByConsultant;
        this.observation = observation;
        this.rejectionMotiveObservation = rejectionMotiveObservation;
        this.user = user;
        this.reportCicle = reportCicle;
        this.approveCicle = approveCicle;
        this.billingCicle = billingCicle;
        this.settlementCicle = settlementCicle;
        this.azaSettlementRate = azaSettlementRate;
        this.arlBillingRate = arlBillingRate;
        this.bankOfHoursRequestDate = bankOfHoursRequestDate;
        this.bankOfHoursPaymentDate = bankOfHoursPaymentDate;
        this.travelExpensesSsettlementValue = travelExpensesSsettlementValue;
        this.transportexpensessettlementvalue = transportexpensessettlementvalue;
        this.settlementhours = settlementhours;
        this.customsettlementvalues = customsettlementvalues;
        this.customsettlementvaluesobservation = customsettlementvaluesobservation;
        this.coodinator = coodinator;
        this.supportconsultant = supportconsultant;
    }
}

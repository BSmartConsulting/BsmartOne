/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aza.api.model.masterData;

import com.aza.api.model.BaseEntity;
import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode(callSuper = false)
@Table(name = "userrate")
public class UserRate extends BaseEntity implements Serializable {

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long profileid;

    @Column(nullable = false)
    private String ratetype;

    @Column(nullable = false)
    private double ratevalue;

    @Column(nullable = false)
    private Long userid;

    @Column(nullable = false)
    private Long arlid;

    @Column
    private LocalDateTime startdate;

    @Column
    private LocalDateTime enddate;

    @Column
    private boolean approved;
    
    public UserRate() {
    }

    @Builder
    public UserRate(Long id, Long profileid, String ratetype, double ratevalue, Long userid, Long arlid, LocalDateTime startdate, LocalDateTime enddate, boolean approved, LocalDateTime creationDate, LocalDateTime lastUpdatedDate, String createdBy, String lastUpdatedBy, Boolean deleted) {
        super(creationDate, lastUpdatedDate, createdBy, lastUpdatedBy, deleted);
        this.id = id;
        this.profileid = profileid;
        this.ratetype = ratetype;
        this.ratevalue = ratevalue;
        this.userid = userid;
        this.arlid = arlid;
        this.startdate = startdate;
        this.enddate = enddate;
        this.approved = approved;
    }
    
}
